import { d as createAstro, c as createComponent, m as maybeRenderHead, b as renderTemplate, a as addAttribute } from './astro/server_yypz6blN.mjs';
import 'piccolore';
import 'clsx';

const $$Astro = createAstro("https://ehsan-pourhadi.com/");
const $$Pagination = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Pagination;
  const {
    currentPage,
    totalPages,
    basePath = "/blog",
    totalItems,
    itemsPerPage = 9
  } = Astro2.props;
  if (totalPages <= 1) {
    return null;
  }
  const getPageUrl = (page) => {
    if (page <= 1) return basePath;
    return `${basePath}/page/${page}`;
  };
  const prevUrl = currentPage > 1 ? getPageUrl(currentPage - 1) : null;
  const nextUrl = currentPage < totalPages ? getPageUrl(currentPage + 1) : null;
  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    if (totalPages <= maxVisible + 2) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
      return pages;
    }
    pages.push(1);
    const left = Math.max(2, currentPage - 1);
    const right = Math.min(totalPages - 1, currentPage + 1);
    if (left > 2) {
      pages.push("ellipsis");
    }
    for (let i = left; i <= right; i++) {
      pages.push(i);
    }
    if (right < totalPages - 1) {
      pages.push("ellipsis");
    }
    pages.push(totalPages);
    return pages;
  };
  const pageNumbers = getPageNumbers();
  return renderTemplate`${maybeRenderHead()}<nav class="mt-16 flex flex-col items-center justify-between gap-4 border-t border-neutral-200 pt-8 sm:flex-row dark:border-white/10" aria-label="Pagination"> ${typeof totalItems === "number" ? renderTemplate`<p class="text-xs font-medium text-neutral-500 dark:text-neutral-400">
Showing${" "} <span class="font-semibold text-neutral-900 dark:text-white"> ${(currentPage - 1) * itemsPerPage + 1} </span>
–
<span class="font-semibold text-neutral-900 dark:text-white"> ${Math.min(currentPage * itemsPerPage, totalItems)} </span>${" "}
of${" "} <span class="font-semibold text-neutral-900 dark:text-white">${totalItems}</span>${" "}
posts
</p>` : renderTemplate`<p class="text-xs font-medium text-neutral-500 dark:text-neutral-400">
Page <span class="font-semibold text-neutral-900 dark:text-white">${currentPage}</span> of${" "} <span class="font-semibold text-neutral-900 dark:text-white">${totalPages}</span> </p>`} <div class="flex items-center gap-1.5">  ${prevUrl ? renderTemplate`<a${addAttribute(prevUrl, "href")} class="inline-flex items-center gap-1 rounded-full border border-neutral-300/80 bg-white/80 px-3.5 py-1.5 text-xs font-semibold text-neutral-800 shadow-sm backdrop-blur transition-all hover:bg-neutral-100 dark:border-white/15 dark:bg-neutral-900/80 dark:text-neutral-200 dark:hover:bg-neutral-800" aria-label="Go to previous page"> <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <path d="m15 18-6-6 6-6"></path> </svg> <span>Previous</span> </a>` : renderTemplate`<span class="inline-flex cursor-not-allowed items-center gap-1 rounded-full border border-neutral-200 bg-neutral-100 px-3.5 py-1.5 text-xs font-semibold text-neutral-400 opacity-60 dark:border-white/5 dark:bg-neutral-900/40 dark:text-neutral-500" aria-disabled="true"> <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <path d="m15 18-6-6 6-6"></path> </svg> <span>Previous</span> </span>`}  <div class="flex items-center gap-1"> ${pageNumbers.map((p) => {
    if (p === "ellipsis") {
      return renderTemplate`<span class="px-2 py-1 text-xs font-bold text-neutral-400 dark:text-neutral-500">
…
</span>`;
    }
    const isCurrent = p === currentPage;
    return isCurrent ? renderTemplate`<span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-neutral-900 text-xs font-bold text-white shadow-sm dark:bg-white dark:text-neutral-950" aria-current="page"> ${p} </span>` : renderTemplate`<a${addAttribute(getPageUrl(p), "href")} class="inline-flex h-8 w-8 items-center justify-center rounded-full border border-neutral-300/80 bg-white/70 text-xs font-semibold text-neutral-700 transition-colors hover:border-neutral-400 hover:bg-white dark:border-white/15 dark:bg-neutral-900/60 dark:text-neutral-300 dark:hover:border-white/30 dark:hover:bg-neutral-800"${addAttribute(`Go to page ${p}`, "aria-label")}> ${p} </a>`;
  })} </div>  ${nextUrl ? renderTemplate`<a${addAttribute(nextUrl, "href")} class="inline-flex items-center gap-1 rounded-full border border-neutral-300/80 bg-white/80 px-3.5 py-1.5 text-xs font-semibold text-neutral-800 shadow-sm backdrop-blur transition-all hover:bg-neutral-100 dark:border-white/15 dark:bg-neutral-900/80 dark:text-neutral-200 dark:hover:bg-neutral-800" aria-label="Go to next page"> <span>Next</span> <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <path d="m9 18 6-6-6-6"></path> </svg> </a>` : renderTemplate`<span class="inline-flex cursor-not-allowed items-center gap-1 rounded-full border border-neutral-200 bg-neutral-100 px-3.5 py-1.5 text-xs font-semibold text-neutral-400 opacity-60 dark:border-white/5 dark:bg-neutral-900/40 dark:text-neutral-500" aria-disabled="true"> <span>Next</span> <svg class="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"> <path d="m9 18 6-6-6-6"></path> </svg> </span>`} </div> </nav>`;
}, "C:/Users/ep/dev/portfolio2026/src/components/blog/Pagination.astro", void 0);

export { $$Pagination as $ };
