import { jsxs, jsx } from 'react/jsx-runtime';
import { useState } from 'react';
import { motion } from 'framer-motion';
import clsx from 'clsx';

function PortfolioFilter({
  categories,
  category: initialCategory,
  onCategoryChange
}) {
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const filterPortfolio = (category) => {
    setSelectedCategory(category);
    if (onCategoryChange) {
      onCategoryChange(category);
    }
    const portfolioCards = document.querySelectorAll("[data-categories]");
    portfolioCards.forEach((card) => {
      const categories2 = JSON.parse(card.getAttribute("data-categories") || "[]");
      if (category === "all" || categories2.includes(category)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-wrap gap-4", children: [
    /* @__PURE__ */ jsx(
      motion.button,
      {
        onClick: () => filterPortfolio("all"),
        className: clsx(
          "clip2 rounded px-4 py-2 transition-colors",
          selectedCategory === "all" ? "bg-primary-500 text-black" : "text-light bg-neutral-800/50"
        ),
        whileHover: { scale: 1.05 },
        whileTap: { scale: 0.95 },
        "aria-label": "Show all categories",
        children: "All"
      }
    ),
    categories.map((category) => /* @__PURE__ */ jsx(
      motion.button,
      {
        onClick: () => filterPortfolio(category),
        className: clsx(
          "clip2 rounded px-4 py-2 transition-colors",
          selectedCategory === category ? "bg-primary-500 text-black" : "text-light bg-neutral-800/50"
        ),
        whileHover: { scale: 1.05 },
        whileTap: { scale: 0.95 },
        "aria-label": `Filter by ${category}`,
        children: category
      },
      category
    ))
  ] });
}

export { PortfolioFilter as P };
