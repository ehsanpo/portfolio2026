const seniorEngineer = new Proxy({"src":"/_astro/Senior Software Engineer.MAB9Tk-B.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Senior Software Engineer.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Senior Software Engineer.png");
							return target[name];
						}
					});

const productEngineer = new Proxy({"src":"/_astro/Product Engineer.DRQX7Zwg.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Product Engineer.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Product Engineer.png");
							return target[name];
						}
					});

const engineeringManager = new Proxy({"src":"/_astro/Engineering Manage.D-RPbemS.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Engineering Manage.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Engineering Manage.png");
							return target[name];
						}
					});

const devops = new Proxy({"src":"/_astro/devops.D_P5e_z2.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/devops.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/devops.png");
							return target[name];
						}
					});

const musicProduction = new Proxy({"src":"/_astro/Music Production.DS15CIZm.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Music Production.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/roles/Music Production.png");
							return target[name];
						}
					});

const imageMap = {
  "/img/roles/Senior Software Engineer.png": seniorEngineer,
  "/img/roles/Product Engineer.png": productEngineer,
  "/img/roles/Engineering Manage.png": engineeringManager,
  "/img/roles/devops.png": devops,
  "/img/roles/Music Production.png": musicProduction
};
function getRoleImage(imagePath) {
  return imageMap[imagePath];
}

export { getRoleImage as g };
