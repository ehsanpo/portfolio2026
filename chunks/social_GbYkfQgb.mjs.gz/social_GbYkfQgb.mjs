import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { useState, useRef, useMemo, useEffect } from 'react';
import { ArrowUpDown, ExternalLink, ChevronLeft, ChevronRight, Grid3X3, Check, Copy, X, Link2, ChevronUp, ChevronDown, Play, ImageIcon, Star, GitFork, Pause, RotateCcw, VolumeX, Volume2, Minimize, Maximize } from 'lucide-react';
import Masonry from 'react-layout-masonry';
import { a as getCollection } from './Layout_DoRYXERu.mjs';

const WHEEL_LOCK_MS = 260;
const SWIPE_THRESHOLD = 50;
const postTypeLabel = {
  image: "Image",
  video: "Video",
  link: "Link",
  tiktok: "TikTok",
  github: "GitHub"
};
const GitHubIcon = ({ className = "h-4 w-4" }) => /* @__PURE__ */ jsx(
  "svg",
  {
    className,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    children: /* @__PURE__ */ jsx("path", { d: "M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" })
  }
);
const TikTokIcon = ({ className = "h-4 w-4" }) => /* @__PURE__ */ jsx(
  "svg",
  {
    className,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true",
    children: /* @__PURE__ */ jsx("path", { d: "M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298-.002.595.042.88.13V9.4a6.33 6.33 0 0 0-1-.08A6.34 6.34 0 0 0 3 15.66a6.34 6.34 0 0 0 10.82 4.46 6.27 6.27 0 0 0 1.88-4.48V8.33a8.27 8.27 0 0 0 4.89 1.57V6.69z" })
  }
);
const getPostIcon = (kind) => {
  if (kind === "video") return Play;
  if (kind === "link") return Link2;
  if (kind === "tiktok") return TikTokIcon;
  if (kind === "github") return GitHubIcon;
  return ImageIcon;
};
const fallbackGradient = "bg-linear-to-br from-secondary-700 via-accent-700 to-primary-500 dark:from-secondary-900 dark:via-accent-900 dark:to-primary-800";
const formatTime = (timeInSeconds) => {
  if (Number.isNaN(timeInSeconds) || !Number.isFinite(timeInSeconds)) return "0:00";
  const mins = Math.floor(timeInSeconds / 60);
  const secs = Math.floor(timeInSeconds % 60);
  return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
};
const formatNumber = (num) => {
  if (typeof num !== "number") return null;
  if (num >= 1e3) {
    return `${(num / 1e3).toFixed(1).replace(/\.0$/, "")}k`;
  }
  return num.toLocaleString();
};
const getSlugFromPath = () => {
  if (typeof window === "undefined") return null;
  const parts = window.location.pathname.split("/").filter(Boolean);
  if (parts[0] !== "social") return null;
  if (parts.length < 2) return null;
  return decodeURIComponent(parts[1]);
};
const setPath = (pathname, mode = "push") => {
  if (typeof window === "undefined") return;
  const target = pathname.startsWith("/") ? pathname : `/${pathname}`;
  if (mode === "replace") {
    window.history.replaceState({}, "", target);
    return;
  }
  window.history.pushState({}, "", target);
};
const formatPostDate = (value) => {
  if (!value) return null;
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) return value;
  return new Intl.DateTimeFormat(void 0, {
    year: "numeric",
    month: "short",
    day: "numeric"
  }).format(new Date(parsed));
};
function FeedVideoPlayer({ src, title, poster }) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showCenterIcon, setShowCenterIcon] = useState(null);
  const [showControls, setShowControls] = useState(true);
  const hideTimerRef = useRef(null);
  const pokeControls = () => {
    setShowControls(true);
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = window.setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) {
        setShowControls(false);
      }
    }, 3500);
  };
  const triggerCenterFeedback = (action) => {
    setShowCenterIcon(action);
    window.setTimeout(() => setShowCenterIcon(null), 500);
  };
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => {
        setIsPlaying(true);
        triggerCenterFeedback("play");
      }).catch(() => {
      });
    } else {
      video.pause();
      setIsPlaying(false);
      triggerCenterFeedback("pause");
    }
    pokeControls();
  };
  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const nextMuted = !video.muted;
    video.muted = nextMuted;
    setIsMuted(nextMuted);
    if (!nextMuted && video.volume === 0) {
      video.volume = 0.8;
      setVolume(0.8);
    }
    pokeControls();
  };
  const handleSeek = (e) => {
    const video = videoRef.current;
    if (!video) return;
    const targetTime = Number(e.target.value);
    video.currentTime = targetTime;
    setCurrentTime(targetTime);
    pokeControls();
  };
  const handleVolume = (e) => {
    const video = videoRef.current;
    if (!video) return;
    const val = Number(e.target.value);
    video.volume = val;
    setVolume(val);
    if (val === 0) {
      video.muted = true;
      setIsMuted(true);
    } else if (isMuted) {
      video.muted = false;
      setIsMuted(false);
    }
    pokeControls();
  };
  const toggleFullscreen = () => {
    const container = containerRef.current || videoRef.current;
    if (!container) return;
    if (!document.fullscreenElement) {
      container.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {
      });
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {
      });
    }
    pokeControls();
  };
  const restart = () => {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = 0;
    video.play().then(() => setIsPlaying(true)).catch(() => {
    });
    pokeControls();
  };
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTimeUpdate = () => setCurrentTime(video.currentTime);
    const onLoadedMetadata = () => {
      setDuration(video.duration);
      video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    };
    const onEnded = () => setIsPlaying(false);
    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("loadedmetadata", onLoadedMetadata);
    video.addEventListener("ended", onEnded);
    pokeControls();
    return () => {
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("loadedmetadata", onLoadedMetadata);
      video.removeEventListener("ended", onEnded);
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
  }, [src]);
  useEffect(() => {
    const onFullscreenChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);
  const progressPercent = duration > 0 ? currentTime / duration * 100 : 0;
  return /* @__PURE__ */ jsxs(
    "div",
    {
      ref: containerRef,
      className: "group relative h-full w-full bg-black select-none",
      onMouseMove: pokeControls,
      onTouchStart: pokeControls,
      children: [
        /* @__PURE__ */ jsx(
          "video",
          {
            ref: videoRef,
            src,
            poster,
            className: "h-full w-full object-cover cursor-pointer",
            autoPlay: true,
            loop: true,
            muted: isMuted,
            playsInline: true,
            preload: "metadata",
            onClick: togglePlay,
            "aria-label": title
          }
        ),
        showCenterIcon && /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsx("div", { className: "flex h-16 w-16 items-center justify-center rounded-full bg-black/70 text-white backdrop-blur-md", children: showCenterIcon === "play" ? /* @__PURE__ */ jsx(Play, { className: "h-8 w-8 translate-x-0.5 fill-white" }) : /* @__PURE__ */ jsx(Pause, { className: "h-8 w-8 fill-white" }) }) }),
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: `absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-3 pt-8 transition-opacity duration-300 ${showControls ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`,
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxs("div", { className: "relative mb-2.5 flex items-center", children: [
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "range",
                    min: 0,
                    max: duration || 100,
                    step: 0.1,
                    value: currentTime,
                    onChange: handleSeek,
                    className: "h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/25 accent-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white",
                    "aria-label": "Seek video"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    className: "pointer-events-none absolute left-0 top-0 h-1.5 rounded-full bg-white",
                    style: { width: `${progressPercent}%` }
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between text-xs text-white", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:gap-2", children: [
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      type: "button",
                      onClick: togglePlay,
                      className: "rounded-full p-1.5 text-white transition-colors hover:bg-white/20 focus-visible:ring-2 focus-visible:ring-white",
                      "aria-label": isPlaying ? "Pause video" : "Play video",
                      children: isPlaying ? /* @__PURE__ */ jsx(Pause, { className: "h-4 w-4 fill-white" }) : /* @__PURE__ */ jsx(Play, { className: "h-4 w-4 fill-white translate-x-0.5" })
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "button",
                    {
                      type: "button",
                      onClick: restart,
                      className: "rounded-full p-1.5 text-white/80 transition-colors hover:bg-white/20 hover:text-white",
                      "aria-label": "Restart video",
                      title: "Restart",
                      children: /* @__PURE__ */ jsx(RotateCcw, { className: "h-3.5 w-3.5" })
                    }
                  ),
                  /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsx(
                      "button",
                      {
                        type: "button",
                        onClick: toggleMute,
                        className: "rounded-full p-1.5 text-white transition-colors hover:bg-white/20",
                        "aria-label": isMuted ? "Unmute audio" : "Mute audio",
                        children: isMuted || volume === 0 ? /* @__PURE__ */ jsx(VolumeX, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Volume2, { className: "h-4 w-4" })
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "range",
                        min: 0,
                        max: 1,
                        step: 0.05,
                        value: isMuted ? 0 : volume,
                        onChange: handleVolume,
                        className: "hidden sm:inline-block h-1 w-14 cursor-pointer appearance-none rounded bg-white/30 accent-white",
                        "aria-label": "Volume slider"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("span", { className: "font-mono text-[11px] text-white/80 ml-1", children: [
                    formatTime(currentTime),
                    " / ",
                    formatTime(duration)
                  ] })
                ] }),
                /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsx(
                  "button",
                  {
                    type: "button",
                    onClick: toggleFullscreen,
                    className: "rounded-full p-1.5 text-white/80 transition-colors hover:bg-white/20 hover:text-white",
                    "aria-label": isFullscreen ? "Exit fullscreen" : "Enter fullscreen",
                    children: isFullscreen ? /* @__PURE__ */ jsx(Minimize, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Maximize, { className: "h-4 w-4" })
                  }
                ) })
              ] })
            ]
          }
        )
      ]
    }
  );
}
const renderPostMedia = (post, mode) => {
  const Icon = getPostIcon(post.kind);
  const fallback = /* @__PURE__ */ jsx(
    "div",
    {
      className: `flex h-full w-full items-center justify-center ${fallbackGradient} text-white`,
      "aria-label": `${post.title} placeholder`,
      children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-3 p-4 text-center", children: [
        /* @__PURE__ */ jsx(Icon, { className: "h-10 w-10 opacity-90" }),
        /* @__PURE__ */ jsx("span", { className: "px-4 text-sm font-semibold", children: post.title })
      ] })
    }
  );
  if (post.kind === "tiktok") {
    if (mode === "grid") {
      return /* @__PURE__ */ jsxs("div", { className: "relative h-full w-full bg-black", children: [
        post.mediaUrl ? /* @__PURE__ */ jsx(
          "img",
          {
            src: post.mediaUrl,
            alt: "",
            className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105",
            loading: "lazy"
          }
        ) : /* @__PURE__ */ jsx("div", { className: `flex h-full w-full items-center justify-center ${fallbackGradient}`, children: /* @__PURE__ */ jsx(TikTokIcon, { className: "h-10 w-10 text-white" }) }),
        /* @__PURE__ */ jsx("div", { className: "absolute inset-0 flex items-center justify-center bg-black/20 transition-colors group-hover:bg-black/35", children: /* @__PURE__ */ jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-full border border-white/30 bg-black/60 text-white backdrop-blur-sm transition-transform group-hover:scale-110 shadow-lg", children: /* @__PURE__ */ jsx(Play, { className: "h-5 w-5 translate-x-0.5 fill-white" }) }) }),
        /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute top-3 left-3 z-10", children: /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-pink-500/30 bg-black/60 backdrop-blur-md px-2.5 py-0.5 text-[10px] font-semibold tracking-wide uppercase text-pink-300", children: [
          /* @__PURE__ */ jsx(TikTokIcon, { className: "h-3 w-3 fill-current" }),
          "TikTok"
        ] }) })
      ] });
    }
    return /* @__PURE__ */ jsx("div", { className: "relative h-full w-full bg-black", children: post.embedUrl ? /* @__PURE__ */ jsx(
      "iframe",
      {
        src: post.embedUrl,
        title: post.title,
        className: "h-full w-full border-0 bg-black",
        allowFullScreen: true,
        allow: "autoplay; fullscreen",
        loading: "lazy"
      }
    ) : post.mediaUrl ? /* @__PURE__ */ jsx("img", { src: post.mediaUrl, alt: "", className: "h-full w-full object-cover" }) : /* @__PURE__ */ jsx("div", { className: "flex h-full w-full items-center justify-center bg-black", children: /* @__PURE__ */ jsx(TikTokIcon, { className: "h-12 w-12 text-white" }) }) });
  }
  if (post.kind === "github") {
    if (mode === "grid") {
      return /* @__PURE__ */ jsxs("div", { className: "relative flex h-full w-full flex-col justify-between overflow-hidden bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 p-3.5 sm:p-4 text-white", children: [
        /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute -right-6 -bottom-6 opacity-[0.06] text-white", children: /* @__PURE__ */ jsx(GitHubIcon, { className: "h-32 w-32" }) }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 space-y-1.5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase text-white", children: [
              /* @__PURE__ */ jsx(GitHubIcon, { className: "h-3 w-3" }),
              "GitHub Star"
            ] }),
            post.href && /* @__PURE__ */ jsx(
              "a",
              {
                href: post.href,
                target: "_blank",
                rel: "noreferrer",
                onClick: (e) => e.stopPropagation(),
                className: "rounded-full border border-white/15 bg-white/5 p-1 text-neutral-300 transition-colors hover:border-white/40 hover:bg-white/15 hover:text-white",
                "aria-label": `Open ${post.title} on GitHub`,
                title: "Open repository",
                children: /* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h4", { className: "line-clamp-1 sm:line-clamp-2 text-xs sm:text-sm font-bold text-white transition-colors group-hover:text-primary-300", children: post.title }),
            /* @__PURE__ */ jsx("p", { className: "mt-1 line-clamp-2 text-[11px] sm:text-xs leading-relaxed text-neutral-300", children: post.caption })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 mt-2 flex items-center justify-between gap-1.5 border-t border-white/10 pt-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
            typeof post.stars === "number" && /* @__PURE__ */ jsxs(
              "span",
              {
                className: "inline-flex items-center gap-1 rounded-md border border-amber-400/30 bg-amber-400/10 px-1.5 py-0.5 text-[11px] font-semibold text-amber-300",
                title: `${post.stars.toLocaleString()} stars`,
                children: [
                  /* @__PURE__ */ jsx(Star, { className: "h-3 w-3 fill-amber-400 text-amber-400" }),
                  formatNumber(post.stars)
                ]
              }
            ),
            typeof post.forks === "number" && /* @__PURE__ */ jsxs(
              "span",
              {
                className: "inline-flex items-center gap-1 rounded-md border border-sky-400/30 bg-sky-400/10 px-1.5 py-0.5 text-[11px] font-semibold text-sky-300",
                title: `${post.forks.toLocaleString()} forks`,
                children: [
                  /* @__PURE__ */ jsx(GitFork, { className: "h-3 w-3 text-sky-400" }),
                  formatNumber(post.forks)
                ]
              }
            )
          ] }),
          post.href && /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-0.5 text-[10px] font-medium text-neutral-400 transition-colors group-hover:text-white", children: [
            "Repo",
            /* @__PURE__ */ jsx(ChevronRight, { className: "h-3 w-3" })
          ] })
        ] })
      ] });
    }
    return /* @__PURE__ */ jsxs("div", { className: "relative flex h-full w-full flex-col justify-between overflow-hidden bg-gradient-to-b from-neutral-900 via-neutral-950 to-black p-5 sm:p-6 text-white", children: [
      /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute -right-10 -top-10 opacity-[0.05] text-white", children: /* @__PURE__ */ jsx(GitHubIcon, { className: "h-56 w-56" }) }),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 space-y-3.5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-white", children: [
            /* @__PURE__ */ jsx(GitHubIcon, { className: "h-3.5 w-3.5" }),
            "Starred Repository"
          ] }),
          post.date && /* @__PURE__ */ jsx("span", { className: "text-xs text-neutral-400", children: formatPostDate(post.date) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-basement text-xl sm:text-2xl leading-snug text-white", children: post.title }),
          /* @__PURE__ */ jsx("p", { className: "line-clamp-3 text-xs sm:text-sm leading-relaxed text-neutral-300", children: post.caption })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2.5 pt-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5 rounded-2xl border border-amber-400/25 bg-amber-400/10 p-3 backdrop-blur-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400/20 text-amber-300", children: /* @__PURE__ */ jsx(Star, { className: "h-4 w-4 fill-amber-400 text-amber-400" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "text-base font-bold text-white", children: typeof post.stars === "number" ? post.stars.toLocaleString() : "—" }),
              /* @__PURE__ */ jsx("div", { className: "text-[11px] font-medium text-amber-300/90", children: "Stars" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5 rounded-2xl border border-sky-400/25 bg-sky-400/10 p-3 backdrop-blur-sm", children: [
            /* @__PURE__ */ jsx("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-400/20 text-sky-300", children: /* @__PURE__ */ jsx(GitFork, { className: "h-4 w-4 text-sky-400" }) }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("div", { className: "text-base font-bold text-white", children: typeof post.forks === "number" ? post.forks.toLocaleString() : "—" }),
              /* @__PURE__ */ jsx("div", { className: "text-[11px] font-medium text-sky-300/90", children: "Forks" })
            ] })
          ] })
        ] })
      ] }),
      post.href && /* @__PURE__ */ jsx("div", { className: "relative z-10 mt-3 border-t border-white/10 pt-3", children: /* @__PURE__ */ jsxs(
        "a",
        {
          href: post.href,
          target: "_blank",
          rel: "noreferrer",
          className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-xs sm:text-sm font-bold text-neutral-950 shadow-lg transition-transform hover:scale-[1.02] hover:bg-neutral-100",
          children: [
            /* @__PURE__ */ jsx(GitHubIcon, { className: "h-4 w-4" }),
            post.ctaLabel || "View Repository on GitHub",
            /* @__PURE__ */ jsx(ExternalLink, { className: "h-3.5 w-3.5 opacity-75" })
          ]
        }
      ) })
    ] });
  }
  if (post.kind === "link" && !post.mediaUrl) {
    const domain = post.href ? (() => {
      try {
        return new URL(post.href).hostname.replace(/^www\./, "");
      } catch {
        return null;
      }
    })() : null;
    if (mode === "grid") {
      return /* @__PURE__ */ jsxs("div", { className: "relative flex h-full w-full flex-col justify-between overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 p-3.5 sm:p-4 text-white", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 space-y-1.5", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase text-white", children: [
              /* @__PURE__ */ jsx(Link2, { className: "h-3 w-3" }),
              "Link"
            ] }),
            post.href && /* @__PURE__ */ jsx(
              "a",
              {
                href: post.href,
                target: "_blank",
                rel: "noreferrer",
                onClick: (e) => e.stopPropagation(),
                className: "rounded-full border border-white/15 bg-white/5 p-1 text-neutral-300 transition-colors hover:border-white/40 hover:bg-white/15 hover:text-white",
                "aria-label": `Open ${post.title}`,
                title: post.ctaLabel || "Open link",
                children: /* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h4", { className: "line-clamp-1 sm:line-clamp-2 text-xs sm:text-sm font-bold text-white transition-colors group-hover:text-primary-300", children: post.title }),
            /* @__PURE__ */ jsx("p", { className: "mt-1 line-clamp-2 text-[11px] sm:text-xs leading-relaxed text-neutral-300", children: post.caption })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "relative z-10 mt-2 flex items-center justify-between gap-1.5 border-t border-white/10 pt-2", children: [
          domain && /* @__PURE__ */ jsx("span", { className: "truncate max-w-[150px] font-mono text-[11px] text-neutral-400", children: domain }),
          post.href && /* @__PURE__ */ jsxs("span", { className: "ml-auto flex items-center gap-0.5 text-[10px] font-medium text-neutral-400 transition-colors group-hover:text-white", children: [
            post.ctaLabel || "Visit",
            /* @__PURE__ */ jsx(ChevronRight, { className: "h-3 w-3" })
          ] })
        ] })
      ] });
    }
    return /* @__PURE__ */ jsxs("div", { className: "relative flex h-full w-full flex-col justify-between overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-950 to-black p-5 sm:p-6 text-white", children: [
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 space-y-3.5", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-white", children: [
            /* @__PURE__ */ jsx(Link2, { className: "h-3.5 w-3.5" }),
            "Link Resource"
          ] }),
          post.date && /* @__PURE__ */ jsx("span", { className: "text-xs text-neutral-400", children: formatPostDate(post.date) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-1.5", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-basement text-xl sm:text-2xl leading-snug text-white", children: post.title }),
          /* @__PURE__ */ jsx("p", { className: "line-clamp-3 text-xs sm:text-sm leading-relaxed text-neutral-300", children: post.caption }),
          domain && /* @__PURE__ */ jsx("p", { className: "font-mono text-xs text-primary-400 pt-1", children: domain })
        ] })
      ] }),
      post.href && /* @__PURE__ */ jsx("div", { className: "relative z-10 mt-3 border-t border-white/10 pt-3", children: /* @__PURE__ */ jsxs(
        "a",
        {
          href: post.href,
          target: "_blank",
          rel: "noreferrer",
          className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-xs sm:text-sm font-bold text-neutral-950 shadow-lg transition-transform hover:scale-[1.02] hover:bg-neutral-100",
          children: [
            /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" }),
            post.ctaLabel || "Open Link"
          ]
        }
      ) })
    ] });
  }
  if (!post.mediaUrl) {
    return fallback;
  }
  if (post.kind === "video") {
    if (mode === "feed") {
      return /* @__PURE__ */ jsx(FeedVideoPlayer, { src: post.mediaUrl, title: post.title, poster: post.poster });
    }
    return /* @__PURE__ */ jsxs("div", { className: "relative h-full w-full bg-black", children: [
      post.poster ? /* @__PURE__ */ jsx(
        "img",
        {
          src: post.poster,
          alt: post.title,
          className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105",
          loading: "lazy",
          onError: (e) => {
            e.target.style.display = "none";
          }
        }
      ) : /* @__PURE__ */ jsx(
        "video",
        {
          src: `${post.mediaUrl}#t=0.001`,
          className: "h-full w-full object-cover",
          muted: true,
          playsInline: true,
          preload: "metadata"
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "absolute inset-0 flex items-center justify-center bg-black/20 transition-colors group-hover:bg-black/35", children: /* @__PURE__ */ jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-full border border-white/30 bg-black/60 text-white backdrop-blur-sm transition-transform group-hover:scale-110 shadow-lg", children: /* @__PURE__ */ jsx(Play, { className: "h-5 w-5 translate-x-0.5 fill-white" }) }) })
    ] });
  }
  return /* @__PURE__ */ jsx("img", { src: post.mediaUrl, alt: post.title, className: "h-full w-full object-cover" });
};
function SocialGridFeed({
  posts,
  initialPostSlug,
  startInFeed = false,
  postsPerPage = 16
}) {
  const [activeIndex, setActiveIndex] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [sortOrder, setSortOrder] = useState("desc");
  const [copied, setCopied] = useState(false);
  const gridTopRef = useRef(null);
  const wheelLockedRef = useRef(false);
  const touchStartYRef = useRef(null);
  const filterCounts = useMemo(() => {
    const res = {
      all: posts.length,
      github: 0,
      video: 0,
      image: 0,
      link: 0,
      tiktok: 0
    };
    posts.forEach((p) => {
      if (res[p.kind] !== void 0) res[p.kind]++;
    });
    return res;
  }, [posts]);
  const filteredPosts = useMemo(() => {
    let list = selectedFilter === "all" ? posts : posts.filter((p) => p.kind === selectedFilter);
    if (sortOrder === "asc") {
      return [...list].reverse();
    }
    return list;
  }, [posts, selectedFilter, sortOrder]);
  const totalPages = Math.max(1, Math.ceil(filteredPosts.length / postsPerPage));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const paginatedPosts = useMemo(() => {
    const start = (safeCurrentPage - 1) * postsPerPage;
    return filteredPosts.slice(start, start + postsPerPage);
  }, [filteredPosts, safeCurrentPage, postsPerPage]);
  const handlePageChange = (p) => {
    if (p < 1 || p > totalPages || p === safeCurrentPage) return;
    setCurrentPage(p);
    gridTopRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    if (totalPages <= maxVisible + 2) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
      return pages;
    }
    pages.push(1);
    const left = Math.max(2, safeCurrentPage - 1);
    const right = Math.min(totalPages - 1, safeCurrentPage + 1);
    if (left > 2) pages.push("ellipsis");
    for (let i = left; i <= right; i++) pages.push(i);
    if (right < totalPages - 1) pages.push("ellipsis");
    pages.push(totalPages);
    return pages;
  };
  const activePost = activeIndex === null ? null : filteredPosts[activeIndex] ?? null;
  const closeFeed = (mode = "push") => {
    setActiveIndex(null);
    setPath("/social", mode);
  };
  const openFeedAt = (indexOnPage, mode = "push") => {
    const globalIndex = (safeCurrentPage - 1) * postsPerPage + indexOnPage;
    if (globalIndex < 0 || globalIndex >= filteredPosts.length) return;
    setActiveIndex(globalIndex);
    setPath(`/social/${filteredPosts[globalIndex].slug}`, mode);
  };
  const navigate = (direction) => {
    if (activeIndex === null) return;
    const nextIndex = Math.max(0, Math.min(filteredPosts.length - 1, activeIndex + direction));
    if (nextIndex === activeIndex) return;
    setActiveIndex(nextIndex);
    setPath(`/social/${filteredPosts[nextIndex].slug}`, "push");
  };
  const handleWheel = (event) => {
    event.preventDefault();
    if (wheelLockedRef.current) return;
    if (Math.abs(event.deltaY) < 20) return;
    navigate(event.deltaY > 0 ? 1 : -1);
    wheelLockedRef.current = true;
    window.setTimeout(() => {
      wheelLockedRef.current = false;
    }, WHEEL_LOCK_MS);
  };
  const handleTouchStart = (event) => {
    touchStartYRef.current = event.changedTouches[0]?.clientY ?? null;
  };
  const handleTouchEnd = (event) => {
    if (touchStartYRef.current === null) return;
    const touchEndY = event.changedTouches[0]?.clientY ?? touchStartYRef.current;
    const delta = touchStartYRef.current - touchEndY;
    touchStartYRef.current = null;
    if (Math.abs(delta) < SWIPE_THRESHOLD) return;
    navigate(delta > 0 ? 1 : -1);
  };
  const copyCurrentUrl = () => {
    if (!activePost) return;
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2e3);
    });
  };
  useEffect(() => {
    if (!filteredPosts.length) return;
    const pathSlug = getSlugFromPath();
    const preferredSlug = pathSlug || initialPostSlug || null;
    if (!preferredSlug) {
      setActiveIndex(startInFeed ? 0 : null);
      return;
    }
    const nextIndex = filteredPosts.findIndex((post) => post.slug === preferredSlug);
    if (nextIndex !== -1) {
      setActiveIndex(nextIndex);
      return;
    }
    if (startInFeed) {
      setActiveIndex(0);
      setPath(`/social/${filteredPosts[0].slug}`, "replace");
    }
  }, [filteredPosts, initialPostSlug, startInFeed]);
  useEffect(() => {
    const onPopState = () => {
      const pathSlug = getSlugFromPath();
      if (!pathSlug) {
        setActiveIndex(null);
        return;
      }
      const nextIndex = filteredPosts.findIndex((post) => post.slug === pathSlug);
      if (nextIndex !== -1) {
        setActiveIndex(nextIndex);
      }
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [filteredPosts]);
  useEffect(() => {
    if (activeIndex === null) return;
    const onKeyDown = (event) => {
      if (event.key === "Escape") closeFeed("push");
      if (event.key === "ArrowDown" || event.key.toLowerCase() === "j") navigate(1);
      if (event.key === "ArrowUp" || event.key.toLowerCase() === "k") navigate(-1);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activeIndex, filteredPosts]);
  useEffect(() => {
    if (activeIndex === null) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [activeIndex]);
  if (!posts.length) {
    return /* @__PURE__ */ jsx("div", { className: "rounded-2xl border border-black/10 p-8 text-center dark:border-white/10", children: /* @__PURE__ */ jsx("p", { className: "text-neutral-600 dark:text-neutral-300", children: "No social posts added yet." }) });
  }
  const filterKeys = ["all", "github", "video", "image", "link", "tiktok"];
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("div", { ref: gridTopRef, className: "scroll-mt-8" }),
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsx("div", { className: "flex flex-wrap items-center gap-2", role: "tablist", "aria-label": "Filter posts by type", children: filterKeys.filter((key) => key === "all" || filterCounts[key] > 0).map((key) => {
        const isSelected = selectedFilter === key;
        const label = key === "all" ? "All" : postTypeLabel[key];
        const count = filterCounts[key];
        return /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            role: "tab",
            "aria-selected": isSelected,
            onClick: () => {
              setSelectedFilter(key);
              setCurrentPage(1);
            },
            className: `inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all ${isSelected ? "bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-sm" : "border border-neutral-300/80 bg-white/70 text-neutral-700 hover:border-neutral-400 hover:bg-white dark:border-white/15 dark:bg-neutral-900/60 dark:text-neutral-300 dark:hover:border-white/30 dark:hover:bg-neutral-800"}`,
            children: [
              label,
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `rounded-full px-1.5 py-0.2 text-[10px] font-bold ${isSelected ? "bg-white/20 text-white dark:bg-black/15 dark:text-neutral-900" : "bg-neutral-200 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300"}`,
                  children: count
                }
              )
            ]
          },
          key
        );
      }) }),
      /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 self-start sm:self-auto", children: /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => {
            setSortOrder((curr) => curr === "desc" ? "asc" : "desc");
            setCurrentPage(1);
          },
          className: "inline-flex items-center gap-2 rounded-full border border-neutral-300/80 bg-white/80 px-3.5 py-1.5 text-xs font-semibold text-neutral-800 shadow-sm backdrop-blur transition-all hover:bg-neutral-100 dark:border-white/15 dark:bg-neutral-900/80 dark:text-neutral-200 dark:hover:bg-neutral-800",
          "aria-label": `Sort by date: currently ${sortOrder === "desc" ? "newest first" : "oldest first"}`,
          title: "Toggle date sort direction",
          children: [
            /* @__PURE__ */ jsx(ArrowUpDown, { className: "h-3.5 w-3.5 text-neutral-500 dark:text-neutral-400" }),
            /* @__PURE__ */ jsxs("span", { children: [
              "Date: ",
              sortOrder === "desc" ? "Newest First" : "Oldest First"
            ] })
          ]
        }
      ) })
    ] }),
    filteredPosts.length === 0 ? /* @__PURE__ */ jsxs("div", { className: "rounded-2xl border border-neutral-200 p-12 text-center dark:border-white/10", children: [
      /* @__PURE__ */ jsx("p", { className: "text-neutral-600 dark:text-neutral-300", children: "No posts found for this filter." }),
      /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          onClick: () => {
            setSelectedFilter("all");
            setCurrentPage(1);
          },
          className: "mt-4 rounded-full bg-neutral-900 px-4 py-2 text-xs font-semibold text-white dark:bg-white dark:text-neutral-950",
          children: "Show all posts"
        }
      )
    ] }) : (
      /* Responsive Masonry Layout */
      /* @__PURE__ */ jsx(
        Masonry,
        {
          columns: { 0: 2, 640: 2, 768: 3, 1024: 4 },
          gap: 16,
          columnProps: { className: "min-w-0" },
          children: paginatedPosts.map((post, index) => {
            const Icon = getPostIcon(post.kind);
            const isCompact = post.kind === "github" || post.kind === "link";
            return /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => openFeedAt(index, "push"),
                className: "group relative w-full overflow-hidden rounded-3xl border border-black/10 bg-black text-left shadow-md transition-all duration-200 hover:-translate-y-1 hover:shadow-xl dark:border-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-500",
                "aria-label": `Open ${post.title}`,
                children: [
                  /* @__PURE__ */ jsxs(
                    "div",
                    {
                      className: `overflow-hidden ${isCompact ? "aspect-[9/8]" : "aspect-[9/16]"}`,
                      children: [
                        renderPostMedia(post, "grid"),
                        post.kind === "link" && post.mediaUrl && /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-black/25" })
                      ]
                    }
                  ),
                  post.kind === "tiktok" ? /* @__PURE__ */ jsx("div", { className: "absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black via-black/80 to-transparent p-3.5 text-white", children: post.href && /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: post.href,
                      target: "_blank",
                      rel: "noreferrer",
                      onClick: (e) => e.stopPropagation(),
                      className: "inline-flex w-full items-center justify-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-bold text-neutral-950 shadow-md transition-all hover:bg-neutral-100 hover:scale-[1.02]",
                      children: [
                        /* @__PURE__ */ jsx(TikTokIcon, { className: "h-3.5 w-3.5 fill-current" }),
                        post.ctaLabel || "Watch on TikTok",
                        /* @__PURE__ */ jsx(ExternalLink, { className: "h-3 w-3 opacity-70" })
                      ]
                    }
                  ) }) : (
                    /* Bottom overlay for non-github, non-tiktok, and non-no-media-link posts */
                    post.kind !== "github" && !(post.kind === "link" && !post.mediaUrl) && /* @__PURE__ */ jsxs("div", { className: "absolute inset-x-0 bottom-0 space-y-1.5 bg-gradient-to-t from-black via-black/80 to-transparent p-3.5 text-white", children: [
                      /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full border border-white/25 bg-black/40 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", children: [
                        /* @__PURE__ */ jsx(Icon, { className: "h-3 w-3" }),
                        postTypeLabel[post.kind]
                      ] }) }),
                      /* @__PURE__ */ jsx("p", { className: "line-clamp-2 text-xs sm:text-sm font-semibold leading-snug text-white", children: post.title }),
                      post.date && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-white/70", children: formatPostDate(post.date) })
                    ] })
                  )
                ]
              },
              post.id
            );
          })
        }
      )
    ),
    totalPages > 1 && /* @__PURE__ */ jsxs(
      "nav",
      {
        "aria-label": "Social posts pagination",
        className: "mt-12 flex flex-col items-center justify-between gap-4 border-t border-black/10 pt-8 sm:flex-row dark:border-white/10",
        children: [
          /* @__PURE__ */ jsxs("p", { className: "text-xs text-neutral-500 dark:text-neutral-400", children: [
            "Page ",
            /* @__PURE__ */ jsx("span", { className: "font-semibold text-neutral-900 dark:text-white", children: safeCurrentPage }),
            " of",
            " ",
            /* @__PURE__ */ jsx("span", { className: "font-semibold text-neutral-900 dark:text-white", children: totalPages }),
            " (",
            filteredPosts.length,
            " posts)"
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handlePageChange(safeCurrentPage - 1),
                disabled: safeCurrentPage <= 1,
                "aria-label": "Previous page",
                className: "inline-flex h-9 items-center gap-1 rounded-full border border-neutral-300/80 bg-white/80 px-3 text-xs font-semibold text-neutral-700 shadow-sm backdrop-blur transition-all hover:bg-neutral-100 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/15 dark:bg-neutral-900/80 dark:text-neutral-300 dark:hover:bg-neutral-800",
                children: [
                  /* @__PURE__ */ jsx(ChevronLeft, { className: "h-4 w-4" }),
                  /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Previous" })
                ]
              }
            ),
            /* @__PURE__ */ jsx("div", { className: "flex items-center gap-1", children: getPageNumbers().map(
              (item, idx) => item === "ellipsis" ? /* @__PURE__ */ jsx(
                "span",
                {
                  className: "flex h-9 w-7 items-center justify-center text-xs font-bold text-neutral-400 dark:text-neutral-500",
                  children: "…"
                },
                `ellipsis-${idx}`
              ) : /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => handlePageChange(item),
                  "aria-current": item === safeCurrentPage ? "page" : void 0,
                  className: `flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold transition-all ${item === safeCurrentPage ? "bg-neutral-900 text-white shadow-sm dark:bg-white dark:text-neutral-950 font-bold" : "border border-neutral-300/80 bg-white/70 text-neutral-700 hover:border-neutral-400 hover:bg-white dark:border-white/15 dark:bg-neutral-900/60 dark:text-neutral-300 dark:hover:border-white/30 dark:hover:bg-neutral-800"}`,
                  children: item
                },
                item
              )
            ) }),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handlePageChange(safeCurrentPage + 1),
                disabled: safeCurrentPage >= totalPages,
                "aria-label": "Next page",
                className: "inline-flex h-9 items-center gap-1 rounded-full border border-neutral-300/80 bg-white/80 px-3 text-xs font-semibold text-neutral-700 shadow-sm backdrop-blur transition-all hover:bg-neutral-100 disabled:cursor-not-allowed disabled:opacity-40 dark:border-white/15 dark:bg-neutral-900/80 dark:text-neutral-300 dark:hover:bg-neutral-800",
                children: [
                  /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Next" }),
                  /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4" })
                ]
              }
            )
          ] })
        ]
      }
    ),
    activePost && activeIndex !== null && /* @__PURE__ */ jsxs(
      "div",
      {
        className: "fixed inset-0 z-[200] bg-black",
        onWheel: handleWheel,
        onTouchStart: handleTouchStart,
        onTouchEnd: handleTouchEnd,
        children: [
          /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute top-4 left-4 right-4 z-30 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => closeFeed("push"),
                className: "pointer-events-auto inline-flex items-center gap-2 rounded-full border border-white/25 bg-black/70 px-4 py-2 text-sm font-semibold text-white backdrop-blur-md transition-colors hover:bg-black/90 focus-visible:ring-2 focus-visible:ring-white",
                children: [
                  /* @__PURE__ */ jsx(Grid3X3, { className: "h-4 w-4" }),
                  "Back to grid"
                ]
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "pointer-events-auto flex items-center gap-2", children: [
              /* @__PURE__ */ jsxs(
                "button",
                {
                  type: "button",
                  onClick: copyCurrentUrl,
                  className: "inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-black/70 px-3.5 py-2 text-xs font-semibold text-white backdrop-blur-md transition-colors hover:bg-black/90 focus-visible:ring-2 focus-visible:ring-white",
                  "aria-label": "Copy share link",
                  title: "Copy share link",
                  children: [
                    copied ? /* @__PURE__ */ jsx(Check, { className: "h-4 w-4 text-emerald-400" }) : /* @__PURE__ */ jsx(Copy, { className: "h-4 w-4" }),
                    /* @__PURE__ */ jsx("span", { children: copied ? "Copied!" : "Share" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => closeFeed("push"),
                  className: "rounded-full border border-white/25 bg-black/70 p-2 text-white backdrop-blur-md transition-colors hover:bg-black/90 focus-visible:ring-2 focus-visible:ring-white",
                  "aria-label": "Close feed",
                  children: /* @__PURE__ */ jsx(X, { className: "h-5 w-5" })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 overflow-hidden", children: [
            activePost.poster || activePost.kind === "image" && activePost.mediaUrl ? /* @__PURE__ */ jsx(
              "img",
              {
                src: activePost.poster || activePost.mediaUrl,
                alt: "",
                "aria-hidden": "true",
                className: "h-full w-full scale-110 object-cover opacity-25 blur-3xl"
              }
            ) : /* @__PURE__ */ jsx("div", { "aria-hidden": "true", className: `h-full w-full ${fallbackGradient} opacity-20 blur-3xl` }),
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-black/75" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "relative flex h-full items-center justify-center p-4 sm:p-6", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: `relative w-full ${activePost.kind === "github" || activePost.kind === "link" ? "max-w-[480px]" : "max-w-[440px]"}`,
                children: /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: `relative overflow-hidden rounded-[2.25rem] border border-white/20 bg-neutral-950 shadow-[0_30px_90px_rgba(0,0,0,0.85)] ${activePost.kind === "github" || activePost.kind === "link" ? "aspect-[9/8] sm:aspect-[9/8]" : "aspect-[9/16]"}`,
                    children: [
                      renderPostMedia(activePost, "feed"),
                      activePost.kind === "tiktok" && /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 space-y-2 bg-gradient-to-t from-black via-black/80 to-transparent p-4 sm:p-5 text-white", children: [
                        /* @__PURE__ */ jsxs("div", { className: "pointer-events-auto flex items-center justify-between", children: [
                          /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-pink-500/30 bg-black/60 backdrop-blur-md px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-pink-300", children: [
                            /* @__PURE__ */ jsx(TikTokIcon, { className: "h-3.5 w-3.5 fill-current" }),
                            "TikTok"
                          ] }),
                          activePost.date && /* @__PURE__ */ jsx("div", { className: "text-xs text-white/80", children: formatPostDate(activePost.date) })
                        ] }),
                        activePost.href && /* @__PURE__ */ jsx("div", { className: "pointer-events-auto pt-1", children: /* @__PURE__ */ jsxs(
                          "a",
                          {
                            href: activePost.href,
                            target: "_blank",
                            rel: "noreferrer",
                            className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-4 py-2.5 text-xs sm:text-sm font-bold text-black shadow-lg transition-transform hover:scale-[1.02] hover:bg-neutral-200",
                            children: [
                              /* @__PURE__ */ jsx(TikTokIcon, { className: "h-4 w-4 fill-current" }),
                              activePost.ctaLabel || "Watch on TikTok",
                              /* @__PURE__ */ jsx(ExternalLink, { className: "h-3.5 w-3.5" })
                            ]
                          }
                        ) })
                      ] }),
                      activePost.kind !== "github" && activePost.kind !== "tiktok" && !(activePost.kind === "link" && !activePost.mediaUrl) && /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 space-y-2 bg-gradient-to-t from-black via-black/80 to-transparent p-4 sm:p-5 text-white", children: [
                        /* @__PURE__ */ jsxs("div", { className: "pointer-events-auto flex items-center justify-between", children: [
                          /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-black/50 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider", children: [
                            (() => {
                              const Icon = getPostIcon(activePost.kind);
                              return /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5" });
                            })(),
                            postTypeLabel[activePost.kind]
                          ] }),
                          /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
                            activePost.date && /* @__PURE__ */ jsx("div", { className: "text-xs text-white/80", children: formatPostDate(activePost.date) }),
                            /* @__PURE__ */ jsxs("div", { className: "text-[11px] text-white/60", children: [
                              activeIndex + 1,
                              " / ",
                              filteredPosts.length
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsx("h3", { className: "font-basement text-2xl leading-tight text-white", children: activePost.title }),
                        /* @__PURE__ */ jsx("p", { className: "line-clamp-3 text-sm leading-relaxed text-white/90", children: activePost.caption }),
                        /* @__PURE__ */ jsxs("div", { className: "pointer-events-auto flex flex-wrap gap-2 pt-1", children: [
                          activePost.permalink && /* @__PURE__ */ jsxs(
                            "a",
                            {
                              href: activePost.permalink,
                              className: "inline-flex items-center gap-1.5 rounded-full border border-white/30 bg-black/50 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-black/75",
                              children: [
                                "Post Link",
                                /* @__PURE__ */ jsx(Link2, { className: "h-3.5 w-3.5" })
                              ]
                            }
                          ),
                          activePost.href && /* @__PURE__ */ jsxs(
                            "a",
                            {
                              href: activePost.href,
                              target: "_blank",
                              rel: "noreferrer",
                              className: "inline-flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-black transition-colors hover:bg-neutral-200",
                              children: [
                                activePost.ctaLabel ?? "Open Link",
                                /* @__PURE__ */ jsx(ExternalLink, { className: "h-3.5 w-3.5" })
                              ]
                            }
                          )
                        ] })
                      ] })
                    ]
                  }
                )
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 flex-col gap-3 sm:flex", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => navigate(-1),
                  disabled: activeIndex <= 0,
                  className: "pointer-events-auto rounded-full border border-white/25 bg-black/60 p-3 text-white transition-colors hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-30 focus-visible:ring-2 focus-visible:ring-white",
                  "aria-label": "Previous post",
                  title: "Previous (or press ↑)",
                  children: /* @__PURE__ */ jsx(ChevronUp, { className: "h-6 w-6" })
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => navigate(1),
                  disabled: activeIndex >= filteredPosts.length - 1,
                  className: "pointer-events-auto rounded-full border border-white/25 bg-black/60 p-3 text-white transition-colors hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-30 focus-visible:ring-2 focus-visible:ring-white",
                  "aria-label": "Next post",
                  title: "Next (or press ↓)",
                  children: /* @__PURE__ */ jsx(ChevronDown, { className: "h-6 w-6" })
                }
              )
            ] })
          ] })
        ]
      }
    )
  ] });
}

const fallbackGitHubStars = [
	{
		full_name: "mvt-project/mvt",
		html_url: "https://github.com/mvt-project/mvt",
		description: "MVT (Mobile Verification Toolkit) helps with conducting forensics of mobile devices in order to find signs of a potential compromise.",
		stargazers_count: 15315,
		forks_count: 1460,
		starred_at: "2026-10-11T12:40:41Z",
		updated_at: "2026-10-11T12:40:41Z",
		fork: false
	},
	{
		full_name: "humanwhocodes/crosspost",
		html_url: "https://github.com/humanwhocodes/crosspost",
		description: "A JavaScript utility for posting across multiple social networks at once",
		stargazers_count: 577,
		forks_count: 28,
		starred_at: "2026-10-11T00:22:14Z",
		updated_at: "2026-10-11T00:22:14Z",
		fork: false
	},
	{
		full_name: "benoitpetit/signal-sdk",
		html_url: "https://github.com/benoitpetit/signal-sdk",
		description: "A comprehensive TypeScript SDK for interacting with signal messenger, providing JSON-RPC communication and a powerful bot framework.",
		stargazers_count: 25,
		forks_count: 4,
		starred_at: "2026-10-07T20:42:58Z",
		updated_at: "2026-10-07T20:42:58Z",
		fork: false
	},
	{
		full_name: "LeanerCloud/dotclaude",
		html_url: "https://github.com/LeanerCloud/dotclaude",
		description: "Global Claude Code configuration: CLAUDE.md, coding standards, conventions, workflow docs, and agent definitions",
		stargazers_count: 14,
		forks_count: 0,
		starred_at: "2026-10-06T00:44:03Z",
		updated_at: "2026-10-06T00:44:03Z",
		fork: false
	},
	{
		full_name: "charlie947/social-media-skills",
		html_url: "https://github.com/charlie947/social-media-skills",
		description: "Social media automation and skill workflows.",
		stargazers_count: 4009,
		forks_count: 912,
		starred_at: "2026-09-15T02:57:08Z",
		updated_at: "2026-09-15T02:57:08Z",
		fork: false
	},
	{
		full_name: "AnmolSaini16/mapcn",
		html_url: "https://github.com/AnmolSaini16/mapcn",
		description: "Beautiful map components. 100% Free, Zero config, one command setup.",
		stargazers_count: 12248,
		forks_count: 719,
		starred_at: "2026-09-06T20:55:36Z",
		updated_at: "2026-09-06T20:55:36Z",
		fork: false
	},
	{
		full_name: "matallui/artico",
		html_url: "https://github.com/matallui/artico",
		description: "Artico - WebRTC made simple",
		stargazers_count: 115,
		forks_count: 8,
		starred_at: "2026-08-23T20:25:45Z",
		updated_at: "2026-08-23T20:25:45Z",
		fork: false
	},
	{
		full_name: "ZackGphom/GLORP",
		html_url: "https://github.com/ZackGphom/GLORP",
		description: "Optimized Pixel-Art to SVG converter with Greedy Meshing.",
		stargazers_count: 27,
		forks_count: 1,
		starred_at: "2026-07-10T14:15:00Z",
		updated_at: "2026-07-10T14:15:00Z",
		fork: false
	},
	{
		full_name: "molvqingtai/comctx",
		html_url: "https://github.com/molvqingtai/comctx",
		description: "Use RPC to communicate easily across contexts in any JavaScript environment.",
		stargazers_count: 122,
		forks_count: 4,
		starred_at: "2026-06-15T13:00:12Z",
		updated_at: "2026-06-15T13:00:12Z",
		fork: false
	}
];

const DEFAULT_SOCIAL_ORDER = 999;
const DEFAULT_GITHUB_ORDER_BASE = 1300;
const DEFAULT_GITHUB_FROM_DATE = "2026-01-01";
const GITHUB_PER_PAGE = 100;
let cachedSocialPostsPromise = null;
const slugify = (value) => value.toLowerCase().trim().replace(/['"]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const toDateScore = (value) => {
  if (!value) return Number.NEGATIVE_INFINITY;
  const score = Date.parse(value);
  return Number.isNaN(score) ? Number.NEGATIVE_INFINITY : score;
};
const withUniqueSlugs = (posts) => {
  const used = /* @__PURE__ */ new Set();
  return posts.map((post, index) => {
    const baseSlug = slugify(post.slug) || `post-${index + 1}`;
    let nextSlug = baseSlug;
    let suffix = 2;
    while (used.has(nextSlug)) {
      nextSlug = `${baseSlug}-${suffix}`;
      suffix += 1;
    }
    used.add(nextSlug);
    return {
      ...post,
      id: post.id || nextSlug,
      slug: nextSlug,
      permalink: `/social/${nextSlug}`
    };
  });
};
const getGitHubStarPosts = async (githubConfig) => {
  if (!githubConfig || githubConfig.enabled === false) return [];
  const fromDateRaw = githubConfig.fromDate ?? DEFAULT_GITHUB_FROM_DATE;
  const fromDateScore = Date.parse(fromDateRaw);
  const cutoffScore = Number.isNaN(fromDateScore) ? Date.parse(DEFAULT_GITHUB_FROM_DATE) : fromDateScore;
  const headers = {
    Accept: "application/vnd.github.star+json",
    "User-Agent": "portfolio-social-feed"
  };
  try {
    const starItems = [];
    for (let page = 1; ; page += 1) {
      const requestUrl = `https://api.github.com/users/${encodeURIComponent(githubConfig.username)}/starred?per_page=${GITHUB_PER_PAGE}&page=${page}`;
      const response = await fetch(requestUrl, { headers });
      if (!response.ok) {
        console.warn(`[social] GitHub stars fetch failed with status ${response.status}`);
        break;
      }
      const pageItems = await response.json();
      if (!Array.isArray(pageItems) || pageItems.length === 0) {
        break;
      }
      starItems.push(...pageItems);
      if (pageItems.length < GITHUB_PER_PAGE) {
        break;
      }
    }
    if (!starItems.length && Array.isArray(fallbackGitHubStars)) {
      starItems.push(...fallbackGitHubStars);
    }
    if (!starItems.length) return [];
    return starItems.map((item, index) => {
      const repo = item.repo ?? item;
      if (!repo.full_name || !repo.html_url) return null;
      if (githubConfig.includeForks === false && repo.fork) return null;
      const starDateScore = Date.parse(
        item.starred_at ?? repo.updated_at ?? repo.pushed_at ?? ""
      );
      if (Number.isNaN(starDateScore) || starDateScore < cutoffScore) return null;
      const stars = typeof repo.stargazers_count === "number" ? repo.stargazers_count : void 0;
      const forks = typeof repo.forks_count === "number" ? repo.forks_count : void 0;
      const [owner, repoName] = (repo.full_name ?? "").split("/");
      const post = {
        id: `github-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
        slug: `github-star-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
        permalink: `/social/github-star-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
        kind: "github",
        title: repo.full_name,
        caption: repo.description && repo.description.trim().length > 0 ? repo.description.trim() : "Repository from my GitHub stars.",
        date: item.starred_at ?? repo.updated_at ?? repo.pushed_at,
        href: repo.html_url,
        ctaLabel: "View on GitHub",
        order: DEFAULT_GITHUB_ORDER_BASE + index,
        stars,
        forks,
        repoUrl: repo.html_url,
        owner: owner || void 0,
        repoName: repoName || repo.full_name
      };
      return post;
    }).filter((post) => post !== null);
  } catch (error) {
    console.warn("[social] GitHub stars fetch failed, falling back to cached stars.", error);
    if (Array.isArray(fallbackGitHubStars)) {
      return fallbackGitHubStars.map((item, index) => {
        const repo = item.repo ?? item;
        if (!repo.full_name || !repo.html_url) return null;
        if (githubConfig.includeForks === false && repo.fork) return null;
        const starDateScore = Date.parse(
          item.starred_at ?? repo.updated_at ?? repo.pushed_at ?? ""
        );
        if (Number.isNaN(starDateScore) || starDateScore < cutoffScore) return null;
        const stars = typeof repo.stargazers_count === "number" ? repo.stargazers_count : void 0;
        const forks = typeof repo.forks_count === "number" ? repo.forks_count : void 0;
        const [owner, repoName] = (repo.full_name ?? "").split("/");
        const post = {
          id: `github-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
          slug: `github-star-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
          permalink: `/social/github-star-${repo.full_name.toLowerCase().replace(/[^a-z0-9_-]/g, "-")}`,
          kind: "github",
          title: repo.full_name,
          caption: repo.description && repo.description.trim().length > 0 ? repo.description.trim() : "Repository from my GitHub stars.",
          date: item.starred_at ?? repo.updated_at ?? repo.pushed_at,
          href: repo.html_url,
          ctaLabel: "View on GitHub",
          order: DEFAULT_GITHUB_ORDER_BASE + index,
          stars,
          forks,
          repoUrl: repo.html_url,
          owner: owner || void 0,
          repoName: repoName || repo.full_name
        };
        return post;
      }).filter((post) => post !== null);
    }
    return [];
  }
};
const getTikTokDateFromId = (videoId) => {
  try {
    const match = videoId.match(/\d{15,22}/);
    const cleanId = match ? match[0] : videoId;
    const timestampSec = Number(BigInt(cleanId) >> 32n);
    const dateObj = new Date(timestampSec * 1e3);
    if (!Number.isNaN(dateObj.getTime()) && dateObj.getFullYear() > 2016) {
      return dateObj.toISOString().split("T")[0];
    }
  } catch {
  }
  return "2026-01-01";
};
const createTikTokPostFromId = (input, defaultUsername = "ehsanpourhadi462", index = 0) => {
  const raw = typeof input === "string" ? { id: input } : input;
  const match = (raw.id || raw.href || raw.embedUrl || raw.slug || "").match(/\d{15,22}/);
  const videoId = match ? match[0] : raw.id || `video-${index + 1}`;
  const userMatch = (raw.href || "").match(/@([a-zA-Z0-9_.-]+)/);
  const username = userMatch ? userMatch[1] : defaultUsername;
  const derivedDate = raw.date || getTikTokDateFromId(videoId);
  const slug = raw.slug || `tiktok-${videoId}`;
  const embedUrl = raw.embedUrl || `https://www.tiktok.com/player/v1/${videoId}`;
  const href = raw.href || `https://www.tiktok.com/@${username}/video/${videoId}`;
  const mediaUrl = raw.mediaUrl || `/social/tiktok/${videoId}.jpg`;
  return {
    id: `tiktok-${videoId}`,
    slug,
    permalink: `/social/${slug}`,
    kind: "tiktok",
    title: raw.title || "TikTok Video",
    caption: raw.caption || "",
    date: derivedDate,
    embedUrl,
    mediaUrl,
    href,
    ctaLabel: raw.ctaLabel || "Watch on TikTok",
    order: raw.order ?? 500 + index
  };
};
const loadSocialPosts = async () => {
  const [socialEntries, socialSourceEntries] = await Promise.all([
    getCollection("social"),
    getCollection("socialSources")
  ]);
  const sourceConfig = socialSourceEntries.find((entry) => entry.id === "feed") ?? socialSourceEntries[0];
  const manualPosts = socialEntries.filter((entry) => entry.data.published === true).map((entry) => ({
    id: entry.slug,
    slug: entry.slug,
    permalink: `/social/${entry.slug}`,
    kind: entry.data.kind,
    title: entry.data.title,
    caption: entry.data.caption,
    date: entry.data.date,
    mediaUrl: entry.data.mediaUrl,
    poster: entry.data.poster,
    embedUrl: entry.data.embedUrl,
    href: entry.data.href,
    ctaLabel: entry.data.ctaLabel,
    order: entry.data.order ?? DEFAULT_SOCIAL_ORDER,
    stars: entry.data.stars,
    forks: entry.data.forks,
    repoUrl: entry.data.repoUrl,
    published: entry.data.published
  }));
  const tiktokConfig = sourceConfig?.data.tiktok;
  const tiktokUsername = tiktokConfig?.username || "ehsanpourhadi462";
  const rawTikTokItems = [
    ...tiktokConfig?.videoIds ?? [],
    ...sourceConfig?.data.tiktokEmbeds ?? []
  ];
  const tiktokPosts = rawTikTokItems.map(
    (item, index) => createTikTokPostFromId(item, tiktokUsername, index)
  );
  const githubPosts = await getGitHubStarPosts(sourceConfig?.data.github);
  return withUniqueSlugs([...manualPosts, ...tiktokPosts, ...githubPosts]).sort((a, b) => {
    const dateDiff = toDateScore(b.date) - toDateScore(a.date);
    if (dateDiff !== 0) return dateDiff;
    if (a.order !== b.order) return a.order - b.order;
    return a.title.localeCompare(b.title);
  });
};
const getSocialPosts = async () => {
  if (!cachedSocialPostsPromise) {
    cachedSocialPostsPromise = loadSocialPosts();
  }
  return cachedSocialPostsPromise;
};

export { SocialGridFeed as S, getSocialPosts as g };
