import { jsx, jsxs } from 'react/jsx-runtime';
import { motion } from 'framer-motion';
import { f as findTimelineMatch } from './Layout_zewWmYqx.mjs';
import { C as Card3D } from './Card3D_BEIy0EXF.mjs';

function getExpertiseColor(level) {
  if (level >= 7) return "bg-green-500";
  if (level >= 4) return "bg-blue-500";
  if (level >= 1) return "bg-yellow-500";
  return "bg-gray-400";
}
function StackCard({ slug, labels, icon, data }) {
  const getExpertiseLevel = (level) => {
    if (level === 10) return "Expert";
    if (level >= 7 && level <= 9) return "Advanced";
    if (level >= 4 && level <= 6) return "Professional";
    if (level >= 1 && level <= 3) return "Beginner";
    return "No Experience";
  };
  return /* @__PURE__ */ jsx(motion.div, { className: `rounded-lg`, whileHover: { scale: 1.02 }, children: /* @__PURE__ */ jsxs(
    Card3D,
    {
      className: "cursor-pointer flex-col items-center justify-center whitespace-nowrap text-black",
      glowColor: "color-mix(in srgb, currentColor 80%, var(--color-accent))",
      children: [
        /* @__PURE__ */ jsxs("div", { className: "-mb-2.5 flex items-center gap-4 p-3", children: [
          /* @__PURE__ */ jsx("img", { src: icon, alt: slug, className: "h-12 w-12" }),
          /* @__PURE__ */ jsx("h3", { className: "font-basement text-xl text-gray-600 dark:text-gray-300", children: slug })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "space-y-4 p-3", children: labels.map((label, index) => {
          const timelineMatch = findTimelineMatch(label);
          const yearsOfExperience = timelineMatch?.yearsOfExperience;
          return /* @__PURE__ */ jsx("div", { className: "group/stat relative", children: /* @__PURE__ */ jsx("div", { className: "clip2 rounded bg-white/40 dark:bg-black/70 px-2 py-2 transition-all duration-300 group-hover/stat:translate-z-2 group-hover/stat:scale-112 group-hover/stat:shadow-xl", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between gap-2", children: [
            /* @__PURE__ */ jsxs("span", { className: "text-gray-700 dark:text-gray-300", children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `mr-1 inline-block h-3 w-3 rounded-full ${getExpertiseColor(
                    parseInt(data[index]) || 0
                  )}`
                }
              ),
              label,
              yearsOfExperience && /* @__PURE__ */ jsxs("span", { className: "ml-1 text-sm text-gray-500 opacity-0 transition-all duration-300 ease-in-out group-hover/stat:opacity-100 dark:text-secondary-400", children: [
                yearsOfExperience,
                " Years"
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx("span", { className: "text-primary-500 opacity-0 transition-all duration-300 ease-in-out group-hover/stat:opacity-100", children: getExpertiseLevel(parseInt(data[index])) }) })
          ] }) }) }, label);
        }) })
      ]
    }
  ) });
}

export { StackCard as S };
