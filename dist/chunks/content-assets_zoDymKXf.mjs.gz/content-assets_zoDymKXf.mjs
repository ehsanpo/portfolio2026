const __ASTRO_IMAGE_IMPORT_Z1M0s82 = new Proxy({"src":"/_astro/alex-koll-top.pxitMOLg.png","width":1200,"height":630,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-top.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-top.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZPYqEe = new Proxy({"src":"/_astro/alex-koll-logo.kXuqMGD7.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_4VBYL = new Proxy({"src":"/_astro/alex-koll-1.BuVAQALw.jpg","width":446,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/alex-koll/alex-koll-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZBdz4m = new Proxy({"src":"/_astro/oresundskraft.EOY-X4pF.jpg","width":2104,"height":1315,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/oresundskraft.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/oresundskraft.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1DtIdH = new Proxy({"src":"/_astro/braenergi-logo.Dai_ns2s.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/braenergi-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/braenergi-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1UKwPl = new Proxy({"src":"/_astro/braenergi-1.Drli5Ced.jpg","width":1438,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/braenergi-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bra-energi/braenergi-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZkuUD4 = new Proxy({"src":"/_astro/btv-bg.LTHztgLj.png","width":1906,"height":615,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1OvjCy = new Proxy({"src":"/_astro/btv-logo.D2ntKbqp.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_aAkrC = new Proxy({"src":"/_astro/btv-1.CmI6W-fy.png","width":1395,"height":1961,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/battretillvaro/btv-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1n74pI = new Proxy({"src":"/_astro/040-bg.CqbyUhpW.png","width":1400,"height":712,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_KMlrs = new Proxy({"src":"/_astro/040-logo.BtPcWKAB.jpg","width":800,"height":600,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1cjGcP = new Proxy({"src":"/_astro/040-4.CmPmV766.jpg","width":852,"height":317,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1uK827 = new Proxy({"src":"/_astro/040-3.DxJHzZse.png","width":900,"height":217,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1YMOfS = new Proxy({"src":"/_astro/040-1.DaHZGfgO.jpg","width":800,"height":600,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1E9DCK = new Proxy({"src":"/_astro/040-2.Dzo74Hj4.jpg","width":960,"height":426,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2rCLFN = new Proxy({"src":"/_astro/040-5.B5oDTcQ1.jpg","width":1024,"height":768,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-5.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-5.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z11o6Kv = new Proxy({"src":"/_astro/040-6.BE6uBhdw.jpg","width":500,"height":431,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-6.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/040-fm/040-6.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Q7Iq5 = new Proxy({"src":"/_astro/appleappen-top.BvNLjp_w.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-top.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-top.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_A1g3s = new Proxy({"src":"/_astro/appleappen-logo.HXKj3DNQ.jpg","width":1024,"height":576,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_6ukUm = new Proxy({"src":"/_astro/appleappen-1.IotoHkEI.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/appleappen/appleappen-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_16sKrL = new Proxy({"src":"/_astro/bilcleaniken-top.DVx25mXC.jpg","width":2048,"height":1365,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-top.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-top.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1jaysz = new Proxy({"src":"/_astro/bilcleaniken-logo.rTOdknim.png","width":2176,"height":1359,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2oqiiT = new Proxy({"src":"/_astro/bilcleaniken-1.Zc2NxaO0.png","width":1779,"height":1979,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bilcleaniken/bilcleaniken-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z3oR7m = new Proxy({"src":"/_astro/bg.CAFD3MTi.jpg","width":1200,"height":630,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1JHsVy = new Proxy({"src":"/_astro/0_111.c2H20SPI.png","width":1456,"height":816,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/0_111.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/0_111.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_JJ0de = new Proxy({"src":"/_astro/logo.C-AZB2kJ.png","width":527,"height":417,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_tGRPc = new Proxy({"src":"/_astro/0_022.B__pjbJu.png","width":2176,"height":1220,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/0_022.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/0_022.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1NGxvm = new Proxy({"src":"/_astro/bb2.DbktUjmU.jpg","width":1500,"height":678,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bb2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bb2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2vHK9z = new Proxy({"src":"/_astro/bredband2-v2.Bd9aEaVm.png","width":662,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bredband2-v2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/bredband2-v2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZE5CLA = new Proxy({"src":"/_astro/1.CfWPRaUu.jpg","width":650,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bredband2/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZnjuH2 = new Proxy({"src":"/_astro/cover.DXiL43Ul.jpg","width":1000,"height":667,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZAc9Gx = new Proxy({"src":"/_astro/0.Ck0uAhIH.png","width":1387,"height":875,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/0.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/0.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_XVBfm = new Proxy({"src":"/_astro/00.CcY-dm0c.png","width":1382,"height":880,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/00.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/00.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z176mYv = new Proxy({"src":"/_astro/1.BM9-y4oG.png","width":1373,"height":872,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1D0Aht = new Proxy({"src":"/_astro/2.CEwz1PwR.png","width":1355,"height":869,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/audio-tools/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_h7NUq = new Proxy({"src":"/_astro/logo.BrFJuBr_.jpg","width":749,"height":749,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bjornekulla/logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bjornekulla/logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1HBbGp = new Proxy({"src":"/_astro/cover.C16OnEzg.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1I5kCH = new Proxy({"src":"/_astro/logo.BA7n0dKi.png","width":512,"height":512,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_hSvhM = new Proxy({"src":"/_astro/1.D2a1f1mA.png","width":1515,"height":954,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2tO7iW = new Proxy({"src":"/_astro/2.BVBzsCIT.png","width":1227,"height":954,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZorptO = new Proxy({"src":"/_astro/3.CaAm1A6j.png","width":1494,"height":954,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Mtbwl = new Proxy({"src":"/_astro/4.CCLiritL.png","width":1515,"height":954,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/animator/4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1u3FXQ = new Proxy({"src":"/_astro/demo3.DZl16G9j.png","width":1022,"height":579,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ykukx = new Proxy({"src":"/_astro/cover.DuLPy3La.png","width":1479,"height":980,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_rMmCy = new Proxy({"src":"/_astro/logo-text.DHo2ZN9g.png","width":850,"height":603,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/logo-text.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/logo-text.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZrffnU = new Proxy({"src":"/_astro/demo1.Dohf8py3.png","width":697,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZX9sFS = new Proxy({"src":"/_astro/demo2.TC71sizs.png","width":1681,"height":2051,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z20WTgO = new Proxy({"src":"/_astro/demo4.CHeAcCcM.png","width":1022,"height":614,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/atlasblocks/demo4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_uNQu = new Proxy({"src":"/_astro/bg.DKFeMrRo.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_XUr1M = new Proxy({"src":"/_astro/style.nT22C-mW.png","width":2176,"height":1598,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/style.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/style.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_14kp9y = new Proxy({"src":"/_astro/blocks1.BfbERynh.png","width":1694,"height":1066,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z4JlEo = new Proxy({"src":"/_astro/blocks2.Cm6oIgxz.png","width":1688,"height":1060,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1dO7tl = new Proxy({"src":"/_astro/blocks3.DPcq5Kud.png","width":1692,"height":1066,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2mSSii = new Proxy({"src":"/_astro/blocks4.DZgMsLt7.png","width":1690,"height":1074,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1ydtGG = new Proxy({"src":"/_astro/blocks5.Dsl-OFRu.png","width":1694,"height":1074,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks5.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks5.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZIV2Vd = new Proxy({"src":"/_astro/blocks7.Dhb4zPbT.png","width":1684,"height":1068,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks7.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/blockpress/blocks7.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1xyfSX = new Proxy({"src":"/_astro/my.BXutywG6.jpg","width":844,"height":614,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/my.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/my.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_zUUGY = new Proxy({"src":"/_astro/cover.4eMX_QJB.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1696uB = new Proxy({"src":"/_astro/logo.CWu4m2Be.png","width":1536,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z24DaUG = new Proxy({"src":"/_astro/1.C17_Vwcu.png","width":1382,"height":1161,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1B6YSa = new Proxy({"src":"/_astro/2.l2S1fiXj.png","width":1382,"height":1427,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/beads-bracelet-builder/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1LO2t0 = new Proxy({"src":"/_astro/cover.BBLksTUE.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZstIiu = new Proxy({"src":"/_astro/logo.Cn7YaCYH.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2lUWFD = new Proxy({"src":"/_astro/home.CgfiFHVF.png","width":1327,"height":955,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/home.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/home.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zm5ufr = new Proxy({"src":"/_astro/upload.Dei3dknM.png","width":1344,"height":955,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/upload.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/bookmark-library/upload.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Re0Q7 = new Proxy({"src":"/_astro/cyberpet.Nsvj3n0j.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/cyberpet.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/cyberpet.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2brxqb = new Proxy({"src":"/_astro/File_1.CkRaGTkp.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2qTN0v = new Proxy({"src":"/_astro/File_2.B4wpzuXU.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Y50Cg = new Proxy({"src":"/_astro/File_3.BwJfF6LJ.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1wfdf1 = new Proxy({"src":"/_astro/File_4.CmrIIawU.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_14ppQL = new Proxy({"src":"/_astro/File_5.CACtdHqH.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_5.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_5.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_BzCtw = new Proxy({"src":"/_astro/File_6.BXbu-8BJ.png","width":800,"height":1200,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_6.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cyber-pet/File_6.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1W9amw = new Proxy({"src":"/_astro/demo1.DUiw0v5f.png","width":1198,"height":739,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/demo1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/demo1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z140uHn = new Proxy({"src":"/_astro/logo.-8hB9JI4.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1qeW4y = new Proxy({"src":"/_astro/demo2.C2KLNEpG.png","width":1200,"height":786,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/demo2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/cybertechui/demo2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2r7wI5 = new Proxy({"src":"/_astro/cover.9NvNbpC4.png","width":1536,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/fakering/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/fakering/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_24HYYy = new Proxy({"src":"/_astro/logo.B8mywCpd.png","width":646,"height":657,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/fakering/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/fakering/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_jJ7Jq = new Proxy({"src":"/_astro/demo4.BZJa7Uq1.png","width":1241,"height":951,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/demo4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/demo4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1n2QdK = new Proxy({"src":"/_astro/homepage.BnA4sSKC.png","width":1328,"height":955,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/homepage.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/homepage.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_LJbou = new Proxy({"src":"/_astro/cover.Cw4Pht5g.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/ai-design-system-adventure/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1PCOxg = new Proxy({"src":"/_astro/1.DjhC7fyp.png","width":2040,"height":1860,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1TTIO1 = new Proxy({"src":"/_astro/2.BuZ2Oo6T.png","width":2040,"height":1945,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1YbD5L = new Proxy({"src":"/_astro/3.cmFQyBlQ.png","width":2040,"height":1897,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/harlem-underworld/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZH0h3P = new Proxy({"src":"/_astro/pxworld.9QGxI6km.png","width":1368,"height":309,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-animator-sprite-animation-tool/pxworld.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-animator-sprite-animation-tool/pxworld.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1TNE6E = new Proxy({"src":"/_astro/cover.C16OnEzg.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-animator-sprite-animation-tool/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-animator-sprite-animation-tool/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZjLF6Y = new Proxy({"src":"/_astro/cover.Cjke0iux.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/bookmark-chaos-to-spring-boot-salvation/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/bookmark-chaos-to-spring-boot-salvation/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1CS0Sl = new Proxy({"src":"/_astro/cover.Bic4QAou.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-modern-web-apps-with-astro-react/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-modern-web-apps-with-astro-react/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1IAggb = new Proxy({"src":"/_astro/logo-text.DHo2ZN9g.png","width":850,"height":603,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/atlasblocks-wordpress-to-react/logo-text.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/atlasblocks-wordpress-to-react/logo-text.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z18EJMx = new Proxy({"src":"/_astro/cover.DXiL43Ul.jpg","width":1000,"height":667,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-audio-tools-three-apps-one-passion/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-audio-tools-three-apps-one-passion/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZxhQR9 = new Proxy({"src":"/_astro/cover.B6ZC6QOL.jpg","width":1276,"height":746,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-chillinvr-teleporting-to-my-brothers-trip/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-chillinvr-teleporting-to-my-brothers-trip/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZhYOTa = new Proxy({"src":"/_astro/demo1.CvggOyv9.jpg","width":1200,"height":1029,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-go-desktop-app-weather-tray-icon/demo1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-go-desktop-app-weather-tray-icon/demo1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Nxg1W = new Proxy({"src":"/_astro/1.YlGMtc6D.png","width":339,"height":724,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_y2lNK = new Proxy({"src":"/_astro/3.BZ6tRt5c.png","width":510,"height":950,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z146j2n = new Proxy({"src":"/_astro/22.DrD1Lo-B.png","width":339,"height":720,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/22.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/22.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2djwpd = new Proxy({"src":"/_astro/cover.CamfTDQu.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/building-family-tracking-app-expo-supabase/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2aYFEv = new Proxy({"src":"/_astro/demo1.DUiw0v5f.png","width":1198,"height":739,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/demo1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/demo1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2odCmP = new Proxy({"src":"/_astro/demo2.C2KLNEpG.png","width":1200,"height":786,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/demo2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/demo2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z4nV8T = new Proxy({"src":"/_astro/logo.-8hB9JI4.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/cybertechui-making-the-web-cyberpunk/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_LwFRe = new Proxy({"src":"/_astro/3.CVNFJixu.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1N2qC4 = new Proxy({"src":"/_astro/1.DHb6jTET.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1yfE7s = new Proxy({"src":"/_astro/4.B2sqhPCY.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2feeIK = new Proxy({"src":"/_astro/2.D921I_Ay.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2kW9mG = new Proxy({"src":"/_astro/6.pErnpzYE.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/6.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/6.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1yXdiJ = new Proxy({"src":"/_astro/7.BOksW4_R.jpeg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/7.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/7.jpeg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZIRtyO = new Proxy({"src":"/_astro/bussemester-bg.CASIOyzL.jpg","width":2000,"height":1333,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1arbgr = new Proxy({"src":"/_astro/bussemester-logo.BDqwykI-.png","width":2176,"height":1359,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1PDnam = new Proxy({"src":"/_astro/bussemester-1.Dpt2HfQf.jpg","width":902,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Sb3ub = new Proxy({"src":"/_astro/bussemester-2.CE-PQtzL.jpg","width":1357,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bussemester/bussemester-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z29CTRg = new Proxy({"src":"/_astro/carpings-bg.noYD2jNW.jpg","width":1104,"height":680,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1o60vr = new Proxy({"src":"/_astro/carpings-logo.MKz9O73L.png","width":2176,"height":1444,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z10EXGR = new Proxy({"src":"/_astro/carpings-1.Ul2pW1Tt.jpg","width":1889,"height":2076,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/carpings/carpings-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1NDbAI = new Proxy({"src":"/_astro/bym-bg.B0EzSImD.png","width":2176,"height":1206,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z19w1EX = new Proxy({"src":"/_astro/bym-logo.CXxoioup.png","width":296,"height":156,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1EY4ws = new Proxy({"src":"/_astro/bym-2.DetZoyCP.jpg","width":950,"height":190,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2ahjyy = new Proxy({"src":"/_astro/bym-1.DWzhIf8N.jpg","width":800,"height":640,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/bym/bym-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2fGQSB = new Proxy({"src":"/_astro/2.BOyZiw1j.jpg","width":2000,"height":1250,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_25MyQa = new Proxy({"src":"/_astro/logo.RcF9wwfE.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Y3Ug = new Proxy({"src":"/_astro/4.CWekvEec.jpg","width":2000,"height":1215,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clever/4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1SuIvr = new Proxy({"src":"/_astro/5.6qZWMgsY.jpg","width":512,"height":512,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/5.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/prompt/img/agents/5.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1IrTNI = new Proxy({"src":"/_astro/CB_Image_2.DWv6RBEP.jpg","width":2160,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/CB_Image_2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/CB_Image_2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2uUo1e = new Proxy({"src":"/_astro/logo.CFq253hB.png","width":758,"height":906,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1VwB66 = new Proxy({"src":"/_astro/site.D-Ch66VQ.png","width":753,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/site.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cecilia-bjork/site.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZcE8Ma = new Proxy({"src":"/_astro/wsi-imageoptim-sym-1.CEPzXEHY.jpg","width":1024,"height":576,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/wsi-imageoptim-sym-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/wsi-imageoptim-sym-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1DurS6 = new Proxy({"src":"/_astro/logo.BSs46GXs.png","width":2176,"height":1434,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1rAsLm = new Proxy({"src":"/_astro/symsoft-1.DYo4mylR.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_u896b = new Proxy({"src":"/_astro/symsoft-2.DnS_LhfL.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zskaz0 = new Proxy({"src":"/_astro/symsoft-3.BatItMrl.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1pMufb = new Proxy({"src":"/_astro/symsoft-4.fQyvpuQR.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/clx-network/symsoft-4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zhr1k2 = new Proxy({"src":"/_astro/0_2.w0236yhw.png","width":1456,"height":816,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/digital-matchningstjanst/0_2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/digital-matchningstjanst/0_2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1BqnKn = new Proxy({"src":"/_astro/dosgardenias-bg.B3jjh8vQ.jpg","width":2176,"height":1411,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2eiXSv = new Proxy({"src":"/_astro/dosgardenias-logo.BAk31sIU.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZR6ahK = new Proxy({"src":"/_astro/dosgardenias-1.BV2X_LB3.png","width":1403,"height":1337,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/dosgardenias/dosgardenias-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1vQa8N = new Proxy({"src":"/_astro/pigpen-cipher-key.BgSZTMHM.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/pigpen-cipher/pigpen-cipher-key-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/pigpen-cipher/pigpen-cipher-key-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1gRPKk = new Proxy({"src":"/_astro/pigpen-cover.BRggdPfN.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/pigpen-cipher/pigpen-cover-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/pigpen-cipher/pigpen-cover-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1kYOa8 = new Proxy({"src":"/_astro/header.CkE04D6Z.jpg","width":1223,"height":1185,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/header.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/header.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1CqCRA = new Proxy({"src":"/_astro/0.DmMjEHz1.png","width":1218,"height":1981,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/0.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/0.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z25gqfP = new Proxy({"src":"/_astro/1.Dxhi1qK8.png","width":1218,"height":970,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2x5UaQ = new Proxy({"src":"/_astro/2.DniN8wUI.png","width":1218,"height":1025,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_25g7MB = new Proxy({"src":"/_astro/3.DWM5uem7.png","width":1218,"height":1954,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Cqkpm = new Proxy({"src":"/_astro/4.DxDhoYIe.png","width":1218,"height":1391,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/ritual-ai/4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1qoRxC = new Proxy({"src":"/_astro/cottex-bg.B5WrIooN.jpg","width":2176,"height":975,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2waTNH = new Proxy({"src":"/_astro/cottex-logo.DIsV5MGB.png","width":1430,"height":1143,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z7q3VE = new Proxy({"src":"/_astro/cottex-1.Dkm9nEE1.jpg","width":915,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z22Hq5I = new Proxy({"src":"/_astro/cottex-2.DVXGpTeE.png","width":1830,"height":1907,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/cottex/cottex-2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZmOLNX = new Proxy({"src":"/_astro/cover.CamfTDQu.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z15X8s = new Proxy({"src":"/_astro/logo.BkvkFtG8.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_UCOE3 = new Proxy({"src":"/_astro/1.YlGMtc6D.png","width":339,"height":724,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zg3kif = new Proxy({"src":"/_astro/22.DrD1Lo-B.png","width":339,"height":720,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/22.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/22.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2weyC5 = new Proxy({"src":"/_astro/3.BZ6tRt5c.png","width":510,"height":950,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/tracking-app/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2lx5W2 = new Proxy({"src":"/_astro/vscode3.CYcLVMVs.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-git-approvers/vscode3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-git-approvers/vscode3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZVHqch = new Proxy({"src":"/_astro/vscodelogo.BLwS2bSE.png","width":500,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-git-approvers/vscodelogo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-git-approvers/vscodelogo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1uw23P = new Proxy({"src":"/_astro/vscode1.E0n3oVmL.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscode1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscode1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_grF8V = new Proxy({"src":"/_astro/vscodelogo.BLwS2bSE.png","width":500,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscodelogo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscodelogo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2be8K1 = new Proxy({"src":"/_astro/vscode2.B9swsYOW.png","width":1962,"height":903,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscode2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-console-remover/vscode2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2czO7H = new Proxy({"src":"/_astro/Mockups_iPhone_15_Pro2.BQq53Aex.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/Mockups_iPhone_15_Pro2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/Mockups_iPhone_15_Pro2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_QN1Er = new Proxy({"src":"/_astro/cover2.BZNR1xdU.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/Mockups_iPhone_15_Pro.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/Mockups_iPhone_15_Pro.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1CTGU5 = new Proxy({"src":"/_astro/icon.DVBKKCSY.png","width":2048,"height":2048,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/icon.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/icon.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_nvpQD = new Proxy({"src":"/_astro/iPhone_14_Pro_Max_14.CzTzrxLy.jpg","width":1200,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/iPhone_14_Pro_Max_14.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/iPhone_14_Pro_Max_14.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_TiM7e = new Proxy({"src":"/_astro/gameover.DET-fU7t.png","width":414,"height":896,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/gameover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/gameover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zl6ooz = new Proxy({"src":"/_astro/gameplay.KgQ1qpOY.png","width":414,"height":896,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/gameplay.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/gameplay.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1JdftA = new Proxy({"src":"/_astro/leaderboard.COtFIipF.png","width":414,"height":896,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/leaderboard.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/leaderboard.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_16Pn3X = new Proxy({"src":"/_astro/levels.B4ki5oEI.png","width":414,"height":896,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/levels.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/levels.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1NuW0b = new Proxy({"src":"/_astro/settings.3m4ely7f.png","width":414,"height":896,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/settings.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/settings.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_vDBly = new Proxy({"src":"/_astro/ship-insop.ONISyJqZ.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/ship-insop.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/waverider/ship-insop.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1r5bIR = new Proxy({"src":"/_astro/1.CSbVcAOL.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2ttouv = new Proxy({"src":"/_astro/vscodelogo.BLwS2bSE.png","width":500,"height":500,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/vscodelogo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/vscodelogo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z4DgUb = new Proxy({"src":"/_astro/2.x83KZHDx.png","width":903,"height":769,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/vscode-px-to-tailwind/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z5astQ = new Proxy({"src":"/_astro/developer-type-calm-senior.Cqtcpc0I.png","width":1055,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/developer-personality-test/developer-type-calm-senior.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/developer-personality-test/developer-type-calm-senior.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_3Yj7 = new Proxy({"src":"/_astro/cover.vSBY9n1V.png","width":2176,"height":1526,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/developer-personality-test/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/developer-personality-test/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1YvDTY = new Proxy({"src":"/_astro/cover.BXCQrFc7.png","width":2752,"height":1536,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/design-styles/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/design-styles/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2mOPlW = new Proxy({"src":"/_astro/demo1.3x-uVLOv.png","width":432,"height":588,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/demo1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/demo1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Gz6sD = new Proxy({"src":"/_astro/demo2.DrPV5PSn.png","width":2176,"height":884,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/demo2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/demo2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1bKucg = new Proxy({"src":"/_astro/cover.9NvNbpC4.png","width":1536,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/fakering/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z29znzn = new Proxy({"src":"/_astro/circle-8_10.DawTtSuP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-8+10.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-8+10.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2ccPwJ = new Proxy({"src":"/_astro/circle-1.B0J8XjvP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1eJvQy = new Proxy({"src":"/_astro/circle-2.Drj49pzP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1CDr9Y = new Proxy({"src":"/_astro/circle-5.CZsDRi7a.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-5.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-5.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2u5mXL = new Proxy({"src":"/_astro/circle-6.DHF4UpiY.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-6.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-6.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1wC3iA = new Proxy({"src":"/_astro/circle-7.DlB3tYCo.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-7.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-7.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_z9ICp = new Proxy({"src":"/_astro/circle-8.CK6NpJt6.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-8.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-8.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZniA2L = new Proxy({"src":"/_astro/circle-9.sOoY7K3z.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-9.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-art-circles/circle-9.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZeogX9 = new Proxy({"src":"/_astro/cover.BjD05P1S.jpg","width":1024,"height":580,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/from-automation-to-apps/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/from-automation-to-apps/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_SCOSn = new Proxy({"src":"/_astro/slackbot.Bi4Vmhsl.png","width":630,"height":363,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/slack-points-bot/slackbot.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/slack-points-bot/slackbot.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1shmpe = new Proxy({"src":"/_astro/cover.B12ybCuq.jpg","width":1200,"height":933,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zl6gLR = new Proxy({"src":"/_astro/logo.BFlmIge1.png","width":1200,"height":900,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZYDliN = new Proxy({"src":"/_astro/1.D5kj7p0z.png","width":1460,"height":1231,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1rt8G3 = new Proxy({"src":"/_astro/2.kqiYrdpE.png","width":1460,"height":1306,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1TiV4i = new Proxy({"src":"/_astro/3.3FPCusCy.png","width":1460,"height":1306,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2m8Irx = new Proxy({"src":"/_astro/4.C4Lo6iiJ.png","width":1460,"height":1306,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/sweetshop/4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z9hKHe = new Proxy({"src":"/_astro/cover.n4WUx9HM.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/music-production-tools-2022/cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/music-production-tools-2022/cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z5Hr3p = new Proxy({"src":"/_astro/bg.Bv-94RLs.png","width":2176,"height":941,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_WoQ89 = new Proxy({"src":"/_astro/logo.BUQdArh1.png","width":992,"height":1056,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_iQLBd = new Proxy({"src":"/_astro/1.Cg85btT0.png","width":690,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z8X0L2 = new Proxy({"src":"/_astro/2.CklcLkhP.png","width":1218,"height":1098,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/herbal-ai/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2kmGJR = new Proxy({"src":"/_astro/pigpen-cipher-key.BgSZTMHM.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/getting-started-with-react-native/pigpen-cipher-key.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/getting-started-with-react-native/pigpen-cipher-key.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ULCmt = new Proxy({"src":"/_astro/pigpen-cover.BRggdPfN.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/getting-started-with-react-native/pigpen-cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/getting-started-with-react-native/pigpen-cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2sT0Js = new Proxy({"src":"/_astro/1.D7IGsmug.png","width":1080,"height":1920,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZE7c7x = new Proxy({"src":"/_astro/2.88N6M-EN.png","width":1080,"height":1920,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1i3IOo = new Proxy({"src":"/_astro/3.DiJNn6dk.png","width":1080,"height":1920,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Sy6Vc = new Proxy({"src":"/_astro/8.GCB7GdME.png","width":1080,"height":1920,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/8.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/generative-waves/8.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Yo4U5 = new Proxy({"src":"/_astro/Julianna_Margulies.0_dMIKgU.jpg","width":364,"height":484,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/Julianna_Margulies.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/Julianna_Margulies.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1ya76j = new Proxy({"src":"/_astro/cardi-b-rolling-stone-interview-cover_.DmRJtk8O.jpg","width":1473,"height":1156,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/cardi-b-rolling-stone-interview-cover_.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/cardi-b-rolling-stone-interview-cover_.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_E7wJu = new Proxy({"src":"/_astro/1111.Du09yF6B.jpg","width":243,"height":269,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/1111.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/1111.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZBp2pT = new Proxy({"src":"/_astro/nicki-minaj.DPDM5_5t.jpg","width":320,"height":541,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/nicki-minaj.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/nicki-minaj.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Rr2a8 = new Proxy({"src":"/_astro/ml-lessons-cover.D-eon0XA.jpg","width":829,"height":1244,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/ml-lessons-cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/machine-learning-lessons-learned/ml-lessons-cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_71qX0 = new Proxy({"src":"/_astro/cover.BF5BT5mr.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/music-visualization-threejs/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/music-visualization-threejs/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1T02Eo = new Proxy({"src":"/_astro/flamman-top.Cd5F3Sdo.jpg","width":960,"height":639,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-top.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-top.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_RD5hq = new Proxy({"src":"/_astro/flamman-logo.4eP0J6YR.png","width":1980,"height":1394,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z15WNOf = new Proxy({"src":"/_astro/flamman-1.B81P2VRr.jpg","width":486,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/flamman/flamman-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1gC3UC = new Proxy({"src":"/_astro/circle-8_10.DawTtSuP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-8+10.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-8+10.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZcMSc9 = new Proxy({"src":"/_astro/circle-7.DlB3tYCo.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-7.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-7.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZNv2K9 = new Proxy({"src":"/_astro/circle-1.B0J8XjvP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_8iP8v = new Proxy({"src":"/_astro/circle-2.Drj49pzP.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z26qDYs = new Proxy({"src":"/_astro/circle-5.CZsDRi7a.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-5.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-5.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z19BL5N = new Proxy({"src":"/_astro/circle-6.DHF4UpiY.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-6.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-6.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1FORAa = new Proxy({"src":"/_astro/circle-9.sOoY7K3z.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-9.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-9.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_230YTl = new Proxy({"src":"/_astro/circle-10.7lo8ip3x.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-10.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-10.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2qsYlA = new Proxy({"src":"/_astro/circle-16.HNLTM0L-.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-16.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-16.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1tE6rV = new Proxy({"src":"/_astro/circle-17.CZxQoRlG.png","width":2160,"height":2160,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-17.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/generative-circles/circle-17.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2wdWvH = new Proxy({"src":"/_astro/harbarhett-top.gho8mYAg.jpg","width":962,"height":1376,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/harbarhett-top.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/harbarhett-top.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_DcyMs = new Proxy({"src":"/_astro/hallbarhet-logo.bx_UT4Jq.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/hallbarhet-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/hallbarhet-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_sMoXu = new Proxy({"src":"/_astro/hallbarhet-1.BYP7yghk.jpg","width":320,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/hallbarhet-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/hallbarhetsredovisning/hallbarhet-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZEYfXA = new Proxy({"src":"/_astro/44.D3ygVUDk.jpg","width":2160,"height":1350,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/44.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/44.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZEOxHH = new Proxy({"src":"/_astro/hg.BN3WHMBS.png","width":1267,"height":819,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/hg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/hg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_298KEJ = new Proxy({"src":"/_astro/hoolygreens -fsc.C6Kl98dk.jpg","width":849,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/hoolygreens -fsc.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/holy-greens/hoolygreens -fsc.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z14HA9R = new Proxy({"src":"/_astro/gg-bg.BkQ3I3nK.png","width":1200,"height":630,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Cgxjx = new Proxy({"src":"/_astro/gg-logo.RV2SQYdQ.png","width":2176,"height":1053,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZsrXBb = new Proxy({"src":"/_astro/gg-1.BDoeSta6.jpg","width":1251,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/guts-glory/gg-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1qvc0U = new Proxy({"src":"/_astro/fmm-bg.Dm8kri8F.jpg","width":1400,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_23bx5W = new Proxy({"src":"/_astro/fmm-logo.DPiulGKY.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_OqGSu = new Proxy({"src":"/_astro/fmm-1.DRpQySed.jpg","width":962,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/folk-mat-moten/fmm-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z28yfnU = new Proxy({"src":"/_astro/wsi-imageoptim-1_Oresundskraft-2048x1280.BpAqd5s_.jpg","width":2048,"height":1280,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/KompisKlubben/wsi-imageoptim-1_Oresundskraft-2048x1280.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/KompisKlubben/wsi-imageoptim-1_Oresundskraft-2048x1280.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1nrS95 = new Proxy({"src":"/_astro/1.CO4FJBTZ.png","width":1096,"height":635,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/KompisKlubben/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/KompisKlubben/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZYIME0 = new Proxy({"src":"/_astro/felix.Cy-JnvIO.png","width":1920,"height":1080,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/felix.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/felix.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Uj1N7 = new Proxy({"src":"/_astro/logo.CtOeujp2.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1mP5Jt = new Proxy({"src":"/_astro/1.hvqJeL_u.png","width":485,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kockenskamrater/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZMmmp2 = new Proxy({"src":"/_astro/bg.Dg_y2G2Q.png","width":1722,"height":506,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1ih0PQ = new Proxy({"src":"/_astro/logo-rund.CDDAP20p.png","width":113,"height":103,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/logo-rund.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/logo-rund.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1YSQO8 = new Proxy({"src":"/_astro/1.BmV9-V4_.jpg","width":2176,"height":1632,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kondomspexen/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_iL17E = new Proxy({"src":"/_astro/kam.C368R_QZ.jpg","width":1024,"height":576,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2wPIQm = new Proxy({"src":"/_astro/kammar.sQ3O44M0.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kammar.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kammar.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1t3jIX = new Proxy({"src":"/_astro/kam-1.A0UIUfuK.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2uILNc = new Proxy({"src":"/_astro/kam-2.LqAza_IN.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/kammarkollegiet/kam-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_snA8l = new Proxy({"src":"/_astro/cover.CWPP3Spd.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-breakup-with-usestate/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-breakup-with-usestate/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z106qeX = new Proxy({"src":"/_astro/demo1.CvggOyv9.jpg","width":1200,"height":1029,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/demo1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/demo1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_27i1UR = new Proxy({"src":"/_astro/logo.D7TkSTeJ.png","width":680,"height":679,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2neByS = new Proxy({"src":"/_astro/screenshot.DSw1Iw7z.png","width":394,"height":450,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/screenshot.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/products/weather-app/screenshot.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z15qMpe = new Proxy({"src":"/_astro/ml-cover.DzgGo9Xh.jpg","width":1382,"height":922,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-first-machine-learning-project/ml-cover.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-first-machine-learning-project/ml-cover.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z28cVDN = new Proxy({"src":"/_astro/cover.Cmw8mYdg.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-fullstack-developer-journey/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/my-fullstack-developer-journey/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2cfFDw = new Proxy({"src":"/_astro/cover.5QMFeDk_.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/react-19-killing-usememo-usecallback/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/react-19-killing-usememo-usecallback/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZRcSJc = new Proxy({"src":"/_astro/cover.YleS0BZK.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/typescript-best-practices/cover.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/typescript-best-practices/cover.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2aD9uQ = new Proxy({"src":"/_astro/cover-agile-dev-ai.DCKvkTCF.png","width":2176,"height":1187,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/why-agile-ai-coding-feels-kinda-broken/cover-agile-dev-ai.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/why-agile-ai-coding-feels-kinda-broken/cover-agile-dev-ai.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZQBh2o = new Proxy({"src":"/_astro/1754388524427.WePGGLXm.png","width":1279,"height":720,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/why-i-actually-really-like-my-em/1754388524427.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/why-i-actually-really-like-my-em/1754388524427.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2clxB5 = new Proxy({"src":"/_astro/cover2.BZNR1xdU.jpg","width":1440,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/blog/waverider-sunday-build/cover2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/blog/waverider-sunday-build/cover2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1FRXy9 = new Proxy({"src":"/_astro/bg.D1i4f2gf.png","width":1400,"height":900,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_eAWtG = new Proxy({"src":"/_astro/lugi.DY_uqMvP.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/lugi.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/lugi.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZYBcUB = new Proxy({"src":"/_astro/2.Cm6G8j_f.jpg","width":1079,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2rHno2 = new Proxy({"src":"/_astro/1.DKGncHvp.png","width":530,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lugi/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_BLwA3 = new Proxy({"src":"/_astro/1.C7Wcrx4R.jpg","width":1400,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zue3D3 = new Proxy({"src":"/_astro/logo.buOx72Uq.png","width":2176,"height":1367,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Qi3Ca = new Proxy({"src":"/_astro/2.CIzoPrki.png","width":1017,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/lundaspelen/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZPrBF3 = new Proxy({"src":"/_astro/3.B54CSige.jpg","width":1200,"height":630,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_hgwcK = new Proxy({"src":"/_astro/logo-1.DuZVgaBR.png","width":2176,"height":1334,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/logo-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/logo-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_cHMue = new Proxy({"src":"/_astro/jj-1-Rotato-Snapshot.zvsuGJsi.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/jj-1-Rotato-Snapshot.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/jj-1-Rotato-Snapshot.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_RWDGy = new Proxy({"src":"/_astro/11.C9mLW48N.png","width":2176,"height":1222,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/11.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/11.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1FLsqs = new Proxy({"src":"/_astro/1.CEFiH-rL.png","width":2176,"height":1222,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ljusjakten/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZYViHt = new Proxy({"src":"/_astro/site.C_EWEv63.png","width":1432,"height":1996,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/loof-foundation/site.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/loof-foundation/site.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1jnzgB = new Proxy({"src":"/_astro/looflogo.BMDxmPTP.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/loof-foundation/looflogo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/loof-foundation/looflogo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1MXsHv = new Proxy({"src":"/_astro/16952304466_b91c4170f5_h.BRTlE9dI.jpg","width":1599,"height":888,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/library-event-display/16952304466_b91c4170f5_h.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/library-event-display/16952304466_b91c4170f5_h.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZoSuGx = new Proxy({"src":"/_astro/mockup-1.BGJrWXtd.jpg","width":2004,"height":1307,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mockup-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mockup-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_10yqnU = new Proxy({"src":"/_astro/mlogo.DK9VOTBP.png","width":640,"height":462,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mlogo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mlogo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_y8J5W = new Proxy({"src":"/_astro/11.rcV2HMvx.png","width":1157,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/11.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/11.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2lCkGE = new Proxy({"src":"/_astro/1.DoxqLwkB.png","width":991,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_mr9kk = new Proxy({"src":"/_astro/mockup-4.CdwPxXXb.jpg","width":2176,"height":1632,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mockup-4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/missmary/mockup-4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_JcH8x = new Proxy({"src":"/_astro/malmo-saluhall-bg.RElNpMGf.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmo-saluhall-bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmo-saluhall-bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZLeTVN = new Proxy({"src":"/_astro/wsi-imageoptim-5_Malmo_saluhall_2104x1315-2048x1280.DmMhDpQg.jpg","width":2048,"height":926,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/wsi-imageoptim-5_Malmo_saluhall_2104x1315-2048x1280.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/wsi-imageoptim-5_Malmo_saluhall_2104x1315-2048x1280.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zp0juD = new Proxy({"src":"/_astro/malmo-saluhall-top.ChpRD2Yl.png","width":1920,"height":1182,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmo-saluhall-top.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmo-saluhall-top.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1WYLSt = new Proxy({"src":"/_astro/malmosaluhall1.DYn8c2bc.jpg","width":406,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmosaluhall1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/malmo-saluhall/malmosaluhall1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2b1g6J = new Proxy({"src":"/_astro/bois-home-1-1200x0-c-default.DkW42tg5.jpg","width":1200,"height":695,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/bois-home-1-1200x0-c-default.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/bois-home-1-1200x0-c-default.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_29QXIV = new Proxy({"src":"/_astro/logo.BacTjA_y.png","width":2176,"height":1305,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Bdg7i = new Proxy({"src":"/_astro/1.DqCDLLTM.jpg","width":558,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/motesplatsip/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1VKWCp = new Proxy({"src":"/_astro/bg.KGSaXgB5.jpg","width":1200,"height":497,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1L0Hwc = new Proxy({"src":"/_astro/mekonomen.CIfE-3hL.jpg","width":1500,"height":678,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2sUodi = new Proxy({"src":"/_astro/mekonomen-1.uURoQUzS.png","width":1920,"height":1080,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZjJSe8 = new Proxy({"src":"/_astro/4.BX16RokJ.png","width":1418,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/4.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/4.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1t2lot = new Proxy({"src":"/_astro/mekonomen-2.BkUiz0DM.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2umVLh = new Proxy({"src":"/_astro/mekonomen-3.DhYx9L2y.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen/mekonomen-3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_bHcQU = new Proxy({"src":"/_astro/mekg.m6hcCqjd.jpg","width":1024,"height":576,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_BmiHI = new Proxy({"src":"/_astro/mlogo.ePuqwq4r.png","width":640,"height":462,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mlogo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mlogo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_28f1v0 = new Proxy({"src":"/_astro/mekonomen-g-1.CMFv-WpQ.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_11OYee = new Proxy({"src":"/_astro/mekonomen-g-2.C-pVl5-G.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1aY5jj = new Proxy({"src":"/_astro/mekonomen-g-4.D45Q8HMA.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/mekonomen-group/mekonomen-g-4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Hl7E5 = new Proxy({"src":"/_astro/mm_l.DP7xIqxq.png","width":1024,"height":576,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/mm_l.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/mm_l.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zs4kp5 = new Proxy({"src":"/_astro/2.BN29y2lQ.jpg","width":800,"height":600,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1tn6Pt = new Proxy({"src":"/_astro/finax_flode.C_MRkip5.jpg","width":1879,"height":701,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/finax_flode.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/finax_flode.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_25Qmob = new Proxy({"src":"/_astro/Knapp-ny-2-kopia.mU29hFG4.jpg","width":1712,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/Knapp-ny-2-kopia.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/Knapp-ny-2-kopia.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1JEukF = new Proxy({"src":"/_astro/mm-2.BkiJLAm7.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/mm-2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/muslimix/mm-2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Rimrm = new Proxy({"src":"/_astro/bg.BhBQbdP1.jpg","width":520,"height":408,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_muIAT = new Proxy({"src":"/_astro/logo.B00nIg2h.jpg","width":720,"height":486,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z23KjBj = new Proxy({"src":"/_astro/bild1.FQfV2YZy.jpg","width":914,"height":325,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/bild1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/bild1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1loD4r = new Proxy({"src":"/_astro/l2.33OFOBdi.jpg","width":960,"height":850,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/l2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/l2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1gp1MB = new Proxy({"src":"/_astro/ngd1.4jQfuLLK.jpg","width":1750,"height":770,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZL6LKv = new Proxy({"src":"/_astro/ngd2.DMeQ6mtD.jpg","width":1750,"height":770,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZgNwIp = new Proxy({"src":"/_astro/ngd3.BVzQh33C.jpg","width":1750,"height":770,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/ngd3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZhoyAm = new Proxy({"src":"/_astro/p3.DjRZACqu.jpg","width":640,"height":350,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/p3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/ngd/p3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZohVau = new Proxy({"src":"/_astro/noxo.CMkdRBsn.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noxo/noxo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noxo/noxo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1J3Xbf = new Proxy({"src":"/_astro/noxo.GpJeKfuk.jpg","width":779,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noxo/noxo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noxo/noxo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2qNqbF = new Proxy({"src":"/_astro/bg.BeIFqO_F.jpg","width":1656,"height":630,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2QXas = new Proxy({"src":"/_astro/logo.Dd7TCl3P.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_9Rj0K = new Proxy({"src":"/_astro/1.CoaTisRP.jpg","width":886,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/sankt-lars-park/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_178esb = new Proxy({"src":"/_astro/enviroment.Du21US2Q.jpg","width":1920,"height":957,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/enviroment.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/enviroment.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2r5SSP = new Proxy({"src":"/_astro/pfsystem.DSguLycm.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/pfsystem.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/pfsystem.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZQRh6p = new Proxy({"src":"/_astro/Screenshot_2019-04-08-PF-System1.CQ2SBawO.jpg","width":1768,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/Screenshot_2019-04-08-PF-System1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/Screenshot_2019-04-08-PF-System1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1LvhSU = new Proxy({"src":"/_astro/Screenshot_2019-04-08-Om-oss-–-PF-System1.BKLVorRO.png","width":1302,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/Screenshot_2019-04-08-Om-oss-–-PF-System1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pf-system/Screenshot_2019-04-08-Om-oss-–-PF-System1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZdAMvB = new Proxy({"src":"/_astro/logo.CGEOM4uc.jpg","width":2000,"height":1500,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZUihmU = new Proxy({"src":"/_astro/Drinks.CBQHOYdF.png","width":640,"height":1136,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Drinks.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Drinks.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_HLw98 = new Proxy({"src":"/_astro/Bill.d00vlkQz.png","width":640,"height":1136,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Bill.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Bill.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1c4UQK = new Proxy({"src":"/_astro/Choose-Restaurant.BImDJuBU.png","width":640,"height":1136,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Choose-Restaurant.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Choose-Restaurant.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZPm55O = new Proxy({"src":"/_astro/Drinks-No-Photos.B89gM4wx.png","width":640,"height":2177,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Drinks-No-Photos.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Drinks-No-Photos.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_138gH5 = new Proxy({"src":"/_astro/Food.BtVfNp3l.png","width":640,"height":1136,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Food.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Food.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_CMpQv = new Proxy({"src":"/_astro/Welcome.Df1-QHL3.png","width":640,"height":1136,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Welcome.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/pinchis/Welcome.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2hJBjd = new Proxy({"src":"/_astro/bg.CLLcc6T-.jpg","width":1024,"height":485,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_DRmg3 = new Proxy({"src":"/_astro/noalogo.xZ8Th7s9.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/noalogo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/noalogo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2lAbxW = new Proxy({"src":"/_astro/site.B6f34y6u.png","width":927,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/site.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/noaab/site.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2mG6C5 = new Proxy({"src":"/_astro/redfellaslogo.B4Ebp_wj.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/redfellas/redfellaslogo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/redfellas/redfellaslogo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1svvTN = new Proxy({"src":"/_astro/redfellassite.c9Z9YAT6.jpg","width":1591,"height":870,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/redfellas/redfellassite.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/redfellas/redfellassite.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_W6tbY = new Proxy({"src":"/_astro/roofit-garanti-image.DXSlFL7-.jpg","width":2176,"height":811,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/roofit-garanti-image.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/roofit-garanti-image.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1EOVh2 = new Proxy({"src":"/_astro/logo.7OLORq2y.png","width":1400,"height":900,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZlQ4OU = new Proxy({"src":"/_astro/12.DDVeSMV5.jpg","width":1080,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/12.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/12.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Odeza = new Proxy({"src":"/_astro/3.7No8sbc1.jpg","width":976,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/roofit/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_YaVMy = new Proxy({"src":"/_astro/original.DnCXy_NH.jpg","width":1575,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skaneleden/original.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skaneleden/original.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZOnqrr = new Proxy({"src":"/_astro/logo.CT0NavGk.jpg","width":1924,"height":1925,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skaneleden/logo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skaneleden/logo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_7QHRz = new Proxy({"src":"/_astro/bg.RRaTElRf.webp","width":1756,"height":1168,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanska-landskap/bg.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanska-landskap/bg.webp");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2lwsIr = new Proxy({"src":"/_astro/logo1.C5uMHxs_.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanska-landskap/logo1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanska-landskap/logo1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_73eSl = new Proxy({"src":"/_astro/bg.DLTAoIEO.png","width":1200,"height":630,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2ag328 = new Proxy({"src":"/_astro/logo.DKkVGgm6.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2hgnRq = new Proxy({"src":"/_astro/1.e_Feu9qp.jpg","width":1505,"height":1343,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1BjVO0 = new Proxy({"src":"/_astro/2.C-TPLd4T.png","width":1505,"height":1343,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/skanskahandboll/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZRhFHd = new Proxy({"src":"/_astro/bg.D9HMKKBJ.png","width":1436,"height":899,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/bg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/bg.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1cdGfs = new Proxy({"src":"/_astro/logo.CEDVwL3_.png","width":500,"height":238,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1rcXie = new Proxy({"src":"/_astro/1.BLL2E-ts.png","width":1596,"height":1393,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2wcjRw = new Proxy({"src":"/_astro/2.DGvSQcbt.png","width":1015,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/soctanter/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z22yJ1a = new Proxy({"src":"/_astro/ts.Ddyl92Dn.png","width":456,"height":721,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/ts.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/ts.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z6niSf = new Proxy({"src":"/_astro/telavox-top.CiwqlzG0.png","width":2176,"height":1148,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-top.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-top.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1vR7Hq = new Proxy({"src":"/_astro/logo1.Dl7pvDq0.png","width":2176,"height":1412,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/logo1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/logo1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZqvOlM = new Proxy({"src":"/_astro/telavox-logo.JixvSTr-.png","width":2048,"height":2048,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Iw4sb = new Proxy({"src":"/_astro/chat.Ji6AOy0p.png","width":1299,"height":521,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/chat.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/chat.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_vLsQ0 = new Proxy({"src":"/_astro/telavox2.BUcrk1mP.png","width":1616,"height":752,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1LtYJq = new Proxy({"src":"/_astro/11Smart-city_1920x1080px_utan-text.BvnhfmgU.jpg","width":1400,"height":788,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/11Smart-city_1920x1080px_utan-text.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/11Smart-city_1920x1080px_utan-text.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_cMWKT = new Proxy({"src":"/_astro/SHA-Rotato-Snapshot.DKZtN7Zt.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/SHA-Rotato-Snapshot.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/SHA-Rotato-Snapshot.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1zdqWR = new Proxy({"src":"/_astro/Screenshot_2019-04-01-StadshubbsAlliansen1.mfWTKx0t.jpg","width":1289,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/Screenshot_2019-04-01-StadshubbsAlliansen1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/stadshubbsalliansen/Screenshot_2019-04-01-StadshubbsAlliansen1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z10sGMV = new Proxy({"src":"/_astro/telavox-app.BUC-Mhkh.png","width":1212,"height":900,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-app.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavox-app.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_YOQTS = new Proxy({"src":"/_astro/telavoxcv.DVILZ-qr.jpg","width":1500,"height":678,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavoxcv.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/telavoxcv.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2bkUi4 = new Proxy({"src":"/_astro/tvx-app.CasLw5Qs.png","width":2176,"height":1567,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/tvx-app.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telavox/tvx-app.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_23NHa7 = new Proxy({"src":"/_astro/11.CuvGNZ7F.png","width":678,"height":735,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/11.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/11.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2tkwHp = new Proxy({"src":"/_astro/logo.CzWPRkwz.png","width":1024,"height":1024,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZnttIp = new Proxy({"src":"/_astro/4t.Du5ovh9u.png","width":1128,"height":950,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/4t.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/4t.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Nr7hK = new Proxy({"src":"/_astro/5t.CCQS9b9_.png","width":1192,"height":1150,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/5t.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/5t.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z14Opv1 = new Proxy({"src":"/_astro/6t.zNOObIsY.png","width":974,"height":1162,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/6t.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/6t.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1HTCzO = new Proxy({"src":"/_astro/databse.C8dkZh8S.png","width":1207,"height":964,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/databse.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/telenor/databse.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2otYyN = new Proxy({"src":"/_astro/11.BUkm0Xg_.png","width":798,"height":449,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/11.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/11.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_pxWjM = new Proxy({"src":"/_astro/thefanclublogo.BGOB9y_q.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/thefanclublogo.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/thefanclublogo.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_CwL9h = new Proxy({"src":"/_astro/site.bAWLNA6t.png","width":507,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/site.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/site.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2tWXu4 = new Proxy({"src":"/_astro/conv-model.DZ00L96d.png","width":1131,"height":641,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/conv-model.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/conv-model.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z17bv02 = new Proxy({"src":"/_astro/a8d4df00100196c9_800x800ar.BfetrByT.jpg","width":800,"height":533,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/a8d4df00100196c9_800x800ar.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/thefanclub/a8d4df00100196c9_800x800ar.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_22sEeL = new Proxy({"src":"/_astro/3.xeQ4UVBJ.png","width":1507,"height":1275,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_izeYg = new Proxy({"src":"/_astro/logo.DCrTUk1E.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_E5Ynu = new Proxy({"src":"/_astro/2.Di-Kuj4m.png","width":1507,"height":1275,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/twilfit/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_XNHpF = new Proxy({"src":"/_astro/vgardar.Ch_F1atM.jpg","width":600,"height":600,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/varagardar/vgardar.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/varagardar/vgardar.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Zht4Da = new Proxy({"src":"/_astro/VG_logotyp_vit-300x300.Bp151-q0.png","width":300,"height":300,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/varagardar/VG_logotyp_vit-300x300.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/varagardar/VG_logotyp_vit-300x300.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1jGVBt = new Proxy({"src":"/_astro/1.93eDW98H.png","width":1507,"height":1275,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZF8M0W = new Proxy({"src":"/_astro/logo.BQRxjcG7.png","width":2046,"height":1202,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2iULOr = new Proxy({"src":"/_astro/2.CMr5OtLl.png","width":1507,"height":2037,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZQmmrq = new Proxy({"src":"/_astro/3.B82b0HVl.png","width":1507,"height":2037,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/unilever-food-solutions/3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1DVBC3 = new Proxy({"src":"/_astro/toolpool-top1.BSUZrJw-.jpg","width":2176,"height":1451,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-top1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-top1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_9QgE9 = new Proxy({"src":"/_astro/toolpool.CLy4LXuY.jpg","width":1500,"height":678,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZiTc57 = new Proxy({"src":"/_astro/toolpool-4.V6RSn4f8.jpg","width":621,"height":881,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZfsKIB = new Proxy({"src":"/_astro/toolpool-top.Bz_gtmou.jpg","width":2176,"height":1451,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-top.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-top.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z15eQ6Y = new Proxy({"src":"/_astro/toolpool-1.D6KZnAWP.jpg","width":2048,"height":1448,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2g5823 = new Proxy({"src":"/_astro/toolpool-3.CkxrnGtK.jpg","width":960,"height":960,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/toolpool-3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_guhQ4 = new Proxy({"src":"/_astro/site-1.BfU6BhMa.jpg","width":800,"height":600,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/site-1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/toolpool/site-1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_19UUjr = new Proxy({"src":"/_astro/map.DuKA0dPm.png","width":1822,"height":1972,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/map.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/map.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZumGiN = new Proxy({"src":"/_astro/triwa.DtPYkSmt.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/triwa.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/triwa.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2ae2Mp = new Proxy({"src":"/_astro/home.2GUz5GEN.jpg","width":617,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/home.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/triwa/home.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1H7044 = new Proxy({"src":"/_astro/vivere.Q-Nzpo3g.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/vivere/vivere.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/vivere/vivere.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_kldY5 = new Proxy({"src":"/_astro/sitevv.KawD9E2r.png","width":681,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/vivere/sitevv.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/vivere/sitevv.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZzxzTF = new Proxy({"src":"/_astro/site-small.DWoBsn8F.png","width":1328,"height":795,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/site-small.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/site-small.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ebzJ6 = new Proxy({"src":"/_astro/logo.pnX8M-m4.png","width":512,"height":512,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z85ypR = new Proxy({"src":"/_astro/site.CWccJy_V.png","width":372,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/site.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/whitespace/site.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_y57Dg = new Proxy({"src":"/_astro/bg.CJpjxVAQ.jpg","width":2000,"height":1000,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_RQTjE = new Proxy({"src":"/_astro/logo.D9NhAl1R.png","width":1920,"height":1080,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2iPLO0 = new Proxy({"src":"/_astro/wilfa_rgb_blue.CxPZgi2Q.png","width":250,"height":250,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/wilfa_rgb_blue.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/wilfa_rgb_blue.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1Vz9Rl = new Proxy({"src":"/_astro/0.B5xYWEUd.jpg","width":1024,"height":576,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/0.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/0.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1QFRlK = new Proxy({"src":"/_astro/00.BwfOtzSy.jpg","width":1920,"height":1080,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/00.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/00.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1sJmwJ = new Proxy({"src":"/_astro/1.Cu3cdHZ_.png","width":627,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZlS5tK = new Proxy({"src":"/_astro/3.UjoXndYb.jpg","width":733,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZCl9Lj = new Proxy({"src":"/_astro/33.Do_Euwwy.jpg","width":1327,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/33.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/wilfa/33.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1iivdG = new Proxy({"src":"/_astro/bg.DvuBKf3N.jpg","width":2176,"height":995,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/bg.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/bg.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_JCMxn = new Proxy({"src":"/_astro/logo.s0zl5eHx.png","width":1400,"height":900,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/logo.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/logo.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZlGIlV = new Proxy({"src":"/_astro/1.DocpDEZW.jpg","width":1012,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/1.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/1.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z11Wsff = new Proxy({"src":"/_astro/2.CnDihRor.jpg","width":1649,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/2.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1Hdc8y = new Proxy({"src":"/_astro/3.Dz3CABh3.jpg","width":1132,"height":2176,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2h93Ar = new Proxy({"src":"/_astro/33.DOtgeb5H.jpg","width":1936,"height":2092,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/33.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/33.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1FyfTq = new Proxy({"src":"/_astro/wframe.sjwzoqBI.png","width":2048,"height":2176,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/wframe.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest/wframe.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2c6tE5 = new Proxy({"src":"/_astro/fb2.BI6ms6wx.png","width":1200,"height":640,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/fb2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/fb2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z2WxjT = new Proxy({"src":"/_astro/1-3.Dcqp6EXH.png","width":2176,"height":1224,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/1-3.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/1-3.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_17RIAa = new Proxy({"src":"/_astro/1-1.DZyku9cK.png","width":1609,"height":1961,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/1-1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zest-hmd/1-1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1px57i = new Proxy({"src":"/_astro/1.fDYQA5Ao.png","width":1328,"height":702,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_ZmrEtj = new Proxy({"src":"/_astro/zt-w1.B-SuFg5T.png","width":1920,"height":1080,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/zt-w1.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/zt-w1.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_wCPOD = new Proxy({"src":"/_astro/2.DPd1kQ6n.png","width":1271,"height":676,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/2.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_Z1CHa6K = new Proxy({"src":"/_astro/4.C8dPWcC-.jpg","width":1280,"height":804,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/4.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/4.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_1uj2Kf = new Proxy({"src":"/_astro/3.-eKc4Beb.jpg","width":1400,"height":900,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/3.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/3.jpg");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_2ajrrm = new Proxy({"src":"/_astro/111.BEyb1PVB.png","width":553,"height":922,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/111.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/111.png");
							return target[name];
						}
					});

const __ASTRO_IMAGE_IMPORT_QCp6l = new Proxy({"src":"/_astro/1-2.CC6ZLz9s.png","width":553,"height":922,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/1-2.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/content/portfolio/zhowtime/1-2.png");
							return target[name];
						}
					});

const contentAssets = new Map([["./alex-koll-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Falex-koll%2Falex-koll.md", __ASTRO_IMAGE_IMPORT_Z1M0s82], ["./alex-koll-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Falex-koll%2Falex-koll.md", __ASTRO_IMAGE_IMPORT_ZPYqEe], ["./alex-koll-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Falex-koll%2Falex-koll.md", __ASTRO_IMAGE_IMPORT_4VBYL], ["./oresundskraft.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbra-energi%2Fbra-energi.md", __ASTRO_IMAGE_IMPORT_ZBdz4m], ["./braenergi-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbra-energi%2Fbra-energi.md", __ASTRO_IMAGE_IMPORT_Z1DtIdH], ["./braenergi-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbra-energi%2Fbra-energi.md", __ASTRO_IMAGE_IMPORT_1UKwPl], ["./btv-bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbattretillvaro%2Fbattretillvaro-se.md", __ASTRO_IMAGE_IMPORT_ZkuUD4], ["./btv-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbattretillvaro%2Fbattretillvaro-se.md", __ASTRO_IMAGE_IMPORT_1OvjCy], ["./btv-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbattretillvaro%2Fbattretillvaro-se.md", __ASTRO_IMAGE_IMPORT_aAkrC], ["./040-bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_Z1n74pI], ["./040-logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_KMlrs], ["./040-4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_1cjGcP], ["./040-3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_1uK827], ["./040-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_1YMOfS], ["./040-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_Z1E9DCK], ["./040-5.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_Z2rCLFN], ["./040-6.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2F040-fm%2F040-fm.md", __ASTRO_IMAGE_IMPORT_Z11o6Kv], ["./appleappen-top.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fappleappen%2Fappleappen.md", __ASTRO_IMAGE_IMPORT_Q7Iq5], ["./appleappen-logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fappleappen%2Fappleappen.md", __ASTRO_IMAGE_IMPORT_A1g3s], ["./appleappen-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fappleappen%2Fappleappen.md", __ASTRO_IMAGE_IMPORT_6ukUm], ["./bilcleaniken-top.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbilcleaniken%2Fbilcleaniken.md", __ASTRO_IMAGE_IMPORT_16sKrL], ["./bilcleaniken-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbilcleaniken%2Fbilcleaniken.md", __ASTRO_IMAGE_IMPORT_1jaysz], ["./bilcleaniken-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbilcleaniken%2Fbilcleaniken.md", __ASTRO_IMAGE_IMPORT_2oqiiT], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fsearch.md", __ASTRO_IMAGE_IMPORT_Z3oR7m], ["./0_111.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fsearch.md", __ASTRO_IMAGE_IMPORT_1JHsVy], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fsearch.md", __ASTRO_IMAGE_IMPORT_JJ0de], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fportal.md", __ASTRO_IMAGE_IMPORT_Z3oR7m], ["./0_022.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fportal.md", __ASTRO_IMAGE_IMPORT_tGRPc], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fportal.md", __ASTRO_IMAGE_IMPORT_JJ0de], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fredesign.md", __ASTRO_IMAGE_IMPORT_Z3oR7m], ["./bb2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fredesign.md", __ASTRO_IMAGE_IMPORT_1NGxvm], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fredesign.md", __ASTRO_IMAGE_IMPORT_JJ0de], ["./bredband2-v2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fredesign.md", __ASTRO_IMAGE_IMPORT_2vHK9z], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fredesign.md", __ASTRO_IMAGE_IMPORT_ZE5CLA], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Faudio-tools%2Faudio-tools.md", __ASTRO_IMAGE_IMPORT_ZnjuH2], ["./0.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Faudio-tools%2Faudio-tools.md", __ASTRO_IMAGE_IMPORT_ZAc9Gx], ["./00.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Faudio-tools%2Faudio-tools.md", __ASTRO_IMAGE_IMPORT_XVBfm], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Faudio-tools%2Faudio-tools.md", __ASTRO_IMAGE_IMPORT_Z176mYv], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Faudio-tools%2Faudio-tools.md", __ASTRO_IMAGE_IMPORT_Z1D0Aht], ["./logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbjornekulla%2Fbjornekulla.md", __ASTRO_IMAGE_IMPORT_h7NUq], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_Z1HBbGp], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_1I5kCH], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_hSvhM], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_2tO7iW], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_ZorptO], ["./4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fanimator%2Fanimator.md", __ASTRO_IMAGE_IMPORT_1Mtbwl], ["./demo3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_Z1u3FXQ], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_ykukx], ["./logo-text.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_rMmCy], ["./demo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_ZrffnU], ["./demo2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_ZX9sFS], ["./demo4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fatlasblocks%2Fatlasblocks.md", __ASTRO_IMAGE_IMPORT_Z20WTgO], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_uNQu], ["./style.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_XUr1M], ["./blocks1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_14kp9y], ["./blocks2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_Z4JlEo], ["./blocks3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_Z1dO7tl], ["./blocks4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_Z2mSSii], ["./blocks5.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_1ydtGG], ["./blocks7.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fblockpress%2Fblockpress.md", __ASTRO_IMAGE_IMPORT_ZIV2Vd], ["./my.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbeads-bracelet-builder%2Fbeads-bracelet-builder.md", __ASTRO_IMAGE_IMPORT_Z1xyfSX], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbeads-bracelet-builder%2Fbeads-bracelet-builder.md", __ASTRO_IMAGE_IMPORT_zUUGY], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbeads-bracelet-builder%2Fbeads-bracelet-builder.md", __ASTRO_IMAGE_IMPORT_Z1696uB], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbeads-bracelet-builder%2Fbeads-bracelet-builder.md", __ASTRO_IMAGE_IMPORT_Z24DaUG], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbeads-bracelet-builder%2Fbeads-bracelet-builder.md", __ASTRO_IMAGE_IMPORT_1B6YSa], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbookmark-library%2Fbookmark-library.md", __ASTRO_IMAGE_IMPORT_1LO2t0], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbookmark-library%2Fbookmark-library.md", __ASTRO_IMAGE_IMPORT_ZstIiu], ["./home.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbookmark-library%2Fbookmark-library.md", __ASTRO_IMAGE_IMPORT_Z2lUWFD], ["./upload.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fbookmark-library%2Fbookmark-library.md", __ASTRO_IMAGE_IMPORT_Zm5ufr], ["./cyberpet.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_Re0Q7], ["./File_1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_Z2brxqb], ["./File_2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_2qTN0v], ["./File_3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_1Y50Cg], ["./File_4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_1wfdf1], ["./File_5.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_14ppQL], ["./File_6.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcyber-pet%2Fcyber-pet.md", __ASTRO_IMAGE_IMPORT_BzCtw], ["./demo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcybertechui%2Fcybertechui.md", __ASTRO_IMAGE_IMPORT_1W9amw], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcybertechui%2Fcybertechui.md", __ASTRO_IMAGE_IMPORT_Z140uHn], ["./demo2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fcybertechui%2Fcybertechui.md", __ASTRO_IMAGE_IMPORT_1qeW4y], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ffakering%2Ffakering.md", __ASTRO_IMAGE_IMPORT_2r7wI5], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ffakering%2Ffakering.md", __ASTRO_IMAGE_IMPORT_24HYYy], ["demo4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fai-design-system-adventure%2Findex.md", __ASTRO_IMAGE_IMPORT_jJ7Jq], ["homepage.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fai-design-system-adventure%2Findex.md", __ASTRO_IMAGE_IMPORT_1n2QdK], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fai-design-system-adventure%2Findex.md", __ASTRO_IMAGE_IMPORT_LJbou], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fharlem-underworld%2Fharlem-underworld.md", __ASTRO_IMAGE_IMPORT_1PCOxg], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fharlem-underworld%2Fharlem-underworld.md", __ASTRO_IMAGE_IMPORT_1TTIO1], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fharlem-underworld%2Fharlem-underworld.md", __ASTRO_IMAGE_IMPORT_1YbD5L], ["./pxworld.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-animator-sprite-animation-tool%2Findex.md", __ASTRO_IMAGE_IMPORT_ZH0h3P], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-animator-sprite-animation-tool%2Findex.md", __ASTRO_IMAGE_IMPORT_1TNE6E], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbookmark-chaos-to-spring-boot-salvation%2Findex.md", __ASTRO_IMAGE_IMPORT_ZjLF6Y], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-modern-web-apps-with-astro-react%2Findex.md", __ASTRO_IMAGE_IMPORT_1CS0Sl], ["./logo-text.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fatlasblocks-wordpress-to-react%2Findex.md", __ASTRO_IMAGE_IMPORT_1IAggb], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-audio-tools-three-apps-one-passion%2Findex.md", __ASTRO_IMAGE_IMPORT_Z18EJMx], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-chillinvr-teleporting-to-my-brothers-trip%2Findex.md", __ASTRO_IMAGE_IMPORT_ZxhQR9], ["./demo1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-go-desktop-app-weather-tray-icon%2Findex.md", __ASTRO_IMAGE_IMPORT_ZhYOTa], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-family-tracking-app-expo-supabase%2Findex.md", __ASTRO_IMAGE_IMPORT_Z1Nxg1W], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-family-tracking-app-expo-supabase%2Findex.md", __ASTRO_IMAGE_IMPORT_y2lNK], ["./22.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-family-tracking-app-expo-supabase%2Findex.md", __ASTRO_IMAGE_IMPORT_Z146j2n], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fbuilding-family-tracking-app-expo-supabase%2Findex.md", __ASTRO_IMAGE_IMPORT_Z2djwpd], ["./demo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fcybertechui-making-the-web-cyberpunk%2Findex.md", __ASTRO_IMAGE_IMPORT_2aYFEv], ["demo2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fcybertechui-making-the-web-cyberpunk%2Findex.md", __ASTRO_IMAGE_IMPORT_Z2odCmP], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fcybertechui-making-the-web-cyberpunk%2Findex.md", __ASTRO_IMAGE_IMPORT_Z4nV8T], ["./img/agents/3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FBook+Summery.md", __ASTRO_IMAGE_IMPORT_LwFRe], ["./img/agents/1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FblogWriter.md", __ASTRO_IMAGE_IMPORT_1N2qC4], ["./img/agents/4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FCover+Letter+Job-Specific+Generator.md", __ASTRO_IMAGE_IMPORT_1yfE7s], ["./img/agents/2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FPortfolioWriter.md", __ASTRO_IMAGE_IMPORT_2feeIK], ["./img/agents/6.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FResume+Review+%26+Rewrite+Agent.md", __ASTRO_IMAGE_IMPORT_Z2kW9mG], ["./img/agents/7.jpeg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FProductLuncher.md", __ASTRO_IMAGE_IMPORT_Z1yXdiJ], ["./bussemester-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbussemester%2Fbussemester.md", __ASTRO_IMAGE_IMPORT_ZIRtyO], ["./bussemester-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbussemester%2Fbussemester.md", __ASTRO_IMAGE_IMPORT_1arbgr], ["./bussemester-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbussemester%2Fbussemester.md", __ASTRO_IMAGE_IMPORT_1PDnam], ["./bussemester-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbussemester%2Fbussemester.md", __ASTRO_IMAGE_IMPORT_Sb3ub], ["./carpings-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcarpings%2Fcarpings.md", __ASTRO_IMAGE_IMPORT_Z29CTRg], ["./carpings-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcarpings%2Fcarpings.md", __ASTRO_IMAGE_IMPORT_1o60vr], ["./carpings-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcarpings%2Fcarpings.md", __ASTRO_IMAGE_IMPORT_Z10EXGR], ["./bym-bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbym%2Fbym.md", __ASTRO_IMAGE_IMPORT_1NDbAI], ["./bym-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbym%2Fbym.md", __ASTRO_IMAGE_IMPORT_Z19w1EX], ["./bym-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbym%2Fbym.md", __ASTRO_IMAGE_IMPORT_Z1EY4ws], ["./bym-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbym%2Fbym.md", __ASTRO_IMAGE_IMPORT_Z2ahjyy], ["./2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclever%2Fclever.md", __ASTRO_IMAGE_IMPORT_2fGQSB], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclever%2Fclever.md", __ASTRO_IMAGE_IMPORT_25MyQa], ["./4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclever%2Fclever.md", __ASTRO_IMAGE_IMPORT_1Y3Ug], ["./img/agents/5.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fprompt%2FProductWriter.md", __ASTRO_IMAGE_IMPORT_1SuIvr], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fskills.md", __ASTRO_IMAGE_IMPORT_Z3oR7m], ["./bb2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fskills.md", __ASTRO_IMAGE_IMPORT_1NGxvm], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fbredband2%2Fskills.md", __ASTRO_IMAGE_IMPORT_JJ0de], ["./CB_Image_2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcecilia-bjork%2Fcecilia-bjork.md", __ASTRO_IMAGE_IMPORT_Z1IrTNI], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcecilia-bjork%2Fcecilia-bjork.md", __ASTRO_IMAGE_IMPORT_2uUo1e], ["./site.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcecilia-bjork%2Fcecilia-bjork.md", __ASTRO_IMAGE_IMPORT_1VwB66], ["./wsi-imageoptim-sym-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_ZcE8Ma], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_1DurS6], ["./symsoft-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_1rAsLm], ["./symsoft-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_u896b], ["./symsoft-3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_Zskaz0], ["./symsoft-4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fclx-network%2Fclx-network.md", __ASTRO_IMAGE_IMPORT_Z1pMufb], ["./0_2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fdigital-matchningstjanst%2Fdigital-matchningstjanst.md", __ASTRO_IMAGE_IMPORT_Zhr1k2], ["./dosgardenias-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fdosgardenias%2Fdosgardenias.md", __ASTRO_IMAGE_IMPORT_1BqnKn], ["./dosgardenias-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fdosgardenias%2Fdosgardenias.md", __ASTRO_IMAGE_IMPORT_2eiXSv], ["./dosgardenias-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fdosgardenias%2Fdosgardenias.md", __ASTRO_IMAGE_IMPORT_ZR6ahK], ["./pigpen-cipher-key-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fpigpen-cipher%2Fpigpen-cipher.md", __ASTRO_IMAGE_IMPORT_Z1vQa8N], ["./pigpen-cover-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fpigpen-cipher%2Fpigpen-cipher.md", __ASTRO_IMAGE_IMPORT_Z1gRPKk], ["./header.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_Z1kYOa8], ["./0.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_Z1CqCRA], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_Z25gqfP], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_2x5UaQ], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_25g7MB], ["./4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fritual-ai%2Fritual-ai.md", __ASTRO_IMAGE_IMPORT_1Cqkpm], ["./cottex-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcottex%2Fcottex.md", __ASTRO_IMAGE_IMPORT_Z1qoRxC], ["./cottex-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcottex%2Fcottex.md", __ASTRO_IMAGE_IMPORT_2waTNH], ["./cottex-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcottex%2Fcottex.md", __ASTRO_IMAGE_IMPORT_Z7q3VE], ["./cottex-2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fcottex%2Fcottex.md", __ASTRO_IMAGE_IMPORT_Z22Hq5I], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ftracking-app%2Ftracking-app.md", __ASTRO_IMAGE_IMPORT_ZmOLNX], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ftracking-app%2Ftracking-app.md", __ASTRO_IMAGE_IMPORT_Z15X8s], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ftracking-app%2Ftracking-app.md", __ASTRO_IMAGE_IMPORT_UCOE3], ["./22.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ftracking-app%2Ftracking-app.md", __ASTRO_IMAGE_IMPORT_Zg3kif], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Ftracking-app%2Ftracking-app.md", __ASTRO_IMAGE_IMPORT_2weyC5], ["./vscode3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-git-approvers%2Fvscode-git-approvers.md", __ASTRO_IMAGE_IMPORT_Z2lx5W2], ["./vscodelogo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-git-approvers%2Fvscode-git-approvers.md", __ASTRO_IMAGE_IMPORT_ZVHqch], ["./vscode1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-console-remover%2Fvscode-console-remover.md", __ASTRO_IMAGE_IMPORT_Z1uw23P], ["./vscodelogo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-console-remover%2Fvscode-console-remover.md", __ASTRO_IMAGE_IMPORT_grF8V], ["./vscode2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-console-remover%2Fvscode-console-remover.md", __ASTRO_IMAGE_IMPORT_2be8K1], ["./Mockups_iPhone_15_Pro2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_Z2czO7H], ["./Mockups_iPhone_15_Pro.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_QN1Er], ["./icon.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_1CTGU5], ["./iPhone_14_Pro_Max_14.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_nvpQD], ["./gameover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_TiM7e], ["./gameplay.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_Zl6ooz], ["./leaderboard.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_1JdftA], ["./levels.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_16Pn3X], ["./settings.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_Z1NuW0b], ["./ship-insop.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fwaverider%2Fwaverider.md", __ASTRO_IMAGE_IMPORT_vDBly], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-px-to-tailwind%2Fvscode-px-to-tailwind.md", __ASTRO_IMAGE_IMPORT_1r5bIR], ["./vscodelogo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-px-to-tailwind%2Fvscode-px-to-tailwind.md", __ASTRO_IMAGE_IMPORT_Z2ttouv], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fvscode-px-to-tailwind%2Fvscode-px-to-tailwind.md", __ASTRO_IMAGE_IMPORT_Z4DgUb], ["./developer-type-calm-senior.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fdeveloper-personality-test%2Findex.md", __ASTRO_IMAGE_IMPORT_Z5astQ], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fdeveloper-personality-test%2Findex.md", __ASTRO_IMAGE_IMPORT_3Yj7], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fdesign-styles%2Findex.md", __ASTRO_IMAGE_IMPORT_1YvDTY], ["demo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Ffakering%2Findex.md", __ASTRO_IMAGE_IMPORT_2mOPlW], ["demo2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Ffakering%2Findex.md", __ASTRO_IMAGE_IMPORT_1Gz6sD], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Ffakering%2Findex.md", __ASTRO_IMAGE_IMPORT_1bKucg], ["./circle-8+10.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_Z29znzn], ["./circle-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_2ccPwJ], ["./circle-2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_1eJvQy], ["./circle-5.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_Z1CDr9Y], ["./circle-6.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_2u5mXL], ["./circle-7.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_1wC3iA], ["./circle-8.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_z9ICp], ["./circle-9.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-art-circles%2Findex.md", __ASTRO_IMAGE_IMPORT_ZniA2L], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Ffrom-automation-to-apps%2Findex.md", __ASTRO_IMAGE_IMPORT_ZeogX9], ["./slackbot.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fslack-points-bot%2Fslack-points-bot.md", __ASTRO_IMAGE_IMPORT_SCOSn], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_1shmpe], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_Zl6gLR], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_ZYDliN], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_Z1rt8G3], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_Z1TiV4i], ["./4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fsweetshop%2Fsweetshop.md", __ASTRO_IMAGE_IMPORT_Z2m8Irx], ["./cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmusic-production-tools-2022%2Findex.md", __ASTRO_IMAGE_IMPORT_Z9hKHe], ["./bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fherbal-ai%2Fherbal-ai.md", __ASTRO_IMAGE_IMPORT_Z5Hr3p], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fherbal-ai%2Fherbal-ai.md", __ASTRO_IMAGE_IMPORT_WoQ89], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fherbal-ai%2Fherbal-ai.md", __ASTRO_IMAGE_IMPORT_iQLBd], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fherbal-ai%2Fherbal-ai.md", __ASTRO_IMAGE_IMPORT_Z8X0L2], ["./pigpen-cipher-key.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgetting-started-with-react-native%2Findex.md", __ASTRO_IMAGE_IMPORT_Z2kmGJR], ["./pigpen-cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgetting-started-with-react-native%2Findex.md", __ASTRO_IMAGE_IMPORT_ULCmt], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-waves%2Findex.md", __ASTRO_IMAGE_IMPORT_2sT0Js], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-waves%2Findex.md", __ASTRO_IMAGE_IMPORT_ZE7c7x], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-waves%2Findex.md", __ASTRO_IMAGE_IMPORT_1i3IOo], ["./8.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fgenerative-waves%2Findex.md", __ASTRO_IMAGE_IMPORT_Sy6Vc], ["./Julianna_Margulies.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmachine-learning-lessons-learned%2Findex.md", __ASTRO_IMAGE_IMPORT_1Yo4U5], ["./cardi-b-rolling-stone-interview-cover_.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmachine-learning-lessons-learned%2Findex.md", __ASTRO_IMAGE_IMPORT_Z1ya76j], ["./1111.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmachine-learning-lessons-learned%2Findex.md", __ASTRO_IMAGE_IMPORT_E7wJu], ["./nicki-minaj.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmachine-learning-lessons-learned%2Findex.md", __ASTRO_IMAGE_IMPORT_ZBp2pT], ["./ml-lessons-cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmachine-learning-lessons-learned%2Findex.md", __ASTRO_IMAGE_IMPORT_Z1Rr2a8], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmusic-visualization-threejs%2Findex.md", __ASTRO_IMAGE_IMPORT_71qX0], ["./flamman-top.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fflamman%2Fflamman.md", __ASTRO_IMAGE_IMPORT_1T02Eo], ["./flamman-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fflamman%2Fflamman.md", __ASTRO_IMAGE_IMPORT_RD5hq], ["./flamman-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fflamman%2Fflamman.md", __ASTRO_IMAGE_IMPORT_Z15WNOf], ["./circle-8+10.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_Z1gC3UC], ["./circle-7.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_ZcMSc9], ["./circle-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_ZNv2K9], ["./circle-2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_8iP8v], ["./circle-5.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_Z26qDYs], ["./circle-6.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_Z19BL5N], ["./circle-9.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_1FORAa], ["./circle-10.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_230YTl], ["./circle-16.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_Z2qsYlA], ["./circle-17.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fgenerative-circles%2Fcircles.md", __ASTRO_IMAGE_IMPORT_Z1tE6rV], ["./harbarhett-top.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fhallbarhetsredovisning%2Fhallbarhetsredovisning.md", __ASTRO_IMAGE_IMPORT_2wdWvH], ["./hallbarhet-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fhallbarhetsredovisning%2Fhallbarhetsredovisning.md", __ASTRO_IMAGE_IMPORT_DcyMs], ["./hallbarhet-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fhallbarhetsredovisning%2Fhallbarhetsredovisning.md", __ASTRO_IMAGE_IMPORT_sMoXu], ["./44.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fholy-greens%2Fholy-greens.md", __ASTRO_IMAGE_IMPORT_ZEYfXA], ["./hg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fholy-greens%2Fholy-greens.md", __ASTRO_IMAGE_IMPORT_ZEOxHH], ["./hoolygreens -fsc.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fholy-greens%2Fholy-greens.md", __ASTRO_IMAGE_IMPORT_298KEJ], ["./gg-bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fguts-glory%2Fguts-glory.md", __ASTRO_IMAGE_IMPORT_Z14HA9R], ["./gg-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fguts-glory%2Fguts-glory.md", __ASTRO_IMAGE_IMPORT_1Cgxjx], ["./gg-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fguts-glory%2Fguts-glory.md", __ASTRO_IMAGE_IMPORT_ZsrXBb], ["./fmm-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ffolk-mat-moten%2Ffolk-mat-moten.md", __ASTRO_IMAGE_IMPORT_1qvc0U], ["./fmm-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ffolk-mat-moten%2Ffolk-mat-moten.md", __ASTRO_IMAGE_IMPORT_23bx5W], ["./fmm-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ffolk-mat-moten%2Ffolk-mat-moten.md", __ASTRO_IMAGE_IMPORT_OqGSu], ["./wsi-imageoptim-1_Oresundskraft-2048x1280.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2FKompisKlubben%2FKompisKlubben.md", __ASTRO_IMAGE_IMPORT_Z28yfnU], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2FKompisKlubben%2FKompisKlubben.md", __ASTRO_IMAGE_IMPORT_Z1nrS95], ["./felix.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkockenskamrater%2Fkockenskamrater.md", __ASTRO_IMAGE_IMPORT_ZYIME0], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkockenskamrater%2Fkockenskamrater.md", __ASTRO_IMAGE_IMPORT_Z1Uj1N7], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkockenskamrater%2Fkockenskamrater.md", __ASTRO_IMAGE_IMPORT_Z1mP5Jt], ["./bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkondomspexen%2Fkondomspexen.md", __ASTRO_IMAGE_IMPORT_ZMmmp2], ["./logo-rund.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkondomspexen%2Fkondomspexen.md", __ASTRO_IMAGE_IMPORT_Z1ih0PQ], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkondomspexen%2Fkondomspexen.md", __ASTRO_IMAGE_IMPORT_Z1YSQO8], ["./kam.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkammarkollegiet%2Fkammarkollegiet.md", __ASTRO_IMAGE_IMPORT_iL17E], ["./kammar.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkammarkollegiet%2Fkammarkollegiet.md", __ASTRO_IMAGE_IMPORT_2wPIQm], ["./kam-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkammarkollegiet%2Fkammarkollegiet.md", __ASTRO_IMAGE_IMPORT_Z1t3jIX], ["./kam-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fkammarkollegiet%2Fkammarkollegiet.md", __ASTRO_IMAGE_IMPORT_2uILNc], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmy-breakup-with-usestate%2Findex.md", __ASTRO_IMAGE_IMPORT_snA8l], ["./demo1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fweather-app%2Fweather-app.md", __ASTRO_IMAGE_IMPORT_Z106qeX], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fweather-app%2Fweather-app.md", __ASTRO_IMAGE_IMPORT_27i1UR], ["./screenshot.png?astroContentImageFlag=&importer=src%2Fcontent%2Fproducts%2Fweather-app%2Fweather-app.md", __ASTRO_IMAGE_IMPORT_Z2neByS], ["./ml-cover.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmy-first-machine-learning-project%2Findex.md", __ASTRO_IMAGE_IMPORT_Z15qMpe], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fmy-fullstack-developer-journey%2Findex.md", __ASTRO_IMAGE_IMPORT_Z28cVDN], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Freact-19-killing-usememo-usecallback%2Findex.md", __ASTRO_IMAGE_IMPORT_2cfFDw], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Ftypescript-best-practices%2Findex.md", __ASTRO_IMAGE_IMPORT_ZRcSJc], ["./cover-agile-dev-ai.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fwhy-agile-ai-coding-feels-kinda-broken%2Findex.md", __ASTRO_IMAGE_IMPORT_2aD9uQ], ["./1754388524427.png?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fwhy-i-actually-really-like-my-em%2Findex.md", __ASTRO_IMAGE_IMPORT_ZQBh2o], ["./cover2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fblog%2Fwaverider-sunday-build%2Findex.md", __ASTRO_IMAGE_IMPORT_Z2clxB5], ["./bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flugi%2Flugi.md", __ASTRO_IMAGE_IMPORT_1FRXy9], ["./lugi.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flugi%2Flugi.md", __ASTRO_IMAGE_IMPORT_eAWtG], ["./2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flugi%2Flugi.md", __ASTRO_IMAGE_IMPORT_ZYBcUB], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flugi%2Flugi.md", __ASTRO_IMAGE_IMPORT_Z2rHno2], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flundaspelen%2Flundaspelen.md", __ASTRO_IMAGE_IMPORT_BLwA3], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flundaspelen%2Flundaspelen.md", __ASTRO_IMAGE_IMPORT_Zue3D3], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flundaspelen%2Flundaspelen.md", __ASTRO_IMAGE_IMPORT_1Qi3Ca], ["./3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fljusjakten%2Fljusjakten.md", __ASTRO_IMAGE_IMPORT_ZPrBF3], ["./logo-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fljusjakten%2Fljusjakten.md", __ASTRO_IMAGE_IMPORT_hgwcK], ["./jj-1-Rotato-Snapshot.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fljusjakten%2Fljusjakten.md", __ASTRO_IMAGE_IMPORT_cHMue], ["./11.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fljusjakten%2Fljusjakten.md", __ASTRO_IMAGE_IMPORT_RWDGy], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fljusjakten%2Fljusjakten.md", __ASTRO_IMAGE_IMPORT_1FLsqs], ["./site.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Floof-foundation%2Floof-foundation.md", __ASTRO_IMAGE_IMPORT_ZYViHt], ["./looflogo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Floof-foundation%2Floof-foundation.md", __ASTRO_IMAGE_IMPORT_1jnzgB], ["./16952304466_b91c4170f5_h.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Flibrary-event-display%2Flibrary-event-display.md", __ASTRO_IMAGE_IMPORT_Z1MXsHv], ["./mockup-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmissmary%2Fmissmary.md", __ASTRO_IMAGE_IMPORT_ZoSuGx], ["./mlogo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmissmary%2Fmissmary.md", __ASTRO_IMAGE_IMPORT_10yqnU], ["./11.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmissmary%2Fmissmary.md", __ASTRO_IMAGE_IMPORT_y8J5W], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmissmary%2Fmissmary.md", __ASTRO_IMAGE_IMPORT_2lCkGE], ["./mockup-4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmissmary%2Fmissmary.md", __ASTRO_IMAGE_IMPORT_mr9kk], ["./malmo-saluhall-bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmalmo-saluhall%2Fmalmo-saluhall.md", __ASTRO_IMAGE_IMPORT_JcH8x], ["./wsi-imageoptim-5_Malmo_saluhall_2104x1315-2048x1280.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmalmo-saluhall%2Fmalmo-saluhall.md", __ASTRO_IMAGE_IMPORT_ZLeTVN], ["./malmo-saluhall-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmalmo-saluhall%2Fmalmo-saluhall.md", __ASTRO_IMAGE_IMPORT_Zp0juD], ["./malmosaluhall1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmalmo-saluhall%2Fmalmo-saluhall.md", __ASTRO_IMAGE_IMPORT_Z1WYLSt], ["./bois-home-1-1200x0-c-default.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmotesplatsip%2Fmotesplatsip.md", __ASTRO_IMAGE_IMPORT_Z2b1g6J], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmotesplatsip%2Fmotesplatsip.md", __ASTRO_IMAGE_IMPORT_29QXIV], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmotesplatsip%2Fmotesplatsip.md", __ASTRO_IMAGE_IMPORT_Bdg7i], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_1VKWCp], ["./mekonomen.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_1L0Hwc], ["./mekonomen-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_Z2sUodi], ["./4.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_ZjJSe8], ["./mekonomen-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_1t2lot], ["./mekonomen-3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen%2Fmekonomen.md", __ASTRO_IMAGE_IMPORT_Z2umVLh], ["./mekg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen-group%2Fmekonomen-group.md", __ASTRO_IMAGE_IMPORT_bHcQU], ["./mlogo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen-group%2Fmekonomen-group.md", __ASTRO_IMAGE_IMPORT_BmiHI], ["./mekonomen-g-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen-group%2Fmekonomen-group.md", __ASTRO_IMAGE_IMPORT_28f1v0], ["./mekonomen-g-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen-group%2Fmekonomen-group.md", __ASTRO_IMAGE_IMPORT_11OYee], ["./mekonomen-g-4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmekonomen-group%2Fmekonomen-group.md", __ASTRO_IMAGE_IMPORT_Z1aY5jj], ["./mm_l.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmuslimix%2Fmuslimix.md", __ASTRO_IMAGE_IMPORT_1Hl7E5], ["./2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmuslimix%2Fmuslimix.md", __ASTRO_IMAGE_IMPORT_Zs4kp5], ["./finax_flode.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmuslimix%2Fmuslimix.md", __ASTRO_IMAGE_IMPORT_1tn6Pt], ["./Knapp-ny-2-kopia.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmuslimix%2Fmuslimix.md", __ASTRO_IMAGE_IMPORT_25Qmob], ["./mm-2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fmuslimix%2Fmuslimix.md", __ASTRO_IMAGE_IMPORT_1JEukF], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_Z1Rimrm], ["./logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_muIAT], ["./bild1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_Z23KjBj], ["./l2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_Z1loD4r], ["./ngd1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_Z1gp1MB], ["./ngd2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_ZL6LKv], ["./ngd3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_ZgNwIp], ["./p3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fngd%2Fngd.md", __ASTRO_IMAGE_IMPORT_ZhoyAm], ["./noxo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fnoxo%2Fnoxo.md", __ASTRO_IMAGE_IMPORT_ZohVau], ["./noxo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fnoxo%2Fnoxo.md", __ASTRO_IMAGE_IMPORT_1J3Xbf], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsankt-lars-park%2Fsankt-lars-park.md", __ASTRO_IMAGE_IMPORT_Z2qNqbF], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsankt-lars-park%2Fsankt-lars-park.md", __ASTRO_IMAGE_IMPORT_2QXas], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsankt-lars-park%2Fsankt-lars-park.md", __ASTRO_IMAGE_IMPORT_9Rj0K], ["./enviroment.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpf-system%2Fpf-system.md", __ASTRO_IMAGE_IMPORT_178esb], ["./pfsystem.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpf-system%2Fpf-system.md", __ASTRO_IMAGE_IMPORT_Z2r5SSP], ["./Screenshot_2019-04-08-PF-System1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpf-system%2Fpf-system.md", __ASTRO_IMAGE_IMPORT_ZQRh6p], ["./Screenshot_2019-04-08-Om-oss-–-PF-System1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpf-system%2Fpf-system.md", __ASTRO_IMAGE_IMPORT_Z1LvhSU], ["./logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_ZdAMvB], ["./Drinks.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_ZUihmU], ["./Bill.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_HLw98], ["./Choose-Restaurant.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_Z1c4UQK], ["./Drinks-No-Photos.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_ZPm55O], ["./Food.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_138gH5], ["./Welcome.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fpinchis%2Fpinchos.md", __ASTRO_IMAGE_IMPORT_CMpQv], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fnoaab%2Fnoaab.md", __ASTRO_IMAGE_IMPORT_2hJBjd], ["./noalogo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fnoaab%2Fnoaab.md", __ASTRO_IMAGE_IMPORT_DRmg3], ["./site.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fnoaab%2Fnoaab.md", __ASTRO_IMAGE_IMPORT_Z2lAbxW], ["./redfellaslogo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fredfellas%2Fredfellas.md", __ASTRO_IMAGE_IMPORT_Z2mG6C5], ["./redfellassite.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fredfellas%2Fredfellas.md", __ASTRO_IMAGE_IMPORT_Z1svvTN], ["./roofit-garanti-image.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Froofit%2Froofit.md", __ASTRO_IMAGE_IMPORT_W6tbY], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Froofit%2Froofit.md", __ASTRO_IMAGE_IMPORT_1EOVh2], ["./12.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Froofit%2Froofit.md", __ASTRO_IMAGE_IMPORT_ZlQ4OU], ["./3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Froofit%2Froofit.md", __ASTRO_IMAGE_IMPORT_Z1Odeza], ["./original.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskaneleden%2Fskaneleden.md", __ASTRO_IMAGE_IMPORT_YaVMy], ["./logo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskaneleden%2Fskaneleden.md", __ASTRO_IMAGE_IMPORT_ZOnqrr], ["./bg.webp?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanska-landskap%2Fskanska-landskap.md", __ASTRO_IMAGE_IMPORT_7QHRz], ["./logo1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanska-landskap%2Fskanska-landskap.md", __ASTRO_IMAGE_IMPORT_Z2lwsIr], ["./bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanskahandboll%2Fskanskahandboll.md", __ASTRO_IMAGE_IMPORT_73eSl], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanskahandboll%2Fskanskahandboll.md", __ASTRO_IMAGE_IMPORT_2ag328], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanskahandboll%2Fskanskahandboll.md", __ASTRO_IMAGE_IMPORT_2hgnRq], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fskanskahandboll%2Fskanskahandboll.md", __ASTRO_IMAGE_IMPORT_1BjVO0], ["./bg.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsoctanter%2Fsoctanter.md", __ASTRO_IMAGE_IMPORT_ZRhFHd], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsoctanter%2Fsoctanter.md", __ASTRO_IMAGE_IMPORT_1cdGfs], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsoctanter%2Fsoctanter.md", __ASTRO_IMAGE_IMPORT_1rcXie], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fsoctanter%2Fsoctanter.md", __ASTRO_IMAGE_IMPORT_Z2wcjRw], ["./ts.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fai.md", __ASTRO_IMAGE_IMPORT_Z22yJ1a], ["./telavox-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fai.md", __ASTRO_IMAGE_IMPORT_Z6niSf], ["./logo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fai.md", __ASTRO_IMAGE_IMPORT_1vR7Hq], ["./telavox-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fai.md", __ASTRO_IMAGE_IMPORT_ZqvOlM], ["./chat.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fchat.md", __ASTRO_IMAGE_IMPORT_Iw4sb], ["./telavox-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fchat.md", __ASTRO_IMAGE_IMPORT_Z6niSf], ["./logo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fchat.md", __ASTRO_IMAGE_IMPORT_1vR7Hq], ["./telavox-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fchat.md", __ASTRO_IMAGE_IMPORT_ZqvOlM], ["./telavox-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Ffeature-flags.md", __ASTRO_IMAGE_IMPORT_Z6niSf], ["./telavox2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Ffeature-flags.md", __ASTRO_IMAGE_IMPORT_vLsQ0], ["./logo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Ffeature-flags.md", __ASTRO_IMAGE_IMPORT_1vR7Hq], ["./telavox-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Ffeature-flags.md", __ASTRO_IMAGE_IMPORT_ZqvOlM], ["./11Smart-city_1920x1080px_utan-text.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fstadshubbsalliansen%2Fstadshubbsalliansen.md", __ASTRO_IMAGE_IMPORT_Z1LtYJq], ["./SHA-Rotato-Snapshot.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fstadshubbsalliansen%2Fstadshubbsalliansen.md", __ASTRO_IMAGE_IMPORT_cMWKT], ["./Screenshot_2019-04-01-StadshubbsAlliansen1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fstadshubbsalliansen%2Fstadshubbsalliansen.md", __ASTRO_IMAGE_IMPORT_1zdqWR], ["./telavox-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvideo.md", __ASTRO_IMAGE_IMPORT_Z6niSf], ["./telavox-app.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvideo.md", __ASTRO_IMAGE_IMPORT_Z10sGMV], ["./logo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvideo.md", __ASTRO_IMAGE_IMPORT_1vR7Hq], ["./telavox-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvideo.md", __ASTRO_IMAGE_IMPORT_ZqvOlM], ["./telavox-top.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_Z6niSf], ["./telavoxcv.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_YOQTS], ["./logo1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_1vR7Hq], ["./telavox-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_ZqvOlM], ["./telavox-app.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_Z10sGMV], ["./tvx-app.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelavox%2Fvisual-refresh.md", __ASTRO_IMAGE_IMPORT_Z2bkUi4], ["./11.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_23NHa7], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_2tkwHp], ["./4t.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_ZnttIp], ["./5t.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_1Nr7hK], ["./6t.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_Z14Opv1], ["./databse.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftelenor%2Ftelenor.md", __ASTRO_IMAGE_IMPORT_Z1HTCzO], ["./11.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fthefanclub%2Fthefanclub.md", __ASTRO_IMAGE_IMPORT_2otYyN], ["./thefanclublogo.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fthefanclub%2Fthefanclub.md", __ASTRO_IMAGE_IMPORT_pxWjM], ["./site.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fthefanclub%2Fthefanclub.md", __ASTRO_IMAGE_IMPORT_CwL9h], ["./conv-model.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fthefanclub%2Fthefanclub.md", __ASTRO_IMAGE_IMPORT_Z2tWXu4], ["./a8d4df00100196c9_800x800ar.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fthefanclub%2Fthefanclub.md", __ASTRO_IMAGE_IMPORT_Z17bv02], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftwilfit%2Ftwilfit.md", __ASTRO_IMAGE_IMPORT_22sEeL], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftwilfit%2Ftwilfit.md", __ASTRO_IMAGE_IMPORT_izeYg], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftwilfit%2Ftwilfit.md", __ASTRO_IMAGE_IMPORT_E5Ynu], ["./vgardar.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fvaragardar%2Fvaragardar.md", __ASTRO_IMAGE_IMPORT_XNHpF], ["./VG_logotyp_vit-300x300.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fvaragardar%2Fvaragardar.md", __ASTRO_IMAGE_IMPORT_Zht4Da], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Funilever-food-solutions%2Funilever-food-solutions.md", __ASTRO_IMAGE_IMPORT_1jGVBt], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Funilever-food-solutions%2Funilever-food-solutions.md", __ASTRO_IMAGE_IMPORT_ZF8M0W], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Funilever-food-solutions%2Funilever-food-solutions.md", __ASTRO_IMAGE_IMPORT_Z2iULOr], ["./3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Funilever-food-solutions%2Funilever-food-solutions.md", __ASTRO_IMAGE_IMPORT_ZQmmrq], ["./toolpool-top1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_1DVBC3], ["./toolpool.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_9QgE9], ["./toolpool-4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_ZiTc57], ["./toolpool-top.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_ZfsKIB], ["./toolpool-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_Z15eQ6Y], ["./toolpool-3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_Z2g5823], ["./site-1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftoolpool%2Ftoolpool.md", __ASTRO_IMAGE_IMPORT_guhQ4], ["./map.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftriwa%2Ftriwa.md", __ASTRO_IMAGE_IMPORT_19UUjr], ["./triwa.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftriwa%2Ftriwa.md", __ASTRO_IMAGE_IMPORT_ZumGiN], ["./home.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Ftriwa%2Ftriwa.md", __ASTRO_IMAGE_IMPORT_Z2ae2Mp], ["./vivere.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fvivere%2Fvivere.md", __ASTRO_IMAGE_IMPORT_Z1H7044], ["./sitevv.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fvivere%2Fvivere.md", __ASTRO_IMAGE_IMPORT_kldY5], ["./site-small.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwhitespace%2Fwhitespace.md", __ASTRO_IMAGE_IMPORT_ZzxzTF], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwhitespace%2Fwhitespace.md", __ASTRO_IMAGE_IMPORT_ebzJ6], ["./site.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwhitespace%2Fwhitespace.md", __ASTRO_IMAGE_IMPORT_Z85ypR], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_y57Dg], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_RQTjE], ["./wilfa_rgb_blue.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_2iPLO0], ["./0.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_1Vz9Rl], ["./00.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_1QFRlK], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_Z1sJmwJ], ["./3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_ZlS5tK], ["./33.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fwilfa%2FWilfa.md", __ASTRO_IMAGE_IMPORT_ZCl9Lj], ["./bg.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_Z1iivdG], ["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_JCMxn], ["./1.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_ZlGIlV], ["./2.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_Z11Wsff], ["./3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_Z1Hdc8y], ["./33.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_2h93Ar], ["./wframe.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest%2Fzest.md", __ASTRO_IMAGE_IMPORT_Z1FyfTq], ["./fb2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest-hmd%2Fzest-hmd.md", __ASTRO_IMAGE_IMPORT_2c6tE5], ["./1-3.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest-hmd%2Fzest-hmd.md", __ASTRO_IMAGE_IMPORT_Z2WxjT], ["./1-1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzest-hmd%2Fzest-hmd.md", __ASTRO_IMAGE_IMPORT_17RIAa], ["./1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_Z1px57i], ["./zt-w1.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_ZmrEtj], ["./2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_wCPOD], ["./4.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_Z1CHa6K], ["./3.jpg?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_1uj2Kf], ["./111.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_2ajrrm], ["./1-2.png?astroContentImageFlag=&importer=src%2Fcontent%2Fportfolio%2Fzhowtime%2Fzhowtime.md", __ASTRO_IMAGE_IMPORT_QCp6l]]);

export { contentAssets as default };
