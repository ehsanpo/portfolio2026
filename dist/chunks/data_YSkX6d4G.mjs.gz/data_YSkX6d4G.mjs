import { a as getCollection } from './Layout_z3Z6Yi9L.mjs';

const getPortfolioItems = async () => {
  const portfolioEntries = await getCollection("portfolio");
  return portfolioEntries.map((entry) => ({
    ...entry.data,
    slug: entry.slug,
    background_image: entry.data.background_image,
    logo: entry.data.logo,
    bilder: entry.data.images,
    content: entry
  }));
};
const getProductItems = async () => {
  const productEntries = await getCollection("products");
  return productEntries.map((entry) => ({
    ...entry.data,
    slug: entry.slug,
    background_image: entry.data.background_image,
    logo: entry.data.logo,
    bilder: entry.data.images,
    content: entry
  }));
};
const getBlogPosts = async () => {
  const blogEntries = await getCollection("blog", ({ data }) => {
    return data.draft !== true;
  });
  return blogEntries.map(
    (entry) => ({
      title: entry.data.title,
      description: entry.data.description,
      date: entry.data.date,
      author: entry.data.author,
      category: entry.data.category,
      tag: entry.data.tag,
      cover: entry.data.cover,
      featured: entry.data.featured,
      slug: entry.slug,
      content: entry
    })
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};
const getPrompts = async () => {
  const promptEntries = await getCollection("prompt");
  return promptEntries.map((entry) => ({
    title: entry.data.title,
    description: entry.data.description,
    category: entry.data.category,
    tags: entry.data.tags,
    order: entry.data.order,
    icon: entry.data.icon,
    image: entry.data.image?.src,
    slug: entry.slug,
    content: entry
  })).sort((a, b) => (a.order || 999) - (b.order || 999));
};

export { getPortfolioItems as a, getProductItems as b, getPrompts as c, getBlogPosts as g };
