import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { useState, useRef, useMemo, useEffect } from 'react';
import { Grid3X3, X, Link2, ExternalLink, ChevronUp, ChevronDown, Play, Music2, Github, ImageIcon } from 'lucide-react';
import { a as getCollection } from './Layout_z3Z6Yi9L.mjs';

const WHEEL_LOCK_MS = 260;
const SWIPE_THRESHOLD = 50;
const postTypeLabel = {
  image: "Image",
  video: "Video",
  link: "Link",
  tiktok: "TikTok",
  github: "GitHub"
};
const getPostIcon = (kind) => {
  if (kind === "video") return Play;
  if (kind === "link") return Link2;
  if (kind === "tiktok") return Music2;
  if (kind === "github") return Github;
  return ImageIcon;
};
const fallbackGradient = "bg-linear-to-br from-secondary-700 via-accent-700 to-primary-500 dark:from-secondary-900 dark:via-accent-900 dark:to-primary-800";
const getSlugFromPath = () => {
  if (typeof window === "undefined") return null;
  const parts = window.location.pathname.split("/").filter(Boolean);
  if (parts[0] !== "social") return null;
  if (parts.length < 2) return null;
  return decodeURIComponent(parts[1]);
};
const setPath = (pathname, mode = "push") => {
  if (typeof window === "undefined") return;
  const target = pathname.startsWith("/") ? pathname : `/${pathname}`;
  if (mode === "replace") {
    window.history.replaceState({}, "", target);
    return;
  }
  window.history.pushState({}, "", target);
};
const formatPostDate = (value) => {
  if (!value) return null;
  const parsed = Date.parse(value);
  if (Number.isNaN(parsed)) return value;
  return new Intl.DateTimeFormat(void 0, {
    year: "numeric",
    month: "short",
    day: "numeric"
  }).format(new Date(parsed));
};
const renderPostMedia = (post, mode) => {
  const Icon = getPostIcon(post.kind);
  const fallback = /* @__PURE__ */ jsx(
    "div",
    {
      className: `flex h-full w-full items-center justify-center ${fallbackGradient} text-white`,
      "aria-label": `${post.title} placeholder`,
      children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-3", children: [
        /* @__PURE__ */ jsx(Icon, { className: "h-10 w-10 opacity-90" }),
        /* @__PURE__ */ jsx("span", { className: "px-6 text-center text-sm font-semibold", children: post.title })
      ] })
    }
  );
  if (post.kind === "tiktok") {
    if (mode === "feed" && post.embedUrl) {
      return /* @__PURE__ */ jsx(
        "iframe",
        {
          src: post.embedUrl,
          title: post.title,
          className: "h-full w-full border-0 bg-black",
          allowFullScreen: true,
          allow: "fullscreen",
          loading: "lazy"
        }
      );
    }
    return fallback;
  }
  if (post.kind === "github") {
    return /* @__PURE__ */ jsxs("div", { className: "h-full w-full bg-neutral-950 p-5 text-white", children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-3 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-wide", children: [
        /* @__PURE__ */ jsx(Github, { className: "h-3.5 w-3.5" }),
        "GitHub Star"
      ] }),
      /* @__PURE__ */ jsx("h4", { className: "line-clamp-2 text-lg font-semibold", children: post.title }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 line-clamp-7 text-sm text-white/80", children: post.caption })
    ] });
  }
  if (!post.mediaUrl) {
    return fallback;
  }
  if (post.kind === "video") {
    return /* @__PURE__ */ jsx(
      "video",
      {
        src: post.mediaUrl,
        className: "h-full w-full object-cover",
        autoPlay: true,
        loop: true,
        muted: true,
        playsInline: true,
        preload: mode === "feed" ? "metadata" : "none"
      }
    );
  }
  return /* @__PURE__ */ jsx("img", { src: post.mediaUrl, alt: post.title, className: "h-full w-full object-cover" });
};
function SocialGridFeed({
  posts,
  initialPostSlug,
  startInFeed = false,
  initialGridCount = 8,
  gridBatchSize = 6
}) {
  const [activeIndex, setActiveIndex] = useState(null);
  const [visibleCount, setVisibleCount] = useState(() => Math.max(initialGridCount, 1));
  const wheelLockedRef = useRef(false);
  const touchStartYRef = useRef(null);
  const loadMoreRef = useRef(null);
  const activePost = activeIndex === null ? null : posts[activeIndex];
  const disableOutboundActions = activePost?.kind === "tiktok" || activePost?.kind === "github";
  const visiblePosts = useMemo(
    () => posts.slice(0, Math.min(visibleCount, posts.length)),
    [posts, visibleCount]
  );
  const closeFeed = (mode = "push") => {
    setActiveIndex(null);
    setPath("/social", mode);
  };
  const openFeedAt = (index, mode = "push") => {
    if (index < 0 || index >= posts.length) return;
    setActiveIndex(index);
    setPath(`/social/${posts[index].slug}`, mode);
  };
  const navigate = (direction) => {
    if (activeIndex === null) return;
    const nextIndex = Math.max(0, Math.min(posts.length - 1, activeIndex + direction));
    if (nextIndex === activeIndex) return;
    openFeedAt(nextIndex, "push");
  };
  const handleWheel = (event) => {
    event.preventDefault();
    if (wheelLockedRef.current) return;
    if (Math.abs(event.deltaY) < 20) return;
    navigate(event.deltaY > 0 ? 1 : -1);
    wheelLockedRef.current = true;
    window.setTimeout(() => {
      wheelLockedRef.current = false;
    }, WHEEL_LOCK_MS);
  };
  const handleTouchStart = (event) => {
    touchStartYRef.current = event.changedTouches[0]?.clientY ?? null;
  };
  const handleTouchEnd = (event) => {
    if (touchStartYRef.current === null) return;
    const touchEndY = event.changedTouches[0]?.clientY ?? touchStartYRef.current;
    const delta = touchStartYRef.current - touchEndY;
    touchStartYRef.current = null;
    if (Math.abs(delta) < SWIPE_THRESHOLD) return;
    navigate(delta > 0 ? 1 : -1);
  };
  useEffect(() => {
    if (!posts.length) return;
    const pathSlug = getSlugFromPath();
    const preferredSlug = pathSlug || initialPostSlug || null;
    if (!preferredSlug) {
      setActiveIndex(startInFeed ? 0 : null);
      return;
    }
    const nextIndex = posts.findIndex((post) => post.slug === preferredSlug);
    if (nextIndex !== -1) {
      setActiveIndex(nextIndex);
      return;
    }
    if (startInFeed) {
      setActiveIndex(0);
      setPath(`/social/${posts[0].slug}`, "replace");
    }
  }, [posts, initialPostSlug, startInFeed]);
  useEffect(() => {
    const onPopState = () => {
      const pathSlug = getSlugFromPath();
      if (!pathSlug) {
        setActiveIndex(null);
        return;
      }
      const nextIndex = posts.findIndex((post) => post.slug === pathSlug);
      if (nextIndex !== -1) {
        setActiveIndex(nextIndex);
      }
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [posts]);
  useEffect(() => {
    if (activeIndex === null) return;
    const onKeyDown = (event) => {
      if (event.key === "Escape") closeFeed("push");
      if (event.key === "ArrowDown" || event.key.toLowerCase() === "j") navigate(1);
      if (event.key === "ArrowUp" || event.key.toLowerCase() === "k") navigate(-1);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activeIndex, posts]);
  useEffect(() => {
    if (activeIndex === null) return;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, [activeIndex]);
  useEffect(() => {
    if (activeIndex !== null) return;
    if (visibleCount >= posts.length) return;
    const node = loadMoreRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries[0]?.isIntersecting) return;
        setVisibleCount((count) => Math.min(posts.length, count + gridBatchSize));
      },
      { root: null, rootMargin: "220px" }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [activeIndex, visibleCount, posts.length, gridBatchSize]);
  if (!posts.length) {
    return /* @__PURE__ */ jsx("div", { className: "rounded-2xl border border-black/10 p-8 text-center dark:border-white/10", children: /* @__PURE__ */ jsx("p", { className: "text-neutral-600 dark:text-neutral-300", children: "No social posts added yet." }) });
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsx("h2", { className: "font-basement text-3xl text-neutral-900 dark:text-white", children: "Latest posts" }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-neutral-600 dark:text-neutral-300", children: "Open any card and navigate post-by-post with wheel/swipe/arrow keys." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4", children: visiblePosts.map((post, index) => {
      const Icon = getPostIcon(post.kind);
      return /* @__PURE__ */ jsxs(
        "button",
        {
          type: "button",
          onClick: () => openFeedAt(index, "push"),
          className: "group relative overflow-hidden rounded-3xl border border-black/10 bg-black text-left shadow-md transition-transform hover:-translate-y-1 hover:shadow-xl dark:border-white/10",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "aspect-[9/16] overflow-hidden", children: [
              renderPostMedia(post, "grid"),
              post.kind === "link" && /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-black/25" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "absolute inset-x-0 bottom-0 space-y-2 bg-gradient-to-t from-black to-transparent p-3 text-white", children: [
              /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full border border-white/25 bg-black/30 px-2 py-1 text-[11px] uppercase", children: [
                /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5" }),
                postTypeLabel[post.kind]
              ] }) }),
              /* @__PURE__ */ jsx("p", { className: "line-clamp-2 text-sm leading-snug font-semibold", children: post.title }),
              post.date && /* @__PURE__ */ jsx("p", { className: "text-[11px] text-white/75", children: formatPostDate(post.date) })
            ] })
          ]
        },
        post.id
      );
    }) }),
    visibleCount < posts.length && /* @__PURE__ */ jsxs("div", { className: "mt-8 flex justify-center", children: [
      /* @__PURE__ */ jsx("div", { ref: loadMoreRef, className: "h-8 w-full", "aria-hidden": "true" }),
      /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          onClick: () => setVisibleCount((count) => Math.min(posts.length, count + gridBatchSize)),
          className: "rounded-full border border-black/15 bg-white/80 px-4 py-2 text-sm font-semibold text-black backdrop-blur dark:border-white/20 dark:bg-black/40 dark:text-white",
          children: "Load more posts"
        }
      )
    ] }),
    activePost && /* @__PURE__ */ jsxs(
      "div",
      {
        className: "fixed inset-0 z-[200] bg-black",
        onWheel: handleWheel,
        onTouchStart: handleTouchStart,
        onTouchEnd: handleTouchEnd,
        children: [
          /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute top-4 left-4 right-4 z-20 flex items-center justify-between", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => closeFeed("push"),
                className: "pointer-events-auto inline-flex items-center gap-2 rounded-full border border-white/25 bg-black/60 px-4 py-2 text-sm font-semibold text-white backdrop-blur-sm",
                children: [
                  /* @__PURE__ */ jsx(Grid3X3, { className: "h-4 w-4" }),
                  "Back to grid"
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => closeFeed("push"),
                className: "pointer-events-auto rounded-full border border-white/25 bg-black/60 p-2 text-white backdrop-blur-sm",
                "aria-label": "Close feed",
                children: /* @__PURE__ */ jsx(X, { className: "h-5 w-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 overflow-hidden", children: [
            activePost.mediaUrl ? /* @__PURE__ */ jsx(
              "img",
              {
                src: activePost.mediaUrl,
                alt: "",
                "aria-hidden": "true",
                className: "h-full w-full scale-110 object-cover opacity-30 blur-3xl"
              }
            ) : /* @__PURE__ */ jsx("div", { "aria-hidden": "true", className: `h-full w-full ${fallbackGradient}` }),
            /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-black/65" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "relative flex h-full items-center justify-center p-4 sm:p-6", children: [
            /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-[430px]", children: /* @__PURE__ */ jsxs("div", { className: "relative aspect-[9/16] overflow-hidden rounded-[2.25rem] border border-white/15 bg-black shadow-[0_30px_90px_rgba(0,0,0,0.65)]", children: [
              renderPostMedia(activePost, "feed"),
              activePost.kind === "link" && /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute inset-0 bg-black/30" }),
              /* @__PURE__ */ jsxs("div", { className: "absolute inset-x-0 bottom-0 space-y-3 bg-gradient-to-t from-black via-black/70 to-transparent p-5 text-white", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxs("span", { className: "inline-flex items-center gap-1 rounded-full border border-white/25 bg-black/40 px-2 py-1 text-[11px] uppercase tracking-wide", children: [
                    (() => {
                      const Icon = getPostIcon(activePost.kind);
                      return /* @__PURE__ */ jsx(Icon, { className: "h-3.5 w-3.5" });
                    })(),
                    postTypeLabel[activePost.kind]
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "text-right", children: [
                    activePost.date && /* @__PURE__ */ jsx("div", { className: "text-xs text-white/70", children: formatPostDate(activePost.date) }),
                    /* @__PURE__ */ jsxs("div", { className: "text-xs text-white/70", children: [
                      activeIndex + 1,
                      "/",
                      posts.length
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsx("h3", { className: "font-basement text-3xl leading-tight", children: activePost.title }),
                /* @__PURE__ */ jsx("p", { className: "text-sm leading-relaxed text-white/90", children: activePost.caption }),
                !disableOutboundActions && /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-2", children: [
                  /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: activePost.permalink,
                      className: "inline-flex items-center gap-2 rounded-full border border-white/30 bg-black/40 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-black/60",
                      children: [
                        "Post link",
                        /* @__PURE__ */ jsx(Link2, { className: "h-4 w-4" })
                      ]
                    }
                  ),
                  activePost.href && /* @__PURE__ */ jsxs(
                    "a",
                    {
                      href: activePost.href,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-black transition-colors hover:bg-white/90",
                      children: [
                        activePost.ctaLabel ?? "Open link",
                        /* @__PURE__ */ jsx(ExternalLink, { className: "h-4 w-4" })
                      ]
                    }
                  )
                ] })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxs("div", { className: "pointer-events-none absolute right-4 top-1/2 hidden -translate-y-1/2 flex-col gap-3 sm:flex", children: [
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => navigate(-1),
                  disabled: activeIndex <= 0,
                  className: "pointer-events-auto rounded-full border border-white/25 bg-black/50 p-2 text-white disabled:cursor-not-allowed disabled:opacity-40",
                  "aria-label": "Previous post",
                  children: /* @__PURE__ */ jsx(ChevronUp, { className: "h-5 w-5" })
                }
              ),
              /* @__PURE__ */ jsx(
                "button",
                {
                  type: "button",
                  onClick: () => navigate(1),
                  disabled: activeIndex >= posts.length - 1,
                  className: "pointer-events-auto rounded-full border border-white/25 bg-black/50 p-2 text-white disabled:cursor-not-allowed disabled:opacity-40",
                  "aria-label": "Next post",
                  children: /* @__PURE__ */ jsx(ChevronDown, { className: "h-5 w-5" })
                }
              )
            ] })
          ] })
        ]
      }
    )
  ] });
}

const DEFAULT_SOCIAL_ORDER = 999;
const DEFAULT_GITHUB_ORDER_BASE = 1300;
const DEFAULT_GITHUB_FROM_DATE = "2026-01-01";
const GITHUB_PER_PAGE = 100;
let cachedSocialPostsPromise = null;
const slugify = (value) => value.toLowerCase().trim().replace(/['"]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const toDateScore = (value) => {
  if (!value) return Number.NEGATIVE_INFINITY;
  const score = Date.parse(value);
  return Number.isNaN(score) ? Number.NEGATIVE_INFINITY : score;
};
const withUniqueSlugs = (posts) => {
  const used = /* @__PURE__ */ new Set();
  return posts.map((post, index) => {
    const baseSlug = slugify(post.slug) || `post-${index + 1}`;
    let nextSlug = baseSlug;
    let suffix = 2;
    while (used.has(nextSlug)) {
      nextSlug = `${baseSlug}-${suffix}`;
      suffix += 1;
    }
    used.add(nextSlug);
    return {
      ...post,
      id: post.id || nextSlug,
      slug: nextSlug,
      permalink: `/social/${nextSlug}`
    };
  });
};
const getGitHubStarPosts = async (githubConfig) => {
  if (!githubConfig || githubConfig.enabled === false) return [];
  const fromDateRaw = githubConfig.fromDate ?? DEFAULT_GITHUB_FROM_DATE;
  const fromDateScore = Date.parse(fromDateRaw);
  const cutoffScore = Number.isNaN(fromDateScore) ? Date.parse(DEFAULT_GITHUB_FROM_DATE) : fromDateScore;
  const headers = {
    Accept: "application/vnd.github.star+json",
    "User-Agent": "portfolio-social-feed"
  };
  try {
    const starItems = [];
    for (let page = 1; ; page += 1) {
      const requestUrl = `https://api.github.com/users/${encodeURIComponent(githubConfig.username)}/starred?per_page=${GITHUB_PER_PAGE}&page=${page}`;
      const response = await fetch(requestUrl, { headers });
      if (!response.ok) {
        console.warn(`[social] GitHub stars fetch failed with status ${response.status}`);
        break;
      }
      const pageItems = await response.json();
      if (!Array.isArray(pageItems) || pageItems.length === 0) {
        break;
      }
      starItems.push(...pageItems);
      if (pageItems.length < GITHUB_PER_PAGE) {
        break;
      }
    }
    if (!starItems.length) return [];
    return starItems.map((item, index) => {
      const repo = item.repo ?? item;
      if (!repo.full_name || !repo.html_url) return null;
      if (githubConfig.includeForks === false && repo.fork) return null;
      const starDateScore = Date.parse(
        item.starred_at ?? repo.updated_at ?? repo.pushed_at ?? ""
      );
      if (Number.isNaN(starDateScore) || starDateScore < cutoffScore) return null;
      const stats = [
        typeof repo.stargazers_count === "number" ? `${repo.stargazers_count.toLocaleString()} stars` : null,
        typeof repo.forks_count === "number" ? `${repo.forks_count.toLocaleString()} forks` : null
      ].filter(Boolean);
      return {
        id: `github-${repo.full_name.toLowerCase()}`,
        slug: `github-star-${repo.full_name}`,
        permalink: "",
        kind: "github",
        title: repo.full_name,
        caption: (repo.description && repo.description.trim().length > 0 ? repo.description.trim() : "Repository from my GitHub stars.") + (stats.length ? ` (${stats.join(" - ")})` : ""),
        date: item.starred_at ?? repo.updated_at ?? repo.pushed_at,
        order: DEFAULT_GITHUB_ORDER_BASE + index
      };
    }).filter((post) => Boolean(post));
  } catch (error) {
    console.warn("[social] GitHub stars fetch failed.", error);
    return [];
  }
};
const loadSocialPosts = async () => {
  const [socialEntries, socialSourceEntries] = await Promise.all([
    getCollection("social"),
    getCollection("socialSources")
  ]);
  const sourceConfig = socialSourceEntries.find((entry) => entry.id === "feed") ?? socialSourceEntries[0];
  const manualPosts = socialEntries.map((entry) => ({
    id: entry.slug,
    slug: entry.slug,
    permalink: `/social/${entry.slug}`,
    kind: entry.data.kind,
    title: entry.data.title,
    caption: entry.data.caption,
    date: entry.data.date,
    mediaUrl: entry.data.mediaUrl,
    embedUrl: entry.data.embedUrl,
    href: entry.data.href,
    ctaLabel: entry.data.ctaLabel,
    order: entry.data.order ?? DEFAULT_SOCIAL_ORDER
  }));
  const tiktokPosts = (sourceConfig?.data.tiktokEmbeds ?? []).map(
    (item, index) => ({
      id: `tiktok-${item.slug ?? index + 1}`,
      slug: item.slug ?? `tiktok-${item.title}-${item.date}`,
      permalink: "",
      kind: "tiktok",
      title: item.title,
      caption: item.caption ?? "TikTok embed post.",
      date: item.date,
      embedUrl: item.embedUrl,
      href: item.href,
      ctaLabel: item.ctaLabel ?? "Watch on TikTok",
      order: item.order ?? 500 + index
    })
  );
  const githubPosts = await getGitHubStarPosts(sourceConfig?.data.github);
  return withUniqueSlugs([...manualPosts, ...tiktokPosts, ...githubPosts]).sort((a, b) => {
    if (a.order !== b.order) return a.order - b.order;
    const dateDiff = toDateScore(b.date) - toDateScore(a.date);
    if (dateDiff !== 0) return dateDiff;
    return a.title.localeCompare(b.title);
  });
};
const getSocialPosts = async () => {
  if (!cachedSocialPostsPromise) {
    cachedSocialPostsPromise = loadSocialPosts();
  }
  return cachedSocialPostsPromise;
};

export { SocialGridFeed as S, getSocialPosts as g };
