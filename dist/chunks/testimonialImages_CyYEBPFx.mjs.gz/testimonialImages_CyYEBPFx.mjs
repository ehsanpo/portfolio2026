const asger = new Proxy({"src":"/_astro/asger.Y0o9SzkX.jpg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/asger.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/asger.jpg");
							return target[name];
						}
					});

const desire = new Proxy({"src":"/_astro/desire.JGQ9Kbg4.jpeg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/desire.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/desire.jpeg");
							return target[name];
						}
					});

const lenny = new Proxy({"src":"/_astro/lenny.DziwZYpS.jpg","width":566,"height":566,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/lenny.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/lenny.jpg");
							return target[name];
						}
					});

const jony = new Proxy({"src":"/_astro/jony.XkJr-IIj.jpg","width":450,"height":450,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/jony.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/jony.jpg");
							return target[name];
						}
					});

const heshan = new Proxy({"src":"/_astro/heshan.rU0gOFyI.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/heshan.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/heshan.jpg");
							return target[name];
						}
					});

const fredrik2 = new Proxy({"src":"/_astro/fredrik2.BKX3HqGu.jpg","width":375,"height":375,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/fredrik2.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/fredrik2.jpg");
							return target[name];
						}
					});

const timothy = new Proxy({"src":"/_astro/timothy.C9wdZai2.jpg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/timothy.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/timothy.jpg");
							return target[name];
						}
					});

const erfan = new Proxy({"src":"/_astro/erfan.CbzhnEBd.jpg","width":120,"height":120,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/erfan.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/erfan.jpg");
							return target[name];
						}
					});

const rebecca = new Proxy({"src":"/_astro/rebecca.BO-DtqIV.jpg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/rebecca.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/rebecca.jpg");
							return target[name];
						}
					});

const fredrik = new Proxy({"src":"/_astro/fredrik.CipriE2C.jpg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/fredrik.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/fredrik.jpg");
							return target[name];
						}
					});

const david = new Proxy({"src":"/_astro/david.CoqJjBxn.jpg","width":200,"height":200,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/david.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/david.jpg");
							return target[name];
						}
					});

const klas = new Proxy({"src":"/_astro/klas.DmocKHLL.jpg","width":800,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/klas.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/testimonial/klas.jpg");
							return target[name];
						}
					});

const imageMap = {
  "/img/testimonial/asger.jpg": asger,
  "/img/testimonial/desire.jpeg": desire,
  "/img/testimonial/lenny.jpg": lenny,
  "/img/testimonial/jony.jpg": jony,
  "/img/testimonial/heshan.jpg": heshan,
  "/img/testimonial/fredrik2.jpg": fredrik2,
  "/img/testimonial/timothy.jpg": timothy,
  "/img/testimonial/erfan.jpg": erfan,
  "/img/testimonial/rebecca.jpg": rebecca,
  "/img/testimonial/fredrik.jpg": fredrik,
  "/img/testimonial/david.jpg": david,
  "/img/testimonial/klas.jpg": klas
};
function getTestimonialImage(path) {
  const image = imageMap[path];
  return image ? image.src : path;
}

export { getTestimonialImage as g };
