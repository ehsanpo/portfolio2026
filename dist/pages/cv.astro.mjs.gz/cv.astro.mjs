import { c as createComponent, r as renderComponent, b as renderTemplate } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { useState, useEffect } from 'react';
import { Languages, Download, MapPin, Mail, Globe, Linkedin } from 'lucide-react';
import { p as portfolioData, $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
/* empty css                              */
export { renderers } from '../renderers.mjs';

const Toolbar = ({
  onColorChange,
  onLanguageChange,
  onExportPDF,
  currentLanguage
}) => {
  const colors = ["#0891b2", "#4f46e5", "#059669", "#db2777", "#d97706"];
  return /* @__PURE__ */ jsx("div", { className: "fixed top-16 right-0 left-0 z-50 bg-white shadow-md print:hidden", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto flex max-w-4xl items-center justify-between px-4 py-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
      /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: colors.map((color) => /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => onColorChange(color),
          className: "h-6 w-6 rounded-full border-2 border-gray-200",
          style: { backgroundColor: color }
        },
        color
      )) }),
      /* @__PURE__ */ jsx(
        "button",
        {
          onClick: () => onLanguageChange(currentLanguage === "en" ? "sv" : "en"),
          className: "rounded-lg p-2 hover:bg-gray-100",
          children: /* @__PURE__ */ jsx(Languages, { className: "text-primary-500 h-5 w-5" })
        }
      )
    ] }),
    /* @__PURE__ */ jsx("button", { onClick: onExportPDF, className: "rounded-lg bg-slate-300 p-2 hover:bg-gray-100", children: /* @__PURE__ */ jsx(Download, { className: "h-5 w-5" }) })
  ] }) });
};

const Timeline = ({ items, mainColor }) => {
  function calculateDuration(startDate, endDate) {
    const parseDate = (date) => {
      const parts = date.split("-");
      const year = parseInt(parts[0], 10);
      const month = parts.length > 1 ? parseInt(parts[1], 10) - 1 : 0;
      return new Date(year, month);
    };
    const start = parseDate(startDate);
    const end = parseDate(endDate);
    const yearsDiff = end.getFullYear() - start.getFullYear();
    let monthsDiff = end.getMonth() - start.getMonth();
    if (monthsDiff < 0) {
      monthsDiff += 12;
    }
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      yearsDiff > 0 && ` ( ${yearsDiff} ${yearsDiff === 1 ? "year" : "years"} `,
      monthsDiff > 0 ? `${yearsDiff < 0 ? "(" : ""}  ${monthsDiff} ${monthsDiff === 1 ? "month" : "months )"}` : yearsDiff > 0 && ")"
    ] });
  }
  return /* @__PURE__ */ jsx("div", { children: items.map((item, index) => /* @__PURE__ */ jsxs(
    "div",
    {
      className: "timeline-item relative border-l-2 border-current pb-4 pl-8",
      style: { color: mainColor },
      children: [
        /* @__PURE__ */ jsx("div", { className: "absolute top-1 -left-2.25 h-4 w-4 rounded-full bg-current" }),
        /* @__PURE__ */ jsxs("div", { className: "mb-1 text-black", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-baseline justify-between", children: [
            /* @__PURE__ */ jsx(
              "h3",
              {
                className: "mb-1 text-lg font-bold print:mb-0 print:text-base",
                style: { color: mainColor },
                children: item.title
              }
            ),
            /* @__PURE__ */ jsxs("span", { className: "text-sm print:text-xs", children: [
              item.startDate,
              " - ",
              item.endDate,
              " ",
              calculateDuration(item.startDate, item.endDate)
            ] })
          ] }),
          item.subtitle && /* @__PURE__ */ jsx("div", { className: "text-sm font-bold print:text-xs", children: item.subtitle })
        ] }),
        /* @__PURE__ */ jsx("ul", { className: "mb-2 list-disc pl-4 text-sm text-black", children: item.description.map((desc, index2) => /* @__PURE__ */ jsx("li", { children: desc }, index2)) }),
        item.tags && /* @__PURE__ */ jsxs("div", { className: "mb-1 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx("p", { className: "mb-1 text-xs font-semibold", style: { color: mainColor }, children: "Tech:" }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: item.tags.map((tag, tagIndex) => /* @__PURE__ */ jsx(
            "span",
            {
              style: { color: mainColor },
              className: "rounded-full bg-gray-100 px-2 py-1 text-xs",
              children: tag
            },
            tagIndex
          )) })
        ] }),
        item.clients && item.clients.length > 0 && /* @__PURE__ */ jsxs("div", { className: "mb-2 flex items-center gap-4", children: [
          /* @__PURE__ */ jsx("p", { className: "mb-1 text-xs font-semibold", style: { color: mainColor }, children: "Key Clients:" }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: item.clients.map((client, clientIndex) => /* @__PURE__ */ jsx(
            "span",
            {
              className: "rounded-full px-3 py-1 text-xs font-medium",
              style: { backgroundColor: `${mainColor}20`, color: mainColor },
              children: client
            },
            clientIndex
          )) })
        ] })
      ]
    },
    index
  )) });
};

const Section = ({ title, mainColor, children }) => {
  return /* @__PURE__ */ jsxs("section", { children: [
    /* @__PURE__ */ jsx("h2", { className: "mb-4 text-xl font-bold", style: { color: mainColor }, children: title }),
    children
  ] });
};

const translations = {
  en: {
    sections: {
      about: "About",
      contact: "Contact",
      experience: "Experience",
      education: "Education",
      certificates: "Certificates",
      skills: "Skills",
      languages: "Languages"
    }
  },
  sv: {
    sections: {
      about: "Om mig",
      contact: "Kontakt",
      experience: "Erfarenhet",
      education: "Utbildning",
      certificates: "Certifikat",
      skills: "Kompetenser",
      languages: "Språk"
    }
  }
};

const Main = ({ data, mainColor, language, clients = [] }) => {
  const t = translations[language].sections;
  return /* @__PURE__ */ jsxs("main", { className: "space-y-8 lg:col-span-3", children: [
    /* @__PURE__ */ jsxs(Section, { title: t.experience, mainColor, children: [
      /* @__PURE__ */ jsx(
        Timeline,
        {
          items: data.experience.map((exp) => ({
            title: exp.company,
            subtitle: exp.position,
            startDate: exp.startDate,
            endDate: exp.endDate,
            description: exp.description,
            tags: exp.tags,
            clients: exp.clients
          })),
          mainColor
        }
      ),
      /* @__PURE__ */ jsx("div", { className: "dvidePage" })
    ] }),
    /* @__PURE__ */ jsx(Section, { title: t.education, mainColor, children: /* @__PURE__ */ jsx(
      Timeline,
      {
        items: data.education.map((edu) => ({
          title: edu.institution,
          subtitle: edu.degree,
          startDate: edu.startDate,
          endDate: edu.endDate,
          description: edu.description
        })),
        mainColor
      }
    ) }),
    /* @__PURE__ */ jsx(Section, { title: t.certificates, mainColor, children: /* @__PURE__ */ jsx("ul", { className: "space-y-2", children: data.certificates.map((cert, index) => /* @__PURE__ */ jsxs("li", { className: "flex items-baseline justify-between", children: [
      /* @__PURE__ */ jsx("span", { className: "font-medium", children: cert.name }),
      /* @__PURE__ */ jsx("span", { className: "text-sm text-gray-600", children: cert.year })
    ] }, index)) }) }),
    clients && clients.length > 0 && /* @__PURE__ */ jsx(Section, { title: "Clients", mainColor, children: /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-3", children: clients.map((client, index) => /* @__PURE__ */ jsxs("div", { className: "border-l-4 pl-3", style: { borderColor: mainColor }, children: [
      /* @__PURE__ */ jsx("p", { className: "font-medium", children: client.name }),
      /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-600", children: client.type })
    ] }, index)) }) })
  ] });
};

const Tag = ({ children }) => {
  return /* @__PURE__ */ jsx("span", { className: "rounded-full bg-gray-100 px-3 py-1", children });
};

const Aside = ({ data, mainColor, language }) => {
  const t = translations[language].sections;
  return /* @__PURE__ */ jsxs("aside", { className: "space-y-6 lg:col-span-1", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-2 text-xl font-semibold", style: { color: mainColor }, children: t.about }),
      /* @__PURE__ */ jsx("p", { className: "text-sm", children: data.basics.about })
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("h2", { className: "mb-2 text-xl font-semibold", style: { color: mainColor }, children: t.contact }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-sm print:grid print:grid-cols-2 print:space-y-0 print:gap-x-4 print:gap-y-1", children: [
        /* @__PURE__ */ jsxs("p", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(MapPin, { size: 16, style: { color: mainColor } }),
          data.basics.location
        ] }),
        /* @__PURE__ */ jsxs("p", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx(Mail, { size: 16, style: { color: mainColor } }),
          data.basics.email
        ] }),
        /* @__PURE__ */ jsxs(
          "a",
          {
            href: data.basics.website,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "flex items-center gap-2 hover:underline",
            children: [
              /* @__PURE__ */ jsx(Globe, { size: 16, style: { color: mainColor } }),
              data.basics.website
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          "a",
          {
            href: data.basics.linkedin,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "flex items-center gap-2 hover:underline",
            children: [
              /* @__PURE__ */ jsx(Linkedin, { size: 16, style: { color: mainColor } }),
              data.basics.linkedin
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx(Section, { title: t.skills, mainColor, children: /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: data.skills.map((skill, index) => /* @__PURE__ */ jsx(Tag, { children: skill }, index)) }) }),
    /* @__PURE__ */ jsx(Section, { title: t.languages, mainColor, children: /* @__PURE__ */ jsx("div", { className: "mb-6 flex flex-wrap gap-2", children: data.languages.map((lang, index) => /* @__PURE__ */ jsx(Tag, { children: lang }, index)) }) })
  ] });
};

const ResumeCv = () => {
  const [mainColor, setMainColor] = useState("#4f46e5");
  const [language, setLanguage] = useState("en");
  const resumeData = {
    basics: {
      name: portfolioData.basics.name,
      title: portfolioData.basics.title,
      image: portfolioData.basics.image,
      email: portfolioData.basics.email,
      location: portfolioData.basics.location,
      website: portfolioData.basics.website,
      linkedin: portfolioData.basics.linkedin,
      about: portfolioData.basics.about
    },
    experience: portfolioData.companies.map((c) => ({
      company: c.name,
      position: c.position,
      startDate: c.startDate,
      endDate: c.endDate,
      description: c.detailedDescription,
      tags: c.tags,
      clients: c.clients
    })),
    education: portfolioData.education.map((e) => ({
      institution: e.institution,
      degree: e.degree,
      startDate: e.startDate,
      endDate: e.endDate,
      description: e.detailedDescription
    })),
    certificates: portfolioData.certifications,
    skills: portfolioData.skills,
    languages: portfolioData.languages.map((l) => l.name)
  };
  const clients = portfolioData.clients || [];
  const headerSkills = ["React", "Node.js", "TypeScript"];
  useEffect(() => {
    document.documentElement.style.setProperty("--main-color", mainColor);
  }, [mainColor]);
  const handleExportPDF = () => {
    window.print();
  };
  return /* @__PURE__ */ jsxs("div", { className: "relative mt-16 min-h-screen bg-white print:mt-0", children: [
    /* @__PURE__ */ jsx(
      Toolbar,
      {
        onColorChange: setMainColor,
        onLanguageChange: setLanguage,
        onExportPDF: handleExportPDF,
        currentLanguage: language
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "bg-white pt-16 text-gray-900", children: [
      /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-4xl px-4 flex gap-4", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          "img",
          {
            src: "/img/profile.jpg",
            width: 100,
            height: 100,
            alt: resumeData.basics.name,
            className: "mb-4 rounded-full object-cover"
          }
        ) }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h1", { className: "text-6xl font-bold", style: { color: mainColor }, children: resumeData.basics.name }),
          /* @__PURE__ */ jsx("p", { className: "text-4xl mb-3", children: resumeData.basics.title }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2 mb-4", children: headerSkills.map((skill, index) => /* @__PURE__ */ jsx(
            "span",
            {
              className: "inline-block px-3 py-1 rounded-full text-sm font-medium",
              style: { backgroundColor: `${mainColor}15`, color: mainColor },
              children: skill
            },
            index
          )) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mx-auto flex max-w-4xl gap-8 px-3 py-2 print:block print:gap-0 print:space-y-4", children: [
        /* @__PURE__ */ jsx("div", { className: "w-1/4 shrink-0 print:w-full", children: /* @__PURE__ */ jsx(Aside, { data: resumeData, mainColor, language }) }),
        /* @__PURE__ */ jsx("div", { className: "flex-1 print:w-full", children: /* @__PURE__ */ jsx(Main, { data: resumeData, mainColor, language, clients }) })
      ] })
    ] })
  ] });
};

const $$Cv = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "CV", "description": "My CV" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Resume", ResumeCv, { "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/Resume", "client:component-export": "default" })} ` })}
---`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/cv.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/cv.astro";
const $$url = "/cv";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Cv,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
