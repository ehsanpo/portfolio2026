import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead, a as addAttribute, d as createAstro } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { g as getPortfolioData, $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import React__default from 'react';
import { $ as $$Hero } from '../chunks/Hero_BCs66rIJ.mjs';
import { B as Button } from '../chunks/Button_RRZ3yzHB.mjs';
import { a as getPortfolioItems, g as getBlogPosts } from '../chunks/data_DqvtT1J2.mjs';
import { H as Heading } from '../chunks/Heading_B6EqCbpe.mjs';
import { P as ProjectCard3D } from '../chunks/ProjectCard3D_CSBmQc0h.mjs';
import { $ as $$TechStackBlock, a as $$CertificatesBlock } from '../chunks/TechStackBlock_sszWS4tv.mjs';
import { $ as $$TestimonialsBlock } from '../chunks/TestimonialsBlock_BovmDCH0.mjs';
import { $ as $$Image } from '../chunks/_astro_assets_B2nbh57D.mjs';
import { C as Card3D } from '../chunks/Card3D_BEIy0EXF.mjs';
import { B as BlogCard } from '../chunks/BlogCard_DC-0zNN5.mjs';
import 'clsx';
/* empty css                                 */
export { renderers } from '../renderers.mjs';

const $$HeroBlock = createComponent(async ($$result, $$props, $$slots) => {
  const { contact } = getPortfolioData();
  const portfolioItems = await getPortfolioItems();
  return renderTemplate`${renderComponent($$result, "Hero", $$Hero, { "title": contact.name, "subtitle": contact.role, "subtitleText": contact.description, "fullHeight": true, "text": "Hey! \u270C\uFE0F I'm", "island": true }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "React.Fragment", React__default.Fragment, {}, { "default": async ($$result3) => renderTemplate` ${maybeRenderHead()}<div class="flex flex-wrap gap-4"> ${renderComponent($$result3, "Button", Button, { "href": "/portfolio", "text": "View My Work" })} ${renderComponent($$result3, "Button", Button, { "href": "/contact", "text": "Get in Touch" })} </div> <div> <ul class="align-items-start mt-4 flex flex-wrap"> <li class="hero-info-item"> <div class="align-items-center flex"> <h3 class="text-4xl font-bold"> <span class="gradient-text font-bold">${contact.yearsOfExperience}</span> </h3> <h6 class="border-primary-500 ml-2 border-l pl-2 text-sm leading-tight text-gray-800 dark:text-gray-400">
Years <br>of Experience
</h6> </div> </li> <li class="hero-info-item md:ml-8"> <div class="align-items-center flex"> <h3 class="text-4xl"> <span class="gradient-text font-bold">${portfolioItems.length}</span> </h3> <h6 class="border-primary-500 ml-2 border-l pl-2 text-sm leading-tight text-gray-800 dark:text-gray-400">
Projects <br>Completed
</h6> </div> </li> </ul> </div> ` })} ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/blocks/HeroBlock.astro", void 0);

const $$SelectedWorkBlock = createComponent(async ($$result, $$props, $$slots) => {
  const portfolioItems = await getPortfolioItems();
  const filteredAndSortedItems = portfolioItems.filter((item) => item.onHome).sort((a, b) => {
    if (!a.date || !b.date) return 0;
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });
  return renderTemplate`${maybeRenderHead()}<section id="selected-work" class="bg-opium overflow-hidden py-24 dark:bg-neutral-950"> <div class="container mx-auto px-4"> <div class="mb-16"> ${renderComponent($$result, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "className": "pb-4", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": async ($$result2) => renderTemplate`
Selected Work
` })} </div> <div class="flex flex-wrap justify-center gap-8"> ${filteredAndSortedItems.map((item, index) => renderTemplate`<div class="min-w-[min(100%,320px)] flex-1 lg:min-w-[calc(33.333%-2rem)]"> ${renderComponent($$result, "ProjectCard3D", ProjectCard3D, { "client:load": true, "title": item.title, "description": item.description, "date": item.date, "categories": item.category, "tags": item.tag, "image": item.cover ? { ...item.cover, alt: item.title } : void 0, "icon": item.logo?.src, "glowColor": "rgba(255, 238, 8, 0.2)", "className": "h-full", "href": `/portfolio/${item.permalink}`, "layout": index, "client:component-hydration": "load", "client:component-path": "@/components/ProjectCard3D", "client:component-export": "ProjectCard3D" })} </div>`)} </div> </div> </section>`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/blocks/SelectedWorkBlock.astro", void 0);

const cannen = new Proxy({"src":"/_astro/cannen.D0iN0Tdg.png","width":83,"height":85,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/cannen.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/cannen.png");
							return target[name];
						}
					});

const guldagg = new Proxy({"src":"/_astro/guldagg.RaeSMfx6.png","width":83,"height":85,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/guldagg.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/guldagg.png");
							return target[name];
						}
					});

const svenskadesign = new Proxy({"src":"/_astro/svenskadesign.Bm3Nh8NV.png","width":83,"height":85,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/svenskadesign.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("C:/Users/Ehsan/dev/portfolio2026/src/assets/awards/svenskadesign.png");
							return target[name];
						}
					});

const $$AwardsBlock = createComponent(($$result, $$props, $$slots) => {
  const { awards } = getPortfolioData();
  const imageMap = {
    "/img/awards/cannen.png": cannen,
    "/img/awards/guldagg.png": guldagg,
    "/img/awards/svenskadesign.png": svenskadesign
  };
  const awardsWithImages = awards.map((award) => ({
    ...award,
    image: imageMap[award.images] || award.images
  }));
  return renderTemplate`${maybeRenderHead()}<section class="bg-white py-20 dark:bg-neutral-800/50"> <div class="container mx-auto px-4"> ${renderComponent($$result, "Heading", Heading, { "level": "h3", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading/Heading", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate` Awards ` })} <div class="grid grid-cols-1 gap-8 text-center md:grid-cols-2 lg:grid-cols-3"> ${awardsWithImages.map((award) => renderTemplate`${renderComponent($$result, "Card3D", Card3D, { "className": "text-black", "childClassName": "clip6 bg-opium dark:bg-transparent", "glowColor": "color-mix(in srgb, currentColor 80%, var(--color-primary))", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/Card3D", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate` <a${addAttribute(award.link, "href")} class="rounded-lg p-6 transition-transform hover:-translate-y-1"> <div class=""> ${renderComponent($$result2, "Image", $$Image, { "src": award.image, "alt": award.name, "widths": [480, 768, 1024], "sizes": "(max-width: 768px) 100vw, 33vw", "format": "webp", "quality": 80, "loading": "lazy", "class": "mx-auto mb-4 rounded-lg transition-transform group-hover/card:scale-105" })} <h3 class="text-primary-500 mb-2 text-xl font-semibold transition-all duration-300 group-hover/card:translate-z-20 group-hover/card:scale-110"> ${award.name} </h3> <p class="text-primary-500">${award.description}</p> </div> </a> ` })}`)} </div> </div> </section>`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/blocks/AwardsBlock.astro", void 0);

const $$BlogBlock = createComponent(async ($$result, $$props, $$slots) => {
  const blogPosts = await getBlogPosts();
  const latestPosts = blogPosts.slice(0, 3);
  return renderTemplate`${latestPosts.length > 0 && renderTemplate`${maybeRenderHead()}<section class="bg-gray-50 py-20 dark:bg-neutral-900"><div class="container mx-auto px-4"><div class="mb-16 text-center"><h2 class="mb-4 text-4xl font-bold text-gray-900 dark:text-white">Latest Blog Posts</h2><p class="mx-auto max-w-2xl text-xl text-gray-600 dark:text-gray-400">
Insights, tutorials, and thoughts on web development and technology.
</p></div><div class="mb-12 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">${latestPosts.map((post) => renderTemplate`${renderComponent($$result, "BlogCard", BlogCard, { "post": post, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/blog/BlogCard", "client:component-export": "BlogCard" })}`)}</div><div class="text-center">${renderComponent($$result, "Button", Button, { "href": "/blog", "text": "View All Posts \u2192", "variant": "secondary" })}</div></div></section>`}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/blocks/BlogBlock.astro", void 0);

const $$Astro = createAstro("https://ehsan-pourhadi.com/");
const $$MarqueeContent = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$MarqueeContent;
  const { clients } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="flex items-center gap-12 px-4"> ${clients.map((client) => renderTemplate`<div class="clip2 bg-accent-600 font-basement text-secondary-900 rounded-md p-3 text-lg font-medium whitespace-nowrap"> ${client} </div>`)} </div>`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/components/clients/MarqueeContent.astro", void 0);

const $$ClientMarquee = createComponent(async ($$result, $$props, $$slots) => {
  const portfolioItems = await getPortfolioItems();
  const uniqueClients = [...new Set(portfolioItems.map((item) => item.client))].filter(Boolean);
  return renderTemplate`${maybeRenderHead()}<div class="clip bg-white py-12 dark:bg-neutral-800" data-astro-cid-53bmm462> <div class="container mx-auto mb-8 px-4" data-astro-cid-53bmm462> <h2 class="mb-8 text-center text-2xl font-bold text-gray-900 dark:text-white" data-astro-cid-53bmm462>Trusted By</h2> </div> <div class="relative overflow-hidden" data-astro-cid-53bmm462> <div class="marquee-container" data-astro-cid-53bmm462> ${renderComponent($$result, "MarqueeContent", $$MarqueeContent, { "clients": uniqueClients, "data-astro-cid-53bmm462": true })} </div> </div> </div> `;
}, "C:/Users/Ehsan/dev/portfolio2026/src/components/clients/ClientMarquee.astro", void 0);

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Ehsan Pourhadi - Fullstack Developer Portfolio", "description": "Welcome to the portfolio of Ehsan Pourhadi, a full-stack developer specializing in modern web technologies. Explore my selected works, tech stack, certifications, testimonials, awards, and blog posts." }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "HeroBlock", $$HeroBlock, {})} ${renderComponent($$result2, "SelectedWorkBlock", $$SelectedWorkBlock, {})} ${renderComponent($$result2, "TechStackBlock", $$TechStackBlock, {})} ${renderComponent($$result2, "CertificatesBlock", $$CertificatesBlock, {})} ${renderComponent($$result2, "TestimonialsBlock", $$TestimonialsBlock, {})} ${renderComponent($$result2, "AwardsBlock", $$AwardsBlock, {})} ${renderComponent($$result2, "BlogBlock", $$BlogBlock, {})} ${renderComponent($$result2, "ClientMarquee", $$ClientMarquee, {})} ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/index.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
