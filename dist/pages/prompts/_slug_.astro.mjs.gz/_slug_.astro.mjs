import { d as createAstro, c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { c as cn, $ as $$Layout, a as getCollection } from '../../chunks/Layout_zewWmYqx.mjs';
import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { useState } from 'react';
import { H as Heading } from '../../chunks/Heading_B6EqCbpe.mjs';
import { ParallaxProvider, Parallax } from 'react-scroll-parallax';
import Tilt from 'react-parallax-tilt';
import { Tag, Check, Copy } from 'lucide-react';
import { B as Button } from '../../chunks/Button_RRZ3yzHB.mjs';
export { renderers } from '../../renderers.mjs';

const PromptHeader = ({ prompt }) => {
  const { title, description, category, tags, icon, image } = prompt;
  return /* @__PURE__ */ jsx("div", { className: "bg-gray-100 dark:bg-neutral-800", children: /* @__PURE__ */ jsx("header", { className: "mx-auto max-w-6xl overflow-hidden px-4 py-12", children: /* @__PURE__ */ jsx(ParallaxProvider, { children: /* @__PURE__ */ jsx("div", { className: "relative container", children: /* @__PURE__ */ jsxs("div", { className: "grid md:grid-cols-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "self-center", children: [
      /* @__PURE__ */ jsx(Heading, { className: "mb-4 !text-left", level: "h1", gradient: true, children: title }),
      /* @__PURE__ */ jsx("p", { className: "mb-4 text-xl", children: description }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4", children: [
        category && /* @__PURE__ */ jsxs("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsx("h3", { className: "text-primary-400 min-w-20 font-medium uppercase", children: "Category" }),
          /* @__PURE__ */ jsx("span", { className: "clip2 hover:border-primary border-primary-500/30 bg-primary-500/20 text-primary-400 border-l-2 px-3 py-1 text-sm transition-all", children: category })
        ] }),
        tags && tags.length > 0 && /* @__PURE__ */ jsxs("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsx("h3", { className: "min-w-20 font-medium text-purple-400 uppercase", children: "Tags" }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: tags.map((tag, index) => /* @__PURE__ */ jsxs(
            "span",
            {
              className: "clip2 inline-flex items-center gap-1 border-l-2 border-purple-500/30 bg-purple-500/20 px-3 py-1 text-sm text-purple-400 transition-all hover:border-purple-500",
              children: [
                /* @__PURE__ */ jsx(Tag, { className: "h-3 w-3" }),
                tag
              ]
            },
            index
          )) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "relative mt-10 flex-1 md:mt-0", children: /* @__PURE__ */ jsx(Tilt, { perspective: 1e3, className: "portfolio-hero-image-tilt relative", children: /* @__PURE__ */ jsx("div", { className: "portfolio-hero-image", children: /* @__PURE__ */ jsx(Parallax, { speed: -10, children: image ? /* @__PURE__ */ jsx(
      "img",
      {
        src: image,
        alt: title,
        className: "portfolio-hero-box porfolio-hero-large mr-4 rounded-lg object-cover shadow-2xl"
      }
    ) : /* @__PURE__ */ jsx("div", { className: "portfolio-hero-box porfolio-hero-large from-primary/20 to-primary/5 mr-4 flex items-center justify-center rounded-lg bg-gradient-to-br shadow-2xl", children: /* @__PURE__ */ jsx("span", { className: "text-9xl", children: icon || "📝" }) }) }) }) }) })
  ] }) }) }) }) });
};

function PromptDetail({ children, className }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    const contentElement = document.querySelector(".prompt-content");
    if (contentElement) {
      try {
        await navigator.clipboard.writeText(contentElement.textContent || "");
        setCopied(true);
        setTimeout(() => setCopied(false), 2e3);
      } catch (err) {
        console.error("Failed to copy:", err);
      }
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: cn("", className), children: [
    /* @__PURE__ */ jsx("div", { className: "mb-6 rounded-lg border border-blue-200 bg-blue-50 p-6 dark:border-blue-800 dark:bg-blue-900/20", children: /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-2", children: [
      /* @__PURE__ */ jsx(
        "svg",
        {
          className: "mt-0.5 mr-3 h-6 w-6 text-blue-600 dark:text-blue-400",
          fill: "currentColor",
          viewBox: "0 0 20 20",
          children: /* @__PURE__ */ jsx(
            "path",
            {
              fillRule: "evenodd",
              d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
              clipRule: "evenodd"
            }
          )
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsx("h3", { className: "mb-2 text-base font-semibold text-blue-800 dark:text-blue-300", children: "How to use this prompt" }),
        /* @__PURE__ */ jsx("p", { className: "text-sm text-blue-700 dark:text-blue-400", children: "Copy the prompt above and paste it into your favorite AI assistant (ChatGPT, Claude, Gemini, etc.). You can customize it based on your specific needs." })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsx(Button, { onClick: handleCopy, variant: "secondary", children: /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: copied ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }),
        "Copied!"
      ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(Copy, { className: "h-4 w-4" }),
        "Copy Prompt"
      ] }) }) }) })
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "relative mb-8", children: /* @__PURE__ */ jsx("div", { className: "prompt-content prose prose-lg dark:prose-invert max-w-none rounded-xl border border-gray-200 bg-white p-8 dark:border-gray-800 dark:bg-gray-900", children }) })
  ] });
}

const $$Astro = createAstro("https://ehsan-pourhadi.com/");
async function getStaticPaths() {
  const prompts = await getCollection("prompt");
  return prompts.map((prompt) => ({
    params: { slug: prompt.slug },
    props: { prompt }
  }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { prompt } = Astro2.props;
  const { Content } = await prompt.render();
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `${prompt.data.title} - AI Prompts`, "description": prompt.data.description, "image": "/img/ogdefault.jpg", "imageAlt": prompt.data.title }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<article class="relative min-h-screen bg-white dark:bg-neutral-900"> ${renderComponent($$result2, "PromptHeader", PromptHeader, { "prompt": {
    title: prompt.data.title,
    description: prompt.data.description,
    category: prompt.data.category,
    tags: prompt.data.tags,
    icon: prompt.data.icon,
    image: prompt.data.image?.src
  }, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/prompts/PromptHeader", "client:component-export": "default" })} <div class="relative z-10 mx-auto max-w-6xl px-4 pt-10"> ${renderComponent($$result2, "PromptDetail", PromptDetail, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/prompts/PromptDetail", "client:component-export": "PromptDetail" }, { "default": async ($$result3) => renderTemplate` ${renderComponent($$result3, "Content", Content, {})} ` })} </div> </article> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/prompts/[slug].astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/prompts/[slug].astro";
const $$url = "/prompts/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$slug,
	file: $$file,
	getStaticPaths,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
