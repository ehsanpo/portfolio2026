import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout, g as getPortfolioData, b as getRoles } from '../../chunks/Layout_zewWmYqx.mjs';
import { $ as $$Hero } from '../../chunks/Hero_BCs66rIJ.mjs';
import { S as StackCard } from '../../chunks/StackCard_B-PtFpFe.mjs';
import { S as SkillChart } from '../../chunks/SkillChart_D9cUMBlT.mjs';
import { $ as $$ToolsList, P as ProcessFlowDiagram } from '../../chunks/Beams_BM7nfGp2.mjs';
import { H as Heading } from '../../chunks/Heading_B6EqCbpe.mjs';
import { B as BoxReveal } from '../../chunks/box-reveal_B6uqfd-J.mjs';
import { g as getRoleImage } from '../../chunks/roleImageMap_BgqfBJeZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$DevopsCloudEngineer = createComponent(($$result, $$props, $$slots) => {
  const { stacks } = getPortfolioData();
  const roles = getRoles();
  const currentRole = roles.find((role) => role.slug === "devops-cloud-engineer");
  const mappedImage = currentRole?.image ? getRoleImage(currentRole.image) : void 0;
  const displayImage = mappedImage && {
    src: mappedImage.src,
    alt: currentRole?.title,
    width: mappedImage.width,
    height: mappedImage.height
  };
  const devopsStacks = stacks.filter(
    (stack) => ["DevOps", "CI/CD", "Cloud", "Backend"].includes(stack.slug)
  );
  const devopsChart = {
    slug: "DevOps & Cloud",
    labels: [
      "CI/CD Pipelines",
      "Infrastructure as Code",
      "Cloud Architecture",
      "Container Orchestration",
      "Monitoring & Logging",
      "Security & Compliance"
    ],
    data: ["9", "8", "8", "9", "8", "7"]
  };
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "DevOps Cloud Engineer - Ehsan Pourhadi" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Hero", $$Hero, { "fullHeight": true, "title": "DevOps Cloud Engineer", "img": displayImage.src }, { "default": ($$result3) => renderTemplate` ${maybeRenderHead()}<div> ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-secondary-400", "duration": 0.1, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="mb-5 text-2xl dark:text-gray-300"> ${currentRole?.description} </p> ` })} ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="text-xl dark:text-gray-300">
I design and maintain robust cloud infrastructure, automate deployment processes, and
					ensure system reliability at scale. From CI/CD pipelines to monitoring and security, I
					enable development teams to ship faster and safer.
</p> ` })} </div> ` })} <section class="container mx-auto px-4 py-12"> <div class="mx-auto max-w-4xl"> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`What I Bring` })} <p class="text-lg text-gray-700 dark:text-gray-300">
I build the infrastructure that enables teams to ship faster and more reliably. With
					expertise in CI/CD pipelines, containerization, and cloud platforms, I create automated
					workflows that reduce manual intervention and increase deployment confidence. I understand
					both the development and operations perspectives.
</p> </div> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Evidence` })} <div class="space-y-6"> <div class="rounded-lg bg-white p-6 shadow-lg dark:bg-neutral-800"> <h3 class="text-primary-600 dark:text-primary-400 mb-2 text-xl font-semibold">
AWS Certification & Cloud Experience
</h3> <blockquote class="border-primary-500 border-l-4 pl-4 text-gray-700 italic dark:text-gray-300">
"Earned the AWS Certified Solutions Architect certification through rigorous training
							from Linux Academy, demonstrating expertise in architecting scalable and reliable
							cloud solutions."
</blockquote> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Source: Portfolio Education - Linux Academy (2018)
</p> </div> <div class="rounded-lg bg-white p-6 shadow-lg dark:bg-neutral-800"> <h3 class="text-primary-600 dark:text-primary-400 mb-2 text-xl font-semibold">
Testimonial from Fredrik Madsen (Software Developer)
</h3> <blockquote class="border-primary-500 border-l-4 pl-4 text-gray-700 italic dark:text-gray-300">
"Ehsan was always first to jump on problems when our complicated build system acted
							up. When Ehsan was around, we could always be confident that our issues would get
							solved."
</blockquote> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Source: Testimonials - Fredrik Madsen
</p> </div> </div> </div> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Impact & Outcomes` })} <div class="grid gap-6 md:grid-cols-2"> <div class="from-primary-500/10 to-primary-600/10 rounded-lg bg-gradient-to-br p-6"> <div class="text-primary-600 dark:text-primary-400 mb-2 text-3xl font-bold">
Automated
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
CI/CD Pipelines
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Expertise with GitHub Actions, Jenkins, CircleCI, and GitLab CI
</p> </div> <div class="from-secondary-400/10 to-secondary-600/10 rounded-lg bg-gradient-to-br p-6"> <div class="text-secondary-600 dark:text-secondary-400 mb-2 text-3xl font-bold">
AWS Certified
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Solutions Architect
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Designed and implemented scalable cloud infrastructure on AWS
</p> </div> <div class="rounded-lg bg-gradient-to-br from-blue-500/10 to-blue-600/10 p-6"> <div class="mb-2 text-3xl font-bold text-blue-600 dark:text-blue-400">
Container Expert
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Docker & Orchestration
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Containerized applications and managed deployment workflows
</p> </div> <div class="rounded-lg bg-gradient-to-br from-green-500/10 to-green-600/10 p-6"> <div class="mb-2 text-3xl font-bold text-green-600 dark:text-green-400">
Infrastructure
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Linux & Scripting
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Advanced Linux administration and shell scripting for automation
</p> </div> </div> </div> </div> </section> <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`DevOps & Cloud Stacks` })} <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-2"> ${devopsStacks.map((stack) => renderTemplate`${renderComponent($$result2, "StackCard", StackCard, { ...stack, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/StackCard", "client:component-export": "default" })}`)} </div> </div> </section> <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`DevOps & Cloud Skills` })} ${renderComponent($$result2, "SkillChart", SkillChart, { "data": [devopsChart], "chartData": devopsChart, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/SkillChart", "client:component-export": "default" })} </div> </section> ${renderComponent($$result2, "ToolsList", $$ToolsList, {})} <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`DevOps Workflow` })} ${renderComponent($$result2, "ProcessFlowDiagram", ProcessFlowDiagram, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/Beams", "client:component-export": "ProcessFlowDiagram" })} </div> </section> <section class="container mx-auto px-4 py-16"> <div class="gradient-bg rounded-lg py-12 text-center"> <h3 class="mb-6 text-4xl text-gray-600 dark:text-gray-100">
Ready to optimize your deployment pipeline?
</h3> <a href="/contact" class="bg-primary-600 hover:bg-primary-700 inline-flex items-center rounded-lg px-6 py-3 text-white transition-colors">
Get in Touch
<svg class="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path> </svg> </a> </div> </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/devops-cloud-engineer.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/devops-cloud-engineer.astro";
const $$url = "/roles/devops-cloud-engineer";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$DevopsCloudEngineer,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
