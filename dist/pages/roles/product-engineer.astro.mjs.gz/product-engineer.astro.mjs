import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout, g as getPortfolioData, b as getRoles } from '../../chunks/Layout_zewWmYqx.mjs';
import { $ as $$Hero } from '../../chunks/Hero_BCs66rIJ.mjs';
import { S as StackCard } from '../../chunks/StackCard_B-PtFpFe.mjs';
import { S as SkillChart } from '../../chunks/SkillChart_D9cUMBlT.mjs';
import { $ as $$ToolsList, P as ProcessFlowDiagram } from '../../chunks/Beams_BM7nfGp2.mjs';
import { H as Heading } from '../../chunks/Heading_B6EqCbpe.mjs';
import { B as BoxReveal } from '../../chunks/box-reveal_B6uqfd-J.mjs';
import { g as getRoleImage } from '../../chunks/roleImageMap_BgqfBJeZ.mjs';
export { renderers } from '../../renderers.mjs';

const $$ProductEngineer = createComponent(($$result, $$props, $$slots) => {
  const { stacks } = getPortfolioData();
  const roles = getRoles();
  const currentRole = roles.find((role) => role.slug === "product-engineer");
  const mappedImage = currentRole?.image ? getRoleImage(currentRole.image) : void 0;
  const displayImage = mappedImage && {
    src: mappedImage.src,
    alt: currentRole?.title,
    width: mappedImage.width,
    height: mappedImage.height
  };
  const productStacks = stacks.filter(
    (stack) => ["Front-end", "Backend", "Design", "Database"].includes(stack.slug)
  );
  const productChart = {
    slug: "Product Engineering",
    labels: [
      "Product Thinking",
      "User Research",
      "Technical Execution",
      "Iteration Speed",
      "Business Impact",
      "End-to-End Ownership"
    ],
    data: ["9", "8", "10", "9", "9", "10"]
  };
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Product Engineer - Ehsan Pourhadi" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Hero", $$Hero, { "fullHeight": true, "title": "Product Engineer", "img": displayImage.src }, { "default": ($$result3) => renderTemplate` ${maybeRenderHead()}<div> ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-secondary-400", "duration": 0.1, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="mb-5 text-2xl dark:text-gray-300"> ${currentRole?.description} </p> ` })} ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="text-xl dark:text-gray-300">
I bridge the gap between technical possibilities and user needs, ensuring that every line
					of code serves a purpose and every feature solves real problems. I think in products, not
					just features.
</p> ` })} </div> ` })} <section class="container mx-auto px-4 py-12"> <div class="mx-auto max-w-4xl"> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`What I Bring` })} <p class="text-lg text-gray-700 dark:text-gray-300">
I don't just write code,I solve user problems. With a deep understanding of both technical
					implementation and product strategy, I bridge the gap between what users need and what
					engineering can deliver. I own features end-to-end, from ideation through deployment and
					iteration.
</p> </div> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Evidence` })} <div class="space-y-6"> <div class="rounded-lg bg-white p-6 shadow-lg dark:bg-neutral-800"> <h3 class="text-primary-600 dark:text-primary-400 mb-2 text-xl font-semibold">
From Experience at Bredband2
</h3> <blockquote class="border-primary-500 border-l-4 pl-4 text-gray-700 italic dark:text-gray-300">
"Spearheaded the complete redesign and development of the customer service portal,
							serving over 100,000 active users. Implemented real-time service monitoring and
							automated troubleshooting. Worked closely with UX to optimize UI/UX for improved user
							engagement."
</blockquote> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Source: Portfolio Experience - Bredband2 (2020-2023)
</p> </div> <div class="rounded-lg bg-white p-6 shadow-lg dark:bg-neutral-800"> <h3 class="text-primary-600 dark:text-primary-400 mb-2 text-xl font-semibold">
Testimonial from Rebecca Löfgren (Senior UX Designer)
</h3> <blockquote class="border-primary-500 border-l-4 pl-4 text-gray-700 italic dark:text-gray-300">
"Ehsan possesses the ability to see the whole picture, which enables him to produce
							quality products , even if the brief is a bit fuzzy. He has a keen eye for design,
							which has made my job as a designer so much easier."
</blockquote> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Source: Testimonials - Rebecca Löfgren
</p> </div> </div> </div> <div class="mb-16"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Impact & Outcomes` })} <div class="grid gap-6 md:grid-cols-2"> <div class="from-primary-500/10 to-primary-600/10 rounded-lg bg-gradient-to-br p-6"> <div class="text-primary-600 dark:text-primary-400 mb-2 text-3xl font-bold">
100,000+
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">Users Impacted</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Redesigned customer portal serving six-figure user base with improved engagement
</p> </div> <div class="from-secondary-400/10 to-secondary-600/10 rounded-lg bg-gradient-to-br p-6"> <div class="text-secondary-600 dark:text-secondary-400 mb-2 text-3xl font-bold">
End-to-End
</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Product Ownership
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
From user research to deployment, owning complete product features
</p> </div> <div class="rounded-lg bg-gradient-to-br from-blue-500/10 to-blue-600/10 p-6"> <div class="mb-2 text-3xl font-bold text-blue-600 dark:text-blue-400">UX-Driven</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Design Collaboration
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Working closely with designers to optimize user experience and engagement
</p> </div> <div class="rounded-lg bg-gradient-to-br from-green-500/10 to-green-600/10 p-6"> <div class="mb-2 text-3xl font-bold text-green-600 dark:text-green-400">Real-Time</div> <div class="text-lg font-semibold text-gray-800 dark:text-gray-200">
Monitoring Solutions
</div> <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
Implemented automated troubleshooting and real-time service monitoring
</p> </div> </div> </div> </div> </section> <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Technical Stacks` })} <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-2"> ${productStacks.map((stack) => renderTemplate`${renderComponent($$result2, "StackCard", StackCard, { ...stack, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/StackCard", "client:component-export": "default" })}`)} </div> </div> </section> <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Product Engineering Skills` })} ${renderComponent($$result2, "SkillChart", SkillChart, { "data": [productChart], "chartData": productChart, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/SkillChart", "client:component-export": "default" })} </div> </section> ${renderComponent($$result2, "ToolsList", $$ToolsList, {})} <section class="py-12"> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Development Process` })} ${renderComponent($$result2, "ProcessFlowDiagram", ProcessFlowDiagram, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/Beams", "client:component-export": "ProcessFlowDiagram" })} </div> </section> <section class="container mx-auto px-4 py-16"> <div class="gradient-bg rounded-lg py-12 text-center"> <h3 class="mb-6 text-4xl text-gray-600 dark:text-gray-100">
Ready to build products users love?
</h3> <a href="/contact" class="bg-primary-600 hover:bg-primary-700 inline-flex items-center rounded-lg px-6 py-3 text-white transition-colors">
Get in Touch
<svg class="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path> </svg> </a> </div> </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/product-engineer.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/product-engineer.astro";
const $$url = "/roles/product-engineer";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$ProductEngineer,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
