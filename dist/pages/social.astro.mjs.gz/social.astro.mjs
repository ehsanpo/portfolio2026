import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
import { g as getSocialPosts, S as SocialGridFeed } from '../chunks/social_DVnQxcf3.mjs';
export { renderers } from '../renderers.mjs';

const $$Social = createComponent(async ($$result, $$props, $$slots) => {
  const socialPosts = await getSocialPosts();
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Social", "description": "Design drops, short videos, and useful links in one TikTok-style feed." }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Social", "subtitle": "Images, videos, links, and quick drops from my creative workflow." })} ${maybeRenderHead()}<section class="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"> ${renderComponent($$result2, "SocialGridFeed", SocialGridFeed, { "posts": socialPosts, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/social/SocialGridFeed", "client:component-export": "default" })} </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/social.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/social.astro";
const $$url = "/social";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Social,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
