import { d as createAstro, c as createComponent, r as renderComponent, b as renderTemplate } from '../../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { a as getCollection, p as portfolioData, $ as $$Layout } from '../../chunks/Layout_zewWmYqx.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import { motion } from 'framer-motion';
import { P as ProjectCard3D } from '../../chunks/ProjectCard3D_CSBmQc0h.mjs';
import Avatar from 'boring-avatars';
import { g as getTestimonialImage } from '../../chunks/testimonialImages_CyYEBPFx.mjs';
import { g as getProjectImage } from '../../chunks/projectHelpers_Q9_CjjLW.mjs';
export { renderers } from '../../renderers.mjs';

const TeamAvatar = ({ name, size = 40, className = "" }) => {
  return /* @__PURE__ */ jsx("div", { className, children: /* @__PURE__ */ jsx(
    Avatar,
    {
      size,
      name,
      variant: "beam",
      colors: ["#2563eb", "#3b82f6", "#60a5fa", "#93c5fd", "#dbeafe"]
    }
  ) });
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};
const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  }
};
const heroVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.8,
      ease: [0.22, 1, 0.36, 1],
      staggerChildren: 0.1
    }
  }
};
const WorkDetailView = ({
  company,
  relatedProjects,
  skillDurations
}) => {
  const getSkillDuration = (skill) => {
    const s = skill.toLowerCase();
    return skillDurations[s] || skillDurations[s + "js"] || skillDurations[s + " js"] || "";
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-7xl px-4 pt-32 pb-32 sm:px-6 lg:px-8", children: [
    /* @__PURE__ */ jsxs(
      motion.section,
      {
        initial: "hidden",
        animate: "visible",
        variants: heroVariants,
        className: "relative overflow-hidden pb-20",
        children: [
          /* @__PURE__ */ jsx("div", { className: "absolute inset-0 -z-10", children: /* @__PURE__ */ jsx("div", { className: "from-accent-500/10 absolute top-0 left-1/2 h-full w-full -translate-x-1/2 bg-linear-to-b to-transparent opacity-20 blur-3xl" }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center gap-12 lg:flex-row", children: [
            /* @__PURE__ */ jsx(
              motion.div,
              {
                variants: itemVariants,
                className: "group hover:border-accent-500/50 flex h-32 w-32 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-4 shadow-2xl backdrop-blur-sm transition-colors duration-500 md:h-48 md:w-48",
                children: company.image ? /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: company.image,
                    alt: company.name,
                    className: "h-full w-full object-contain transition-transform duration-500 group-hover:scale-110"
                  }
                ) : /* @__PURE__ */ jsx("div", { className: "text-4xl font-bold text-black uppercase dark:text-white", children: company.name.charAt(0) })
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex-1 text-center lg:text-left", children: [
              /* @__PURE__ */ jsxs(
                motion.div,
                {
                  variants: itemVariants,
                  className: "bg-accent-500/10 border-accent-500/20 text-accent-400 mb-5 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-sm font-medium",
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "bg-accent-500 h-2 w-2 animate-pulse rounded-full" }),
                    company.year
                  ]
                }
              ),
              /* @__PURE__ */ jsx(
                motion.h1,
                {
                  variants: itemVariants,
                  className: "text-primary-500 mb-1 text-4xl font-bold tracking-tight md:text-6xl",
                  children: company.name
                }
              ),
              /* @__PURE__ */ jsx(
                motion.p,
                {
                  variants: itemVariants,
                  className: "text-accent-400/90 mb-1 text-xl font-medium tracking-wider uppercase md:text-2xl",
                  children: company.position
                }
              ),
              /* @__PURE__ */ jsx(
                motion.p,
                {
                  variants: itemVariants,
                  className: "mx-auto max-w-2xl text-lg leading-relaxed text-slate-400 lg:mx-0",
                  children: company.description
                }
              )
            ] })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-12 lg:grid-cols-12", children: [
      /* @__PURE__ */ jsxs("div", { className: "space-y-12 lg:col-span-8", children: [
        company.tags && company.tags.length > 0 && /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "border-accent-500 mb-6 border-l-4 pl-4 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Focus Areas" }),
              /* @__PURE__ */ jsx("div", { className: "flex flex-wrap gap-2", children: company.softSkills.map((skill, idx) => /* @__PURE__ */ jsx(
                motion.span,
                {
                  variants: itemVariants,
                  className: "bg-accent-500/10 border-accent-500/20 text-accent-400 hover:bg-accent-500/20 rounded-xl border px-4 py-2 text-sm font-medium transition-colors",
                  children: skill
                },
                idx
              )) })
            ]
          }
        ),
        /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "border-accent-500 mb-8 border-l-4 pl-4 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Overview" }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-4", children: company.detailedDescription.map((item, idx) => /* @__PURE__ */ jsx(
                motion.div,
                {
                  variants: itemVariants,
                  className: "hover:border-accent-500/30 group rounded-2xl border border-white/10 bg-white/5 p-6 transition-all duration-300",
                  children: /* @__PURE__ */ jsx("p", { className: "leading-6 text-slate-700 transition-colors dark:text-slate-300 dark:group-hover:text-white", children: item })
                },
                idx
              )) })
            ]
          }
        ),
        company.awards && company.awards.length > 0 && /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "border-accent-500 mb-8 border-l-4 pl-4 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Awards & Recognition" }),
              /* @__PURE__ */ jsx("div", { className: "space-y-4", children: company.awards.map((award, idx) => /* @__PURE__ */ jsxs(
                motion.div,
                {
                  variants: itemVariants,
                  className: "flex items-center gap-6 rounded-2xl border border-yellow-500/20 bg-linear-to-r from-yellow-500/10 to-transparent p-6",
                  children: [
                    award.images && /* @__PURE__ */ jsx(
                      "img",
                      {
                        src: award.images,
                        alt: award.name,
                        className: "h-16 w-16 object-contain drop-shadow-lg filter"
                      }
                    ),
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("h3", { className: "text-xl font-bold text-black dark:text-white", children: award.name }),
                      /* @__PURE__ */ jsx("p", { className: "text-yellow-500/80", children: award.description })
                    ] })
                  ]
                },
                idx
              )) })
            ]
          }
        ),
        relatedProjects.length > 0 && /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "border-accent-500 mb-8 border-l-4 pl-4 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Projects & Case Studies" }),
              /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 gap-8 md:grid-cols-2", children: relatedProjects.map((project, index) => /* @__PURE__ */ jsx(motion.div, { variants: itemVariants, children: /* @__PURE__ */ jsx(
                ProjectCard3D,
                {
                  title: project.data.title,
                  description: project.data.tagline,
                  date: project.data.date,
                  tags: project.data.tag,
                  image: getProjectImage(project.data),
                  categories: project.data.category,
                  layout: index,
                  href: `/portfolio/${project.data.permalink}`,
                  glowColor: "color-mix(in srgb, black 80%, var(--color-accent))"
                }
              ) }, project.id)) })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "space-y-12 lg:col-span-4", children: [
        /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "border-accent-500 mb-6 border-l-4 pl-4 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Technical Expertise" }),
              /* @__PURE__ */ jsx("div", { className: "space-y-3", children: company.codeSkills.map((skill, idx) => /* @__PURE__ */ jsxs(
                motion.div,
                {
                  variants: itemVariants,
                  className: "group flex items-center justify-between rounded-xl border border-black/10 bg-white/5 p-4 transition-colors hover:bg-white/10 dark:border-white/10",
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "group-hover:text-accent-400 font-medium transition-colors dark:text-slate-300", children: skill }),
                    /* @__PURE__ */ jsx("span", { className: "font-mono text-xs text-slate-500", children: getSkillDuration(skill) })
                  ]
                },
                idx
              )) })
            ]
          }
        ),
        company.team && company.team.length > 0 && /* @__PURE__ */ jsxs(
          motion.section,
          {
            initial: "hidden",
            whileInView: "visible",
            viewport: { once: true, margin: "-100px" },
            variants: containerVariants,
            children: [
              /* @__PURE__ */ jsx("h2", { className: "mb-6 text-sm font-bold tracking-widest text-black uppercase dark:text-white", children: "Team Members" }),
              /* @__PURE__ */ jsx("div", { className: "space-y-4", children: company.team.map((member, idx) => /* @__PURE__ */ jsxs(
                motion.div,
                {
                  variants: itemVariants,
                  className: "group flex items-center gap-4",
                  children: [
                    /* @__PURE__ */ jsx("div", { className: "group-hover:border-accent-500 flex h-12 w-12 items-center justify-center overflow-hidden rounded-full border-2 border-slate-700 bg-slate-800 transition-colors", children: member.img ? /* @__PURE__ */ jsx(
                      "img",
                      {
                        src: getTestimonialImage(member.img),
                        alt: member.name,
                        className: "h-full w-full object-cover"
                      }
                    ) : /* @__PURE__ */ jsx(TeamAvatar, { name: member.name, size: 48 }) }),
                    /* @__PURE__ */ jsxs("div", { children: [
                      /* @__PURE__ */ jsx("div", { className: "group-hover:text-accent-400 text-sm font-medium text-black transition-colors dark:text-white", children: member.name }),
                      /* @__PURE__ */ jsx("div", { className: "text-xs text-slate-500", children: member.role })
                    ] })
                  ]
                },
                idx
              )) })
            ]
          }
        )
      ] })
    ] })
  ] });
};

const $$Astro = createAstro("https://ehsan-pourhadi.com/");
async function getStaticPaths() {
  const companies = portfolioData.companies;
  return companies.map((company) => ({
    params: { slug: company.id },
    props: { company }
  }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { company } = Astro2.props;
  const portfolioEntries = await getCollection("portfolio");
  const relatedProjects = portfolioEntries.filter((entry) => {
    console.log("Checking entry:", entry.data.agency, "for company:", company.name, company.id);
    return entry.data.agency === company.name || entry.data.client === company.name || entry.data.agency && company.name.includes(entry.data.agency) || entry.id && entry.id.startsWith(company.id);
  });
  const skillDurations = portfolioData.timeline.reduce(
    (acc, item) => {
      const name = item.name.toLowerCase();
      acc[name] = item.duration;
      if (name === "reactjs") acc["react"] = item.duration;
      if (name === "electron js") acc["electron"] = item.duration;
      if (name === "vuejs") acc["vue"] = item.duration;
      if (name === "javascript") acc["js"] = item.duration;
      return acc;
    },
    {}
  );
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `${company.name} | ${company.position}`, "description": company.description }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "WorkDetailView", WorkDetailView, { "client:load": true, "company": company, "relatedProjects": relatedProjects, "skillDurations": skillDurations, "client:component-hydration": "load", "client:component-path": "@/components/work/WorkDetailView", "client:component-export": "WorkDetailView" })} ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/work/[slug].astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/work/[slug].astro";
const $$url = "/work/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$slug,
	file: $$file,
	getStaticPaths,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
