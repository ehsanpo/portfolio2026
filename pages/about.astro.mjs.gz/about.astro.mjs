import { c as createComponent, m as maybeRenderHead, r as renderComponent, a as addAttribute, b as renderTemplate } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { g as getPortfolioData, $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$Hero } from '../chunks/Hero_BCs66rIJ.mjs';
import { B as BoxReveal } from '../chunks/box-reveal_B6uqfd-J.mjs';
import { B as Button } from '../chunks/Button_RRZ3yzHB.mjs';
import { E as ExternalLink } from '../chunks/ExternalLink_DnPubapW.mjs';
import { $ as $$TestimonialsBlock } from '../chunks/TestimonialsBlock_BovmDCH0.mjs';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import { Briefcase, GraduationCap, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';
import { C as Card3D } from '../chunks/Card3D_BEIy0EXF.mjs';
export { renderers } from '../renderers.mjs';

const TimelineCard = ({ title, subTitle, date, type, delay = 0 }) => {
  const Icon = type === "work" ? Briefcase : GraduationCap;
  const iconSettings = type === "work" ? { bg: "rgba(231, 74, 131, 0.1)", color: "#e74a83", glow: "rgba(231, 74, 131, 0.3)" } : { bg: "rgba(59, 130, 246, 0.1)", color: "#3b82f6", glow: "rgba(59, 130, 246, 0.3)" };
  return /* @__PURE__ */ jsx(
    motion.div,
    {
      initial: { opacity: 0, y: 20 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: true },
      transition: { duration: 0.5, delay },
      className: "w-full",
      children: /* @__PURE__ */ jsx(
        Card3D,
        {
          intensity: 10,
          glowColor: iconSettings.glow,
          shine: true,
          className: "w-full",
          childClassName: "bg-white/90 dark:bg-neutral-900/80 border-neutral-200/50 dark:border-neutral-800/50 shadow-xl",
          children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col gap-4 p-4 sm:flex-row sm:items-center md:gap-6 md:p-6", children: [
            /* @__PURE__ */ jsx(
              "div",
              {
                className: "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg shadow-sm transition-transform duration-300 group-hover:scale-110 md:h-14 md:w-14",
                style: { backgroundColor: iconSettings.bg },
                children: /* @__PURE__ */ jsx(Icon, { size: 24, style: { color: iconSettings.color }, strokeWidth: 2.5 })
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col justify-between gap-2 sm:flex-row sm:items-center", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-0.5", children: [
                /* @__PURE__ */ jsx("h3", { className: "font-basement text-lg font-bold tracking-tight text-neutral-900 md:text-xl dark:text-neutral-100", children: title }),
                /* @__PURE__ */ jsx("p", { className: "font-medium text-neutral-600 dark:text-neutral-400", children: subTitle })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "flex flex-col sm:text-right", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 sm:justify-end", children: [
                /* @__PURE__ */ jsx(Calendar, { size: 14, className: "text-neutral-400" }),
                /* @__PURE__ */ jsx("span", { className: "text-sm font-bold text-neutral-800 dark:text-neutral-200", children: date })
              ] }) })
            ] })
          ] })
        }
      )
    }
  );
};

const $$ExperienceBlock = createComponent(($$result, $$props, $$slots) => {
  const { companies, education } = getPortfolioData();
  const workItems = companies.map((c) => ({
    id: c.id,
    title: c.position,
    subTitle: c.name,
    date: c.year,
    startDate: c.startDate,
    endDate: c.endDate,
    type: "work"
  })).sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  const educationItems = education.map((e) => ({
    title: e.degree || e.title,
    subTitle: e.institution,
    date: e.year,
    startDate: e.startDate,
    endDate: e.endDate,
    type: "education"
  })).sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  return renderTemplate`${maybeRenderHead()}<section class="py-10 md:py-20"> <div class="container mx-auto"> <div class="grid gap-12 lg:grid-cols-2"> <div class="flex flex-col gap-8"> ${renderComponent($$result, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate` <h2 class="font-basement text-3xl md:text-4xl">Experience</h2> ` })} <div class="flex flex-col gap-4"> ${workItems.map((item, index) => renderTemplate`<a${addAttribute(`/work/${item.id}`, "href")} style="text-decoration: none;"> ${renderComponent($$result, "TimelineCard", TimelineCard, { ...item, "delay": index * 0.1, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/TimelineCard", "client:component-export": "default" })} </a>`)} </div> </div> <div class="flex flex-col gap-8"> ${renderComponent($$result, "BoxReveal", BoxReveal, { "boxColor": "bg-secondary-400", "duration": 0.5, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate` <h2 class="font-basement text-3xl md:text-4xl">Education</h2> ` })} <div class="flex flex-col gap-4"> ${educationItems.map((item, index) => renderTemplate`${renderComponent($$result, "TimelineCard", TimelineCard, { ...item, "delay": index * 0.1, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/TimelineCard", "client:component-export": "default" })}`)} </div> </div> </div> </div> </section>`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/blocks/ExperienceBlock.astro", void 0);

const $$About = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "About" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Hero", $$Hero, { "fullHeight": true, "title": "About Me", "img": "/img/200925148-0.jpg" }, { "default": ($$result3) => renderTemplate` ${maybeRenderHead()}<div> ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-secondary-400", "duration": 0.1, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="mb-5 text-2xl dark:text-gray-300">
I'm a passionate full-stack developer with a keen eye for design and a drive for creating
					exceptional digital experiences.
</p> ` })} ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "delay": 0.2, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <p class="text-xl dark:text-gray-300">
With years of experience in web development and design, I combine technical expertise with
					creative problem-solving to deliver innovative solutions.
</p> ` })} ${renderComponent($$result3, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.6, "delay": 0.3, "client:load": true, "className": "p-1", "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result4) => renderTemplate` <div class="flex"> ${renderComponent($$result4, "Button", Button, { "href": "/cv", "className": "mt-3", "text": "Resume", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/Button", "client:component-export": "default" })} ${renderComponent($$result4, "ExternalLink", ExternalLink, { "href": "https://www.linkedin.com/in/ehsanp/", "className": "mt-3 ml-4", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ui/ExternalLink", "client:component-export": "ExternalLink" }, { "default": ($$result5) => renderTemplate`
Reach me on LinkedIn.
` })} </div> ` })} </div> ` })} ${renderComponent($$result2, "ExperienceBlock", $$ExperienceBlock, {})} ${renderComponent($$result2, "Testimonials", $$TestimonialsBlock, { "showAll": true })} <section class="py-10 md:py-20"> <div class="container mx-auto flex flex-col items-center md:flex-row"> <h2 class="font-basement mb-6 text-2xl md:mb-0 md:w-1/2 md:text-3xl lg:text-6xl"> ${renderComponent($$result2, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate` Background ` })} </h2> <div class="md:w-1/2">
My journey as a self-taught professional has equipped me with a profound understanding of
				software development, design, and multimedia. With a relentless drive for excellence, I have
				honed my expertise in delivering robust software architectures, seamless user experiences,
				and visually captivating designs. With a diverse skill set, I excel in various web
				development stacks, anchored by a robust command of WordPress and Laravel for backend
				excellence.
<br> <br>
My proficiency extends seamlessly to front-end mastery with Javascript and HTML/CSS. Beyond web
				development, I possess a profound comprehension of user interface design, intricacies of logo
				and identity creation, and the intricacies of search engine optimization.
<br> <br>
My extensive expertise also spans multimedia and mobile development, as I consistently seek novel
				ideas and methodologies to elevate my skills and enrich the user experience.
</div> </div> </section> <section class="bg-color-1 clip bg-offwhite py-10 md:py-20 dark:bg-neutral-800"> <div class="container mx-auto flex flex-col items-center md:flex-row"> <div class="md:w-1/2"> <div> <ul class="text-base leading-relaxed"> <li class="pb-1"> <p> <strong class="text-secondary-400">Iterative Excellence:</strong> Code and art thrive
								through iterative processes. I embrace trial, error, and rapid iteration to create solutions
								that transcend boundaries.
</p> </li> <li class="pb-1"> <p> <strong class="text-secondary-400">Architects of Inclusivity:</strong> Developers shape
								a virtual landscape where inclusivity and user-centric design prevail. My goal is to create
								online spaces where every user feels a sense of belonging.
</p> </li> <li class="pb-1"> <p> <strong class="text-secondary-400">Humility in Design:</strong> Ego has no place in design.
								I approach work humbly, embracing failure to pave the way for rapid success.
</p> </li> <li class="pb-1"> <p> <strong class="text-secondary-400">Problem Definition:</strong> Effective design starts
								with clear problem definition. Understanding challenges leads to purposeful solutions.
</p> </li> <li class="pb-1"> <p> <strong class="text-secondary-400">Diverse Solutions:</strong> No single solution fits
								all. I explore creative possibilities to address unique contexts and demands.
</p> </li> <li> <p> <strong class="text-secondary-400">User-Centric Empathy:</strong> Guided by empathy, I
								design from a user-centric perspective, ensuring solutions resonate and provide value.
</p> </li> <li> <p> <strong class="text-secondary-400">Ethics and Impact:</strong> I prioritize privacy, security,
								and ethics, contributing to a digital landscape of integrity.
</p> </li> </ul> </div> </div> <h2 class="font-basement mb-6 text-2xl md:mb-0 md:w-1/2 md:text-3xl lg:text-6xl"> ${renderComponent($$result2, "BoxReveal", BoxReveal, { "boxColor": "bg-secondary-400 leading-12 w-full", "duration": 0.5, "client:idle": true, "width": "100%", "client:component-hydration": "idle", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate`<div class="w-full text-right">Philosophy</div> ` })} </h2> </div> </section> <section class="bg-color-10 py-10 md:py-20"> <div class="container mx-auto flex flex-col items-center md:flex-row"> <h2 class="font-basement mb-6 text-2xl md:mb-0 md:w-1/2 md:text-3xl lg:text-6xl"> ${renderComponent($$result2, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate`Motivators ` })} </h2> <div class="text-base leading-relaxed md:w-1/2"> <div> <ul> <li class="pb-1"> <p>
Tackling <strong class="text-primary-500">complex</strong> problems.
</p> </li> <li class="pb-1"> <p>
Empowering colleagues to contribute
<strong class="text-secondary-400"> meaningful</strong> insights.
</p> </li> <li class="pb-1"> <p>
Constructing cohesive and <strong class="text-purple-500">scalable software
</strong>
architectures.
</p> </li> <li class="pb-1"> <p>
Optimizing workflows. <strong class="text-[#d74f08]">Sharing expertise</strong>.
</p> </li> <li class="pb-1"> <p>
Establishing <strong class="text-teal-500">credibility</strong> and reliability.
</p> </li> <li> <p>
Code is not just functional; it molds
<strong class="text-lime-500">digital environments</strong>, driving innovation.
</p> </li> </ul> </div> </div> </div> </section> <section class="bg-color-1 py-10 md:py-20"> <div class="container mx-auto items-center"> <div class="flex flex-col items-center text-base leading-relaxed"> <img src="/img/tea.png" alt="Time for Tea" class="clip"> <h2 class="font-basement my-6 text-2xl md:text-3xl lg:text-6xl"> ${renderComponent($$result2, "BoxReveal", BoxReveal, { "boxColor": "bg-primary-500", "duration": 0.5, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/ui/box-reveal", "client:component-export": "default" }, { "default": ($$result3) => renderTemplate`It's Always Time for Tea
` })} </h2> <div class="text-center md:w-1/2">
It's always time for tea" reflects the value of creating space for connection and
					thoughtful collaboration. In tech, it serves as a reminder to pause, reflect, and engage
					with others meaningfully. This mindset fosters creativity, inclusivity, and innovative
					problem-solving, demonstrating that the best ideas emerge when teams feel supported and
					empowered to share their perspectives.
</div> </div> </div> </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/about.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/about.astro";
const $$url = "/about";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$About,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
