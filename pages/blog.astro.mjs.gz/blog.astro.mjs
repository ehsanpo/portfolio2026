import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_DoRYXERu.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_CJxF-kWY.mjs';
import { g as getBlogPosts } from '../chunks/data_Dx1U9qRg.mjs';
import { B as BlogCard } from '../chunks/BlogCard_CvNuq9hp.mjs';
import { $ as $$Pagination } from '../chunks/Pagination_DIaVxHh3.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const POSTS_PER_PAGE = 9;
  const blogPosts = await getBlogPosts();
  const featuredPosts = blogPosts.filter((post) => post.featured === true).slice(0, 4);
  const regularPosts = blogPosts.filter((post) => post.featured !== true);
  const totalPages = Math.max(1, Math.ceil(regularPosts.length / POSTS_PER_PAGE));
  const currentPage = 1;
  const paginatedRegularPosts = regularPosts.slice(0, POSTS_PER_PAGE);
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Blog - Thoughts and Insights", "description": "Thoughts, insights, and stories from my journey as a developer", "image": "/img/ogdefault.jpg", "imageAlt": "Ehsan's Blog - Developer Insights and Stories" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Blog", "subtitle": "Thoughts, insights, and stories from my journey as a developer" })} ${maybeRenderHead()}<div class="py-20"> <div class="container mx-auto px-4"> ${featuredPosts.length > 0 && renderTemplate`<div class="mb-16"> <h2 class="mb-8 text-3xl font-bold text-gray-900 dark:text-white">Featured Posts</h2> <div class="grid grid-cols-1 gap-8 md:grid-cols-2"> ${featuredPosts.map((post) => renderTemplate`${renderComponent($$result2, "BlogCard", BlogCard, { "post": post, "featured": true, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/ep/dev/portfolio2026/src/components/blog/BlogCard", "client:component-export": "BlogCard" })}`)} </div> </div>`} <div class="mb-8"> <h2 class="mb-8 text-3xl font-bold text-gray-900 dark:text-white"> ${featuredPosts.length > 0 ? "All Posts" : "Latest Posts"} </h2> </div> <div class="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3"> ${paginatedRegularPosts.map((post) => renderTemplate`${renderComponent($$result2, "BlogCard", BlogCard, { "post": post, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/ep/dev/portfolio2026/src/components/blog/BlogCard", "client:component-export": "BlogCard" })}`)} </div> ${renderComponent($$result2, "Pagination", $$Pagination, { "currentPage": currentPage, "totalPages": totalPages, "totalItems": regularPosts.length, "itemsPerPage": POSTS_PER_PAGE, "basePath": "/blog" })} ${blogPosts.length === 0 && renderTemplate`<div class="py-16 text-center"> <h3 class="mb-4 text-2xl font-semibold text-gray-600 dark:text-gray-400">
No blog posts yet
</h3> <p class="text-gray-500 dark:text-gray-500">
Stay tuned for upcoming articles and insights!
</p> </div>`} </div> </div> ` })}`;
}, "C:/Users/ep/dev/portfolio2026/src/pages/blog/index.astro", void 0);

const $$file = "C:/Users/ep/dev/portfolio2026/src/pages/blog/index.astro";
const $$url = "/blog";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
