import { d as createAstro, c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../../../chunks/Layout_D_CJek8b.mjs';
import { $ as $$PageHero } from '../../../chunks/PageHero_C-utCR6y.mjs';
import { g as getBlogPosts } from '../../../chunks/data_C03_04XE.mjs';
import { B as BlogCard } from '../../../chunks/BlogCard_Dy6tugER.mjs';
import { $ as $$Pagination } from '../../../chunks/Pagination_DIaVxHh3.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro("https://ehsan-pourhadi.com/");
async function getStaticPaths() {
  const POSTS_PER_PAGE = 9;
  const blogPosts = await getBlogPosts();
  const regularPosts = blogPosts.filter((post) => post.featured !== true);
  const totalPages = Math.max(1, Math.ceil(regularPosts.length / POSTS_PER_PAGE));
  const paths = [];
  for (let p = 2; p <= totalPages; p++) {
    const start = (p - 1) * POSTS_PER_PAGE;
    const end = start + POSTS_PER_PAGE;
    paths.push({
      params: { page: String(p) },
      props: {
        currentPage: p,
        totalPages,
        regularPosts: regularPosts.slice(start, end),
        totalItems: regularPosts.length
      }
    });
  }
  return paths;
}
const $$page = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$page;
  const POSTS_PER_PAGE = 9;
  const { currentPage, totalPages, regularPosts, totalItems } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `Blog - Page ${currentPage}`, "description": `Articles, insights, and stories from my developer journey - Page ${currentPage}`, "image": "/img/ogdefault.jpg", "imageAlt": "Ehsan's Blog - Developer Insights and Stories" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Blog", "subtitle": `Articles & stories from my creative journey (Page ${currentPage})` })} ${maybeRenderHead()}<div class="py-20"> <div class="container mx-auto px-4"> <div class="mb-8"> <h2 class="mb-8 text-3xl font-bold text-gray-900 dark:text-white">
Articles (Page ${currentPage} of ${totalPages})
</h2> </div> <div class="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3"> ${regularPosts.map((post) => renderTemplate`${renderComponent($$result2, "BlogCard", BlogCard, { "post": post, "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/ep/dev/portfolio2026/src/components/blog/BlogCard", "client:component-export": "BlogCard" })}`)} </div> ${renderComponent($$result2, "Pagination", $$Pagination, { "currentPage": currentPage, "totalPages": totalPages, "totalItems": totalItems, "itemsPerPage": POSTS_PER_PAGE, "basePath": "/blog" })} </div> </div> ` })}`;
}, "C:/Users/ep/dev/portfolio2026/src/pages/blog/page/[page].astro", void 0);

const $$file = "C:/Users/ep/dev/portfolio2026/src/pages/blog/page/[page].astro";
const $$url = "/blog/page/[page]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$page,
	file: $$file,
	getStaticPaths,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
