import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { jsxs, jsx } from 'react/jsx-runtime';
import { useRef, useState, useEffect } from 'react';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
export { renderers } from '../renderers.mjs';

function SpotifyEmbed({ playlistId, title }) {
  const containerRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    if (isVisible) return;
    const target = containerRef.current;
    if (!target) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: "0px" }
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, [isVisible]);
  return /* @__PURE__ */ jsxs("div", { ref: containerRef, className: "bg-dark/50 rounded-lg p-6 backdrop-blur-lg", children: [
    /* @__PURE__ */ jsx("h3", { className: "font-basement mb-4 text-xl", children: title }),
    /* @__PURE__ */ jsx("div", { className: "relative aspect-[4/5] w-full overflow-hidden rounded-lg bg-black/30", children: isVisible ? /* @__PURE__ */ jsx(
      "iframe",
      {
        title: `${title} Spotify playlist`,
        src: `https://open.spotify.com/embed/album/${playlistId}`,
        width: "100%",
        height: "100%",
        allow: "autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture",
        loading: "lazy",
        className: "absolute inset-0 h-full w-full"
      }
    ) : /* @__PURE__ */ jsx("div", { className: "flex h-full w-full items-center justify-center text-xs text-muted-foreground", children: "Loading Spotify embed..." }) })
  ] });
}

const $$Music = createComponent(($$result, $$props, $$slots) => {
  const musicFiles = [
    {
      filename: "Ehsan Pourhadi - Call me_output.wav",
      title: "Call me",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Call me_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Comes Again (Extend)_output.wav",
      title: "Comes Again (Extend)",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Comes Again (Extend)_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Doom_output.wav",
      title: "Doom",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Doom_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Exit_output.wav",
      title: "Exit",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Exit_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Falling_output.wav",
      title: "Falling",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Falling_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Falling_output_output.wav",
      title: "Falling",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Falling_output_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Habbits_output.wav",
      title: "Habbits",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Habbits_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - livet g\xE5r vidare_output.wav",
      title: "Livet g\xE5r vidare",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - livet g\xE5r vidare_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Never Be Loanly_output.wav",
      title: "Never Be Lonely",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Never Be Loanly_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Skyline_output.wav",
      title: "Skyline",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Skyline_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Sometimes _output.wav",
      title: "Sometimes",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Sometimes _output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Spaced Out Remix_output.wav",
      title: "Spaced Out Remix",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Spaced Out Remix_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - trap_output.wav",
      title: "Trap",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - trap_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - untiteled 17 -2 _output.wav",
      title: "Untitled 17",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - untiteled 17 -2 _output.wav"
    },
    {
      filename: "Ehsan Pourhadi - untitled 9 _output.wav",
      title: "Untitled 9",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - untitled 9 _output.wav"
    },
    {
      filename: "Ehsan Pourhadi - Voices in my head_output.wav",
      title: "Voices in my head",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - Voices in my head_output.wav"
    },
    {
      filename: "Ehsan Pourhadi - WORK IT OUT!_output.wav",
      title: "Work It Out!",
      artist: "Ehsan Pourhadi",
      src: "/music/Ehsan Pourhadi - WORK IT OUT!_output.wav"
    },
    { filename: "L.mp3", title: "L", artist: "Ehsan Pourhadi", src: "/music/L.mp3" }
  ];
  const playlists = [
    {
      playlistId: "5PUExiuXHdh71FCOME9eVA",
      title: "2020 - 2020"
    },
    {
      playlistId: "0AxIzHIcCeyu8z6JqidQtX",
      title: "Future - 2020"
    },
    {
      playlistId: "0e5MIP4vPxL2DtADJFD301",
      title: "Present - 2020"
    },
    {
      playlistId: "1ewlhbOoQAHakrgaEuXWry",
      title: "The Past - 2019"
    },
    {
      playlistId: "5VIhDY0sy0rKd2z68T2yRD",
      title: "The Wind - 2019"
    },
    {
      playlistId: "2nz5ZaS4XeSXO5D9jNP9cD",
      title: "Life Goes On - 2003"
    },
    {
      playlistId: "7oGREogIXr9kBU6cVvTytF",
      title: "Noor - 2022"
    },
    {
      playlistId: "2avKo7p73VQlQZuZ5AhdsX",
      title: "Bellerina - 2022"
    },
    {
      playlistId: "4VzPczlIoeB84Nn1HsuFq6",
      title: "20 - 2022"
    },
    {
      playlistId: "15gO287YrDb4sNHckk5wiJ",
      title: "Divane - 2021"
    },
    {
      playlistId: "1SVNdrRPEto1RXbmX9Oyy9",
      title: "Malm\xF6 Syndrome - 2021"
    },
    {
      playlistId: "04RmkiqoBN6VFU5XQvS0CE",
      title: "Infinity - 2021"
    },
    {
      playlistId: "3i4AVKxg8Znjot9NlO6ie8",
      title: "Spaced out - 2020"
    },
    {
      playlistId: "2nKd39bGTeA5MTq0z21c0I",
      title: "Fallen Angels - 2019"
    },
    {
      playlistId: "5SuRJpmUEks2akEQx9qWAl",
      title: "Getaway - 2019"
    },
    {
      playlistId: "4etfZNUXJ0DljYEvpKIWxy",
      title: "Hope - 2017"
    },
    {
      playlistId: "1aDI4c4U1vQQy9mXbUIiIN",
      title: "The Demo - 2010"
    }
  ];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Music - Developer Portfolio" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Music" })} ${maybeRenderHead()}<div class="container mx-auto px-4 py-20"> <div class="mb-20"> ${renderComponent($$result2, "LocalMusicPlayer", null, { "client:only": "react", "tracks": musicFiles, "client:component-hydration": "only", "client:component-path": "@/components/audio/LocalMusicPlayer", "client:component-export": "default" })} </div> <div> <h2 class="mb-8 text-3xl font-bold dark:text-white">Spotify Playlists</h2> <div class="grid gap-4 md:grid-cols-3"> ${playlists.map((playlist) => renderTemplate`${renderComponent($$result2, "SpotifyEmbed", SpotifyEmbed, { ...playlist, "client:visible": true, "client:component-hydration": "visible", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/audio/SpotifyEmbed", "client:component-export": "default" })}`)} </div> </div> </div> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/music.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/music.astro";
const $$url = "/music";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Music,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
