import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
import { a as getPortfolioItems } from '../chunks/data_DqvtT1J2.mjs';
import { P as PortfolioFilter } from '../chunks/PortfolioFilter_D5xvuWzt.mjs';
import { P as ProjectCard3D } from '../chunks/ProjectCard3D_CSBmQc0h.mjs';
import { g as getProjectImage } from '../chunks/projectHelpers_Q9_CjjLW.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const portfolioItems = await getPortfolioItems();
  const sortedItems = portfolioItems.sort((a, b) => {
    return Number(b.port_date) - Number(a.port_date);
  });
  const allCategories = [...new Set(portfolioItems.flatMap((entry) => entry.category || []))].filter(
    (c) => !!c
  );
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Portfolio - Work", "description": "A showcase of my selected works and projects", "image": "/img/ogdefault.jpg", "imageAlt": "Ehsan's Portfolio - Selected Works and Projects" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Portfolio", "subtitle": "A showcase of my selected works and projects" })} ${maybeRenderHead()}<div class="py-20"> <div class="container mx-auto px-4"> ${renderComponent($$result2, "PortfolioFilter", PortfolioFilter, { "categories": allCategories, "category": "all", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/PortfolioFilter", "client:component-export": "default" })} <div class="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3"> ${sortedItems.map((item, index) => renderTemplate`${renderComponent($$result2, "ProjectCard3D", ProjectCard3D, { "title": item.title || "", "description": item.tagline || "", "date": item.port_date, "categories": item.category, "tags": item.tag, "image": getProjectImage(item), "href": `/portfolio/${item.permalink || item.slug}`, "layout": index, "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/ProjectCard3D", "client:component-export": "ProjectCard3D" })}`)} </div> </div> </div> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/portfolio/index.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/portfolio/index.astro";
const $$url = "/portfolio";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
