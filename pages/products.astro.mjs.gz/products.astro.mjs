import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead, a as addAttribute } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
import { b as getProductItems } from '../chunks/data_DqvtT1J2.mjs';
import { P as PortfolioFilter } from '../chunks/PortfolioFilter_D5xvuWzt.mjs';
import { P as ProjectCard3D } from '../chunks/ProjectCard3D_CSBmQc0h.mjs';
import { g as getProjectImage } from '../chunks/projectHelpers_Q9_CjjLW.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const productItems = await getProductItems();
  const parseDateValue = (dateStr) => {
    const normalized = /^\d{4}-\d{2}$/.test(dateStr) ? `${dateStr}-01` : dateStr;
    return new Date(normalized).getTime();
  };
  const sortedItems = productItems.sort((a, b) => {
    return parseDateValue(b.date) - parseDateValue(a.date);
  });
  const allCategories = [...new Set(productItems.flatMap((entry) => entry.category || []))];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Products - Work", "description": "A showcase of my products and digital creations", "image": "/img/ogdefault.jpg", "imageAlt": "Ehsan's Products - Digital Creations and Tools" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Products", "subtitle": "A showcase of my products and digital creations" })} ${maybeRenderHead()}<div class="py-20"> <div class="container mx-auto px-4"> ${renderComponent($$result2, "PortfolioFilter", PortfolioFilter, { "categories": allCategories, "category": "all", "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/PortfolioFilter", "client:component-export": "default" })} <div class="grid grid-cols-1 gap-8 md:grid-cols-3"> ${sortedItems.map((item, index) => renderTemplate`<a${addAttribute(`/products/${item.permalink || item.slug}`, "href")}${addAttribute(JSON.stringify(item.category || []), "data-categories")} class="group/card-link block h-full cursor-pointer"> ${renderComponent($$result2, "ProjectCard3D", ProjectCard3D, { "client:load": true, "title": item.title, "description": item.tagline, "date": item.date, "categories": item.category, "tags": item.tag, "image": getProjectImage(item), "icon": item.logo?.src, "glowColor": "rgba(255, 238, 8, 0.2)", "className": "h-full", "layout": index, "client:component-hydration": "load", "client:component-path": "@/components/ProjectCard3D", "client:component-export": "ProjectCard3D" })} </a>`)} </div> </div> </div> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/products/index.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/products/index.astro";
const $$url = "/products";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
