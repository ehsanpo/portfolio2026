import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead, a as addAttribute } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
import { c as getPrompts } from '../chunks/data_DqvtT1J2.mjs';
import { C as Card3D } from '../chunks/Card3D_BEIy0EXF.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const prompts = await getPrompts();
  const categories = [...new Set(prompts.map((p) => p.category).filter(Boolean))];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "AI Prompts - Collection", "description": "A collection of AI prompts for various tasks and projects", "image": "/img/ogdefault.jpg", "imageAlt": "Ehsan's AI Prompts Collection" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "AI Prompts", "subtitle": "A collection of AI prompts for various tasks" })} ${maybeRenderHead()}<div class="border-t border-white/5 bg-neutral-900 py-20"> <div class="container mx-auto px-4"> ${categories.map((category) => {
    const categoryPrompts = prompts.filter((p) => p.category === category);
    return renderTemplate`<div class="mb-16"> <h2 class="mb-10 flex items-center gap-4 text-4xl font-black tracking-tighter text-white uppercase"> ${category} <span class="h-px flex-1 bg-linear-to-r from-white/10 to-transparent"></span> </h2> <div class="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-3"> ${categoryPrompts.map((prompt) => renderTemplate`${renderComponent($$result2, "Card3D", Card3D, { "client:load": true, "className": "h-[400px]", "glowColor": "rgba(255, 199, 0, 0.15)", "client:component-hydration": "load", "client:component-path": "C:/Users/Ehsan/dev/portfolio2026/src/components/Card3D", "client:component-export": "Card3D" }, { "default": async ($$result3) => renderTemplate` <div class="preserve-3d flex h-full flex-col items-start p-6"> <div class="group-hover/card:bg-primary/5 group-hover/card:border-primary/20 mb-6 flex h-44 w-full items-center justify-center overflow-hidden rounded-xl border border-white/10 bg-white/5 transition-all duration-500" style="transform: translateZ(30px)"> ${prompt.image ? renderTemplate`<img${addAttribute(prompt.image, "src")}${addAttribute(prompt.title, "alt")} class="h-full w-full object-cover opacity-40 transition-all duration-700 group-hover/card:scale-110 group-hover/card:opacity-100">` : renderTemplate`<span class="text-6xl transition-all duration-500 group-hover/card:scale-110 group-hover/card:rotate-6"> ${prompt.icon || "\u2728"} </span>`} </div> <div class="preserve-3d flex flex-1 flex-col gap-3"> <h3 class="group-hover/card:text-primary text-2xl leading-tight font-black text-white transition-all duration-500" style="transform: translateZ(50px); text-shadow: 0 10px 20px rgba(0,0,0,0.5);"> ${prompt.title} </h3> <p class="line-clamp-3 text-sm leading-relaxed font-medium text-white/50" style="transform: translateZ(30px)"> ${prompt.description} </p> </div> <div class="mt-auto flex w-full items-center justify-between pt-6" style="transform: translateZ(40px)"> <div class="flex flex-wrap gap-2"> ${prompt.tags?.slice(0, 2).map((tag) => renderTemplate`<span class="group-hover/card:border-primary/30 group-hover/card:text-primary/70 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-[9px] font-black tracking-widest text-white/30 uppercase transition-all duration-500">
#${tag} </span>`)} </div> <div class="text-primary -translate-x-4 opacity-0 transition-all duration-500 group-hover/card:translate-x-0 group-hover/card:opacity-100" style="transform: translateZ(60px)"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"> <path d="M5 12h14"></path> <path d="m12 5 7 7-7 7"></path> </svg> </div> </div> <a${addAttribute(`/prompts/${prompt.slug}`, "href")} class="absolute inset-0 z-30"${addAttribute(`View ${prompt.title}`, "aria-label")}></a> </div> ` })}`)} </div> </div>`;
  })} </div> </div> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/prompts/index.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/prompts/index.astro";
const $$url = "/prompts";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
