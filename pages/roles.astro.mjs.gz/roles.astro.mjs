import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead, a as addAttribute } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout, b as getRoles } from '../chunks/Layout_zewWmYqx.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
import { P as ProjectCard3D } from '../chunks/ProjectCard3D_CSBmQc0h.mjs';
import { g as getRoleImage } from '../chunks/roleImageMap_BgqfBJeZ.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  const roles = getRoles();
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Professional Roles - Ehsan Pourhadi" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Versatile Expertise", "subtitle": "Throughout my career, I've worn many hats and adapted to various roles. Each position has shaped my understanding of technology, product development, and team dynamics. Explore the different roles where I can add value to your organization." })} ${maybeRenderHead()}<section class="container mx-auto px-4 py-12"> <div class="mx-auto max-w-6xl"> <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"> ${roles.map((role, index) => {
    const mappedImage = role.image ? getRoleImage(role.image) : void 0;
    const displayImage = mappedImage && {
      src: mappedImage.src,
      alt: role.title,
      width: mappedImage.width,
      height: mappedImage.height
    };
    return renderTemplate`<a${addAttribute(`/roles/${role.slug}`, "href")} class="block h-full cursor-pointer"> ${renderComponent($$result2, "ProjectCard3D", ProjectCard3D, { "client:load": true, "title": role.title, "description": role.description, "icon": role.icon, "image": displayImage, "tags": role.tags, "layout": index, "className": "h-full", "client:component-hydration": "load", "client:component-path": "@/components/ProjectCard3D", "client:component-export": "ProjectCard3D" })} </a>`;
  })} </div> <div class="from-primary-500 to-secondary-400 mt-16 rounded-lg bg-gradient-to-r p-8 text-center text-black"> <h3 class="mb-4 text-2xl font-bold">Ready to Work Together?</h3> <p class="mb-6 text-lg opacity-90">
Whether you need technical expertise, strategic leadership, or creative solutions, I'm
					here to help bring your vision to life.
</p> <a href="/contact" class="text-primary-600 inline-flex items-center gap-2 rounded-lg bg-white px-6 py-3 font-medium transition-all hover:bg-gray-100 hover:shadow-lg">
Get in Touch
<svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h8m-8 0l4 4m-4-4l4-4"></path> </svg> </a> </div> </div> </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/index.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/roles/index.astro";
const $$url = "/roles";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
