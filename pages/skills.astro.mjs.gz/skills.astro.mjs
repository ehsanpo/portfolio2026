import { c as createComponent, m as maybeRenderHead, r as renderComponent, b as renderTemplate } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { g as getPortfolioData, c as cn, $ as $$Layout } from '../chunks/Layout_IgJG5QTq.mjs';
import { S as SkillChart } from '../chunks/SkillChart_D9cUMBlT.mjs';
import { jsx, jsxs, Fragment } from 'react/jsx-runtime';
import { useMemo, useState, useRef, useEffect } from 'react';
import { Tooltip } from 'react-tooltip';
/* empty css                                  */
import { C as Card3D } from '../chunks/Card3D_YIivOgrE.mjs';
import { $ as $$TechStackBlock, a as $$CertificatesBlock } from '../chunks/TechStackBlock_BHu9rVe2.mjs';
import { $ as $$ToolsList, P as ProcessFlowDiagram } from '../chunks/Beams_Adlvj-2M.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_NVFPCKfG.mjs';
import { H as Heading } from '../chunks/Heading_BxFSbb9O.mjs';
import CalendarHeatmap from 'react-calendar-heatmap';
export { renderers } from '../renderers.mjs';

const START_YEAR = 2010;
const END_YEAR = 2026;
const TOTAL_YEARS = END_YEAR - START_YEAR;
const YEARS = Array.from({ length: TOTAL_YEARS + 1 }, (_, i) => START_YEAR + i);

const categoryBadgeStyles = {
	Frontend: "bg-teal-500/15 text-teal-400 border-teal-500/30",
	Backend: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
	Database: "bg-amber-500/15 text-amber-400 border-amber-500/30",
	DevOps: "bg-sky-500/15 text-sky-400 border-sky-500/30",
	Apps: "bg-indigo-500/15 text-indigo-400 border-indigo-500/30",
	Design: "bg-purple-500/15 text-purple-400 border-purple-500/30",
};

const categoryColors = {
	Frontend: "bg-teal-400 text-teal-950",
	Backend: "bg-emerald-400 text-emerald-950",
	Database: "bg-amber-300 text-amber-950",
	DevOps: "bg-sky-400 text-sky-950",
	Apps: "bg-indigo-300 text-indigo-950",
	Design: "bg-purple-300 text-purple-950",
};

const defaultBadgeStyle = "bg-muted/50 text-muted-foreground border-white/40";
const defaultColor = "bg-teal-300 text-teal-950";

// Color glow accents per era to make it flashy and 3D
const getEraGlowColor = (year) => {
	if (year <= 2013) return "rgba(45, 212, 191, 0.4)";
	if (year <= 2017) return "rgba(245, 158, 11, 0.4)";
	if (year <= 2020) return "rgba(56, 189, 248, 0.4)";
	if (year <= 2023) return "rgba(168, 85, 247, 0.45)";
	return "rgba(236, 72, 153, 0.45)";
};

const calculateDurationYears = (durationStr) => {
	if (!durationStr) return "";
	const [s, e] = durationStr.split("-").map(Number);
	const yrs = e - s;
	return `${yrs} ${yrs === 1 ? "year" : "years"}`;
};

const calculateRowPositions = (items) => {
	const occupied = [];
	return items.map((item) => {
		const start = parseInt(item.duration.split("-")[0], 10) - START_YEAR;
		const end = parseInt(item.duration.split("-")[1], 10) - START_YEAR;
		let r = 0;

		while (occupied.some(([s, e, row]) => start < e && end > s && r === row)) {
			r++;
		}

		occupied.push([start, end, r]);
		return { ...item, start, end, adjustedRowIndex: r };
	});
};

// Soft, responsive pagination calculator (never overflows, no horizontal scrolling)
const getPaginationItems = (active, allYears) => {
	const total = allYears.length;
	const first = allYears[0];
	const last = allYears[total - 1];

	let left = active - 1;
	let right = active + 1;

	if (active <= first + 2) {
		left = first;
		right = Math.min(first + 3, last);
	} else if (active >= last - 2) {
		left = Math.max(last - 3, first);
		right = last;
	}

	const range = [];
	const items = [];
	let prev;

	for (let i = 0; i < total; i++) {
		const y = allYears[i];
		if (y === first || y === last || (y >= left && y <= right)) {
			range.push(y);
		}
	}

	for (const y of range) {
		if (prev !== undefined) {
			if (y - prev === 2) {
				items.push(prev + 1);
			} else if (y - prev > 2) {
				items.push(`ellipsis-${prev}`);
			}
		}
		items.push(y);
		prev = y;
	}

	return items;
};

const RankTimelinePagination = ({
  activeYear,
  years,
  onSelectYear,
  onPrev,
  onNext,
  startYear,
  endYear
}) => {
  const paginationItems = useMemo(
    () => getPaginationItems(activeYear, years),
    [activeYear, years]
  );
  return /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center w-full mb-6 px-1", children: /* @__PURE__ */ jsxs(
    "nav",
    {
      "aria-label": "Timeline Pagination",
      className: "inline-flex items-center gap-1 sm:gap-1.5 p-1.5 rounded-2xl bg-card/70 dark:bg-neutral-900/60 border border-white/40 backdrop-blur-md shadow-xs max-w-full",
      children: [
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: onPrev,
            disabled: activeYear === startYear,
            "aria-label": "Previous year",
            className: "inline-flex items-center gap-1 px-2.5 sm:px-3 h-9 rounded-xl text-xs sm:text-sm font-semibold text-muted-foreground hover:text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsx(
                "svg",
                {
                  width: "16",
                  height: "16",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2.5",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  children: /* @__PURE__ */ jsx("polyline", { points: "15 18 9 12 15 6" })
                }
              ),
              /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Prev" })
            ]
          }
        ),
        paginationItems.map((item) => {
          if (typeof item === "string" && item.startsWith("ellipsis")) {
            return /* @__PURE__ */ jsx(
              "span",
              {
                className: "w-6 h-9 flex items-center justify-center text-xs text-muted-foreground/60 font-bold select-none",
                children: "•••"
              },
              item
            );
          }
          const year = item;
          const isSelected = activeYear === year;
          return /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => onSelectYear(year),
              "aria-current": isSelected ? "page" : void 0,
              className: `h-9 min-w-9 px-2 sm:px-3 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer ${isSelected ? "bg-primary text-black font-bold shadow-sm shadow-primary/20 scale-102" : "text-muted-foreground hover:text-foreground hover:bg-muted/60"}`,
              children: year
            },
            year
          );
        }),
        /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            onClick: onNext,
            disabled: activeYear === endYear,
            "aria-label": "Next year",
            className: "inline-flex items-center gap-1 px-2.5 sm:px-3 h-9 rounded-xl text-xs sm:text-sm font-semibold text-muted-foreground hover:text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:pointer-events-none transition-all cursor-pointer",
            children: [
              /* @__PURE__ */ jsx("span", { className: "hidden sm:inline", children: "Next" }),
              /* @__PURE__ */ jsx(
                "svg",
                {
                  width: "16",
                  height: "16",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2.5",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  children: /* @__PURE__ */ jsx("polyline", { points: "9 18 15 12 9 6" })
                }
              )
            ]
          }
        )
      ]
    }
  ) });
};

const RankStoryCard = ({
  card,
  isSelected,
  onSelect,
  categoryBadgeStyles,
  defaultBadgeStyle
}) => {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-year": card.year,
      onClick: onSelect,
      className: "w-[88vw] max-w-[480px] sm:w-[440px] md:w-[480px] flex-shrink-0 snap-center transition-all duration-300",
      children: /* @__PURE__ */ jsx(
        Card3D,
        {
          intensity: -10,
          glowColor: card.glowColor,
          shine: true,
          className: "h-full",
          childClassName: `h-full p-6 sm:p-9 rounded-3xl border transition-all duration-300 ${isSelected ? "border-primary/70 shadow-2xl ring-2 ring-primary/40 bg-card/95 dark:bg-neutral-900/95" : "border-white/15 dark:border-neutral-800/80 bg-card/60 dark:bg-neutral-900/60 hover:border-primary/40 hover:shadow-xl"} backdrop-blur-2xl`,
          children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-between h-full p-6 preserve-3d", children: [
            /* @__PURE__ */ jsxs("div", { className: "preserve-3d", children: [
              /* @__PURE__ */ jsxs(
                "div",
                {
                  className: "preserve-3d flex flex-col items-center justify-center text-center border-b border-white/10 dark:border-neutral-800/80 pb-5 mb-5",
                  style: { transform: "translateZ(30px)" },
                  children: [
                    /* @__PURE__ */ jsx("span", { className: "text-4xl sm:text-3xl font-black tracking-tight text-foreground font-['Basement',sans-serif]", children: card.year }),
                    /* @__PURE__ */ jsxs("span", { className: "text-xs sm:text-sm font-semibold uppercase tracking-wider px-3.5 py-1 rounded clip2 bg-white/10 dark:bg-neutral-800/80 text-muted-foreground border border-white/10 mt-2.5", children: [
                      card.totalActive,
                      " active stack tools"
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "mb-5 preserve-3d", children: [
                /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: "text-xs sm:text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2",
                    style: { transform: "translateZ(20px)" },
                    children: [
                      /* @__PURE__ */ jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-primary inline-block shadow-xs shadow-primary animate-pulse" }),
                      /* @__PURE__ */ jsx("span", { children: "Top 5 Focus Technologies" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-2.5 preserve-3d", children: card.top5.map((tool) => {
                  const badgeStyle = categoryBadgeStyles[tool.category] || defaultBadgeStyle;
                  return /* @__PURE__ */ jsxs(
                    "div",
                    {
                      "data-tooltip-id": "timeline-tooltip",
                      "data-tooltip-content": `${tool.name} • Active: ${tool.duration} (${calculateDurationYears(tool.duration)}) • ${tool.category}`,
                      className: "preserve-3d group/item flex items-center justify-between p-2 rounded bg-white/[0.06] hover:bg-white/[0.14] dark:bg-neutral-800/40 dark:hover:bg-neutral-800/90 border border-white/20 hover:border-primary/50 transition-all duration-200 shadow-xs cursor-pointer hover:translate-z-5 hover:scale-105 hover:shadow-md hover:border-2",
                      style: { transform: "translateZ(25px)" },
                      children: [
                        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3.5 min-w-0 preserve-3d", children: [
                          tool.icon && /* @__PURE__ */ jsx(
                            "img",
                            {
                              src: tool.icon,
                              alt: "",
                              className: "w-6 h-6 flex-shrink-0 object-contain drop-shadow-md group-hover/item:scale-125 group-hover/item:rotate-6 transition-transform duration-200"
                            }
                          ),
                          /* @__PURE__ */ jsx("span", { className: "font-semibold text-sm text-foreground truncate group-hover/item:text-primary transition-colors", children: tool.name })
                        ] }),
                        /* @__PURE__ */ jsx(
                          "span",
                          {
                            className: `text-xs font-semibold px-2.5 py-0.5 rounded-full border ${badgeStyle} flex-shrink-0 ml-2 group-hover/item:shadow-xs transition-transform duration-200`,
                            children: tool.category
                          }
                        )
                      ]
                    },
                    tool.name
                  );
                }) })
              ] })
            ] }),
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: "pt-4 border-t border-white/10 dark:border-neutral-800/80 mt-2",
                style: { transform: "translateZ(15px)" },
                children: [
                  /* @__PURE__ */ jsxs("div", { className: "text-xs sm:text-sm font-semibold uppercase tracking-wider text-muted-foreground/80 mb-2.5 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsx("span", { children: "Other Active Tools" }),
                    /* @__PURE__ */ jsx("span", { className: "text-xs font-mono font-bold px-2 py-0.5 rounded bg-white/5 dark:bg-neutral-800/60 text-muted-foreground border border-white/10", children: card.supporting.length })
                  ] }),
                  /* @__PURE__ */ jsx("div", { className: "ranktimeline-icons-drawer flex flex-wrap gap-2 max-h-[140px] overflow-y-auto scrollbar-none p-2.5 rounded-2xl bg-black/10 dark:bg-neutral-950/30 border border-white/5", children: card.supporting.map((tool) => /* @__PURE__ */ jsx(
                    "div",
                    {
                      "data-tooltip-id": "timeline-tooltip",
                      "data-tooltip-content": `${tool.name} (${tool.duration}) • ${tool.category}`,
                      className: "w-8 h-8 rounded-lg bg-white/[0.06] hover:bg-primary/25 dark:bg-neutral-800/50 dark:hover:bg-primary/30 border border-white/10 hover:border-primary/50 flex items-center justify-center transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md shadow-xs cursor-pointer flex-shrink-0",
                      children: tool.icon ? /* @__PURE__ */ jsx(
                        "img",
                        {
                          src: tool.icon,
                          alt: tool.name,
                          className: "w-5 h-5 object-contain"
                        }
                      ) : /* @__PURE__ */ jsx("span", { className: "text-xs font-bold text-muted-foreground", children: tool.name.slice(0, 2) })
                    },
                    tool.name
                  )) })
                ]
              }
            )
          ] })
        }
      )
    }
  );
};

const fromDate = (item) => parseInt(item.duration.split("-")[0], 10);
const toDate = (item) => parseInt(item.duration.split("-")[1], 10);
const RankTimelineGrid = ({
  categories,
  activeCategory,
  onSelectCategory,
  timelineData,
  displayedTimelineItems,
  totalTimelineRows,
  categoryColors,
  defaultColor,
  years,
  gridScrollRef
}) => {
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2 flex-wrap", children: categories.map((cat) => /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        className: `px-3.5 py-2 rounded-xl text-sm font-semibold transition-all cursor-pointer ${activeCategory === cat ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted/60 text-muted-foreground hover:bg-muted hover:text-foreground"}`,
        onClick: () => onSelectCategory(cat),
        children: [
          cat,
          /* @__PURE__ */ jsxs("span", { className: "ml-1.5 opacity-70 text-xs", children: [
            "(",
            cat === "All" ? timelineData.length : timelineData.filter((i) => i.category === cat).length,
            ")"
          ] })
        ]
      },
      cat
    )) }),
    /* @__PURE__ */ jsx(
      "div",
      {
        ref: gridScrollRef,
        className: "ranktimeline-wrap relative overflow-auto rounded-xl border border-white/40 bg-card/30",
        style: {
          maxHeight: "calc(var(--row-height) * 15 + var(--year-height))"
        },
        children: /* @__PURE__ */ jsxs(
          "div",
          {
            className: "relative",
            style: {
              width: "calc(var(--col-width) * 12 * 16)",
              minWidth: "calc(var(--col-width) * 12 * 16)"
            },
            children: [
              /* @__PURE__ */ jsx("div", { className: "flex h-10 border-b border-white/40 sticky top-0 z-30 select-none bg-card/90 dark:bg-neutral-900/90 backdrop-blur-md", children: years.map((year, index) => /* @__PURE__ */ jsx(
                "div",
                {
                  className: "flex-shrink-0 flex items-center text-sm font-mono font-bold text-muted-foreground pl-2",
                  style: { width: "calc(var(--col-width) * 12)" },
                  children: /* @__PURE__ */ jsx("span", { children: year })
                },
                index
              )) }),
              /* @__PURE__ */ jsx("div", { className: "absolute top-10 bottom-0 left-0 right-0 pointer-events-none z-0", children: years.map((year, index) => /* @__PURE__ */ jsx(
                "div",
                {
                  className: "absolute top-0 bottom-0 border-l border-dashed border-white/20",
                  style: { left: `calc(var(--col-width) * ${index * 12})` }
                },
                year
              )) }),
              /* @__PURE__ */ jsx(
                "div",
                {
                  className: "relative z-10",
                  style: {
                    height: `calc(var(--row-height) * ${totalTimelineRows})`
                  },
                  children: displayedTimelineItems.map((item) => {
                    const colorClass = categoryColors[item.category] || defaultColor;
                    return /* @__PURE__ */ jsx(
                      "div",
                      {
                        className: "absolute group",
                        style: {
                          left: `calc(var(--col-width) * ${item.start * 12})`,
                          width: `calc(var(--col-width) * ${(item.end - item.start) * 12})`,
                          height: "var(--row-height)",
                          top: `calc(var(--row-height) * ${item.adjustedRowIndex})`
                        },
                        children: /* @__PURE__ */ jsx(
                          "div",
                          {
                            "data-tooltip-id": "timeline-tooltip",
                            "data-tooltip-content": `${item.name} • Active: ${item.duration} (${calculateDurationYears(item.duration)}) • ${item.category}`,
                            className: `absolute inset-x-[1px] inset-y-[2px] rounded-md flex items-center px-2.5 text-sm font-medium cursor-pointer transition-opacity duration-150 hover:opacity-90 ${colorClass}`,
                            "data-id": item.id,
                            children: /* @__PURE__ */ jsxs("span", { className: "sticky left-2 flex items-center gap-2 whitespace-nowrap truncate max-w-full", children: [
                              item.icon && /* @__PURE__ */ jsx(
                                "img",
                                {
                                  src: item.icon,
                                  alt: "",
                                  className: "w-4 h-4 flex-shrink-0"
                                }
                              ),
                              /* @__PURE__ */ jsx("span", { className: "truncate font-semibold", children: item.name }),
                              /* @__PURE__ */ jsxs("span", { className: "hidden group-hover:inline opacity-75 font-normal ml-1 flex-shrink-0 text-xs", children: [
                                "- ",
                                fromDate(item),
                                fromDate(item) + 1 === toDate(item) ? "" : ` - ${toDate(item) - 1}`
                              ] })
                            ] })
                          }
                        )
                      },
                      item.id + item.name
                    );
                  })
                }
              )
            ]
          }
        )
      }
    )
  ] });
};

const RankTimeline = () => {
  const portfolioData = getPortfolioData();
  const timelineData = portfolioData.timeline;
  const highlightsMap = portfolioData.timelineHighlights || {};
  const [viewMode, setViewMode] = useState("cards");
  const [activeYear, setActiveYear] = useState(2026);
  const [activeCategory, setActiveCategory] = useState("All");
  const scrollContainerRef = useRef(null);
  const gridScrollRef = useRef(null);
  const yearCards = useMemo(() => {
    return YEARS.map((year) => {
      const activeTools = timelineData.filter((item) => {
        const [s, e] = item.duration.split("-").map(Number);
        return year >= s && year <= e;
      });
      const topNames = highlightsMap[String(year)] || [];
      const top5Tools = topNames.map((name) => timelineData.find((t) => t.name === name)).filter(Boolean);
      const supportingTools = activeTools.filter(
        (item) => !topNames.includes(item.name)
      );
      return {
        year,
        top5: top5Tools,
        supporting: supportingTools,
        totalActive: activeTools.length,
        glowColor: getEraGlowColor(year)
      };
    });
  }, [timelineData, highlightsMap]);
  const categories = useMemo(() => {
    const cats = Array.from(
      new Set(timelineData.map((item) => item.category).filter(Boolean))
    );
    return ["All", ...cats];
  }, [timelineData]);
  const displayedTimelineItems = useMemo(() => {
    if (activeCategory === "All") {
      const distinctCats = Array.from(
        new Set(timelineData.map((item) => item.category).filter(Boolean))
      );
      let globalRowOffset = 0;
      const result = [];
      distinctCats.forEach((cat) => {
        const catItems = timelineData.filter((i) => i.category === cat);
        const positioned = calculateRowPositions(catItems);
        const catMaxRow = positioned.length === 0 ? 0 : Math.max(...positioned.map((i) => i.adjustedRowIndex)) + 1;
        positioned.forEach((item) => {
          result.push({
            ...item,
            adjustedRowIndex: item.adjustedRowIndex + globalRowOffset
          });
        });
        globalRowOffset += catMaxRow;
      });
      return result;
    }
    const filtered = timelineData.filter(
      (item) => item.category === activeCategory
    );
    return calculateRowPositions(filtered);
  }, [activeCategory, timelineData]);
  const totalTimelineRows = useMemo(() => {
    if (displayedTimelineItems.length === 0) return 0;
    return Math.max(...displayedTimelineItems.map((item) => item.adjustedRowIndex)) + 1;
  }, [displayedTimelineItems]);
  useEffect(() => {
    const timer = setTimeout(() => {
      if (viewMode === "cards" && scrollContainerRef.current) {
        scrollContainerRef.current.scrollTo({
          left: scrollContainerRef.current.scrollWidth,
          behavior: "instant"
        });
      } else if (viewMode === "timeline" && gridScrollRef.current) {
        gridScrollRef.current.scrollTo({
          left: gridScrollRef.current.scrollWidth,
          behavior: "instant"
        });
      }
    }, 80);
    return () => clearTimeout(timer);
  }, [viewMode]);
  const scrollToYear = (year) => {
    setActiveYear(year);
    if (!scrollContainerRef.current) return;
    const targetCard = scrollContainerRef.current.querySelector(
      `[data-year="${year}"]`
    );
    if (targetCard) {
      targetCard.scrollIntoView({
        behavior: "smooth",
        inline: "center",
        block: "nearest"
      });
    }
  };
  const scrollStep = (direction) => {
    const currentIndex = YEARS.indexOf(activeYear);
    const nextIndex = Math.min(
      Math.max(currentIndex + direction, 0),
      YEARS.length - 1
    );
    const targetYear = YEARS[nextIndex];
    scrollToYear(targetYear);
  };
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "ranktimeline w-full my-8 select-none",
      style: {
        "--col-width": "24px",
        "--row-height": "40px",
        "--year-height": "40px"
      },
      children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-4 flex-wrap mb-5 px-1", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1.5 p-1 rounded-xl bg-muted/40 border border-white/40", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setViewMode("cards"),
                className: `px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${viewMode === "cards" ? "bg-primary text-black shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
                children: "✨ Story Cards"
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setViewMode("timeline"),
                className: `px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${viewMode === "timeline" ? "bg-primary text-black shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
                children: "📊 Timeline Grid"
              }
            )
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-sm font-medium text-muted-foreground hidden sm:block", children: viewMode === "cards" ? "Interactive evolution by year (2010 – 2026)" : "Chronological succession tracks" })
        ] }),
        viewMode === "cards" && /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            RankTimelinePagination,
            {
              activeYear,
              years: YEARS,
              onSelectYear: scrollToYear,
              onPrev: () => scrollStep(-1),
              onNext: () => scrollStep(1),
              startYear: START_YEAR,
              endYear: END_YEAR
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute left-0 top-0 bottom-0 w-12 sm:w-20 md:w-28 bg-gradient-to-r from-background via-background/70 to-transparent z-20 backdrop-blur-[2px] rounded-l-2xl" }),
            /* @__PURE__ */ jsx("div", { className: "pointer-events-none absolute right-0 top-0 bottom-0 w-12 sm:w-20 md:w-28 bg-gradient-to-l from-background via-background/70 to-transparent z-20 backdrop-blur-[2px] rounded-r-2xl" }),
            /* @__PURE__ */ jsx(
              "div",
              {
                ref: scrollContainerRef,
                className: "ranktimeline-wrap relative overflow-x-auto pb-10 pt-3 px-12 sm:px-24 md:px-36 flex gap-8 sm:gap-10 snap-x snap-mandatory scroll-smooth",
                children: yearCards.map((card) => /* @__PURE__ */ jsx(
                  RankStoryCard,
                  {
                    card,
                    isSelected: activeYear === card.year,
                    onSelect: () => setActiveYear(card.year),
                    categoryBadgeStyles,
                    defaultBadgeStyle
                  },
                  card.year
                ))
              }
            )
          ] })
        ] }),
        viewMode === "timeline" && /* @__PURE__ */ jsx(
          RankTimelineGrid,
          {
            categories,
            activeCategory,
            onSelectCategory: setActiveCategory,
            timelineData,
            displayedTimelineItems,
            totalTimelineRows,
            categoryColors,
            defaultColor,
            years: YEARS,
            gridScrollRef
          }
        ),
        /* @__PURE__ */ jsx(
          Tooltip,
          {
            id: "timeline-tooltip",
            className: "!z-50 !bg-neutral-900/95 !text-white !border !border-white/15 !rounded-xl !px-3.5 !py-2.5 !shadow-2xl !text-sm !backdrop-blur-md"
          }
        )
      ]
    }
  );
};

const GitHubContributions = ({
  username = "ehsanpo",
  defaultYear = (/* @__PURE__ */ new Date()).getFullYear() - 1,
  className = ""
}) => {
  const [selectedYear, setSelectedYear] = useState(defaultYear);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const fetchContributions = async (year) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://github-contributions-api.jogruber.de/v4/${username}?y=${year}`
      );
      if (!response.ok) {
        throw new Error(`Failed to fetch contributions: ${response.statusText}`);
      }
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
      setData(null);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchContributions(selectedYear);
  }, [selectedYear, username]);
  useEffect(() => {
    if (data) {
      const rects = document.querySelectorAll(".react-calendar-heatmap rect");
      rects.forEach((rect, index) => {
        rect.style.transitionDelay = `${index * 2e-3}s`;
        rect.setAttributeNS(null, "rx", "1");
        rect.setAttributeNS(null, "ry", "1");
        rect.setAttributeNS(null, "data-tooltip-id", "tooltip-graph");
      });
    }
  }, [data]);
  const handleYearChange = (event) => {
    setSelectedYear(parseInt(event.target.value));
  };
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  const yearOptions = [];
  for (let year = 2018; year <= currentYear; year++) {
    yearOptions.push(year);
  }
  const heatMapData = data?.contributions.map((day) => ({
    date: day.date,
    count: day.count
  })) || [];
  const totalContributions = data?.total[selectedYear.toString()] || 0;
  return /* @__PURE__ */ jsxs("div", { className: cn("github-contributions min-h-60", className), children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("h3", { className: "text-lg font-semibold text-gray-900 dark:text-gray-100", children: "GitHub Contributions" }),
        /* @__PURE__ */ jsx("div", { className: "h-6", children: data && !loading && /* @__PURE__ */ jsxs("p", { className: "text-sm text-gray-600 dark:text-gray-400", children: [
          totalContributions,
          " contributions in ",
          selectedYear
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        loading && /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-1 text-sm text-gray-600 dark:text-gray-400", children: [
          /* @__PURE__ */ jsxs("svg", { className: "h-4 w-4 animate-spin", viewBox: "0 0 24 24", children: [
            /* @__PURE__ */ jsx(
              "circle",
              {
                className: "opacity-25",
                cx: "12",
                cy: "12",
                r: "10",
                stroke: "currentColor",
                strokeWidth: "4",
                fill: "none"
              }
            ),
            /* @__PURE__ */ jsx(
              "path",
              {
                className: "opacity-75",
                fill: "currentColor",
                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              }
            )
          ] }),
          "Loading..."
        ] }),
        /* @__PURE__ */ jsx(
          "label",
          {
            htmlFor: "year-select",
            className: "text-sm font-medium text-gray-700 dark:text-gray-300",
            children: "Year:"
          }
        ),
        /* @__PURE__ */ jsx(
          "select",
          {
            id: "year-select",
            value: selectedYear,
            onChange: handleYearChange,
            disabled: loading,
            className: "rounded-md border border-gray-300 bg-white px-3 py-1 text-sm text-gray-900 focus:ring-2 focus:ring-blue-500 focus:outline-none dark:border-gray-600 dark:bg-gray-800 dark:text-gray-100",
            children: yearOptions.reverse().map((year) => /* @__PURE__ */ jsx("option", { value: year, children: year }, year))
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "relative", children: [
      error && /* @__PURE__ */ jsx("div", { className: "rounded-lg border border-red-200 bg-red-50 p-4 dark:border-red-700 dark:bg-red-900/20", children: /* @__PURE__ */ jsxs("p", { className: "text-sm text-red-600 dark:text-red-400", children: [
        "Error loading contributions: ",
        error
      ] }) }),
      data && !error && /* @__PURE__ */ jsxs("div", { className: "w-full overflow-x-auto", children: [
        /* @__PURE__ */ jsx("style", { children: `
							.react-calendar-heatmap {
								width: 100% !important;
								min-width: 700px;
							}
							.react-calendar-heatmap .react-calendar-heatmap-month-label {
								font-size: 12px;
								fill: #666;
							}
							.react-calendar-heatmap .react-calendar-heatmap-weekday-label {
								font-size: 10px;
								fill: #666;
							}
							.react-calendar-heatmap .color-empty {
								fill: #ebedf0;
							}
							.react-calendar-heatmap .color-scale-1 {
								fill: #a3d5e8;
							}
							.react-calendar-heatmap .color-scale-2 {
								fill: #6bc4e0;
							}
							.react-calendar-heatmap .color-scale-3 {
								fill: #03aad7;
							}
							.react-calendar-heatmap .color-scale-4 {
								fill: #0377a7;
							}
							.react-calendar-heatmap rect {
								transition: fill 0.1s ease-out;
								opacity: 0;
								animation: cellFadeIn 0.1s ease-out both;
							}
							@keyframes cellFadeIn {
								to {
									opacity: 1;
								}
							}
							.heatmap-container {
							}
							.react-calendar-heatmap rect:hover {
								stroke: var(--primary);
								stroke-width: 1;
								cursor: pointer;
							}
							@media (prefers-color-scheme: dark) {
								.react-calendar-heatmap .react-calendar-heatmap-month-label {
									fill: #ccc;
								}
								.react-calendar-heatmap .react-calendar-heatmap-weekday-label {
									fill: #ccc;
								}
								.react-calendar-heatmap .color-empty {
									fill: #374151;
								}
							}
						` }),
        /* @__PURE__ */ jsxs("div", { className: "heatmap-container", children: [
          /* @__PURE__ */ jsx(
            CalendarHeatmap,
            {
              startDate: /* @__PURE__ */ new Date(`${selectedYear}-01-01`),
              endDate: /* @__PURE__ */ new Date(`${selectedYear}-12-31`),
              values: heatMapData,
              classForValue: (value) => {
                if (!value || value.count === 0) {
                  return "color-empty";
                }
                if (value.count >= 1 && value.count <= 3) return "color-scale-1";
                if (value.count >= 4 && value.count <= 6) return "color-scale-2";
                if (value.count >= 7 && value.count <= 9) return "color-scale-3";
                return "color-scale-4";
              },
              tooltipDataAttrs: (value) => {
                if (!value) return {};
                return {
                  "data-tooltip-content": `${new Date(value.date).toISOString().slice(0, 10)} has count: ${value.count}`
                };
              }
            }
          ),
          /* @__PURE__ */ jsx(Tooltip, { id: "tooltip-graph" })
        ] })
      ] })
    ] })
  ] });
};

const $$GitHubContributionsBlock = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<section class="bg-white py-16 dark:bg-gray-900"> <div class="container mx-auto px-4"> <div class="mb-12 text-center"> ${renderComponent($$result, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading/Heading", "client:component-export": "default" }, { "default": ($$result2) => renderTemplate`GitHub Activity` })} <p class="mx-auto max-w-2xl text-lg text-gray-600 dark:text-gray-300">
A visual representation of my coding activity and contributions over time.
</p> </div> <div class="mx-auto max-w-6xl"> ${renderComponent($$result, "GitHubContributions", GitHubContributions, { "username": "ehsanpo", "className": "rounded-lg bg-gray-50 px-6 pt-6 pb-4 shadow-sm dark:bg-gray-800", "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/ep/dev/portfolio2026/src/components/GitHubContributions", "client:component-export": "default" })} </div> </div> </section>`;
}, "C:/Users/ep/dev/portfolio2026/src/blocks/GitHubContributionsBlock.astro", void 0);

const $$Skills = createComponent(($$result, $$props, $$slots) => {
  const { stacks, charts } = getPortfolioData();
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Skills - Developer Portfolio" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Skills & Tools", "subtitle": "My technical expertise and proficiency across different technologies" })} ${renderComponent($$result2, "TechStackBlock", $$TechStackBlock, { "showAll": true })} ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Skills Chart` })} ${renderComponent($$result2, "SkillChart", SkillChart, { "data": stacks, "chartData": charts[0], "client:load": true, "showButtons": true, "client:component-hydration": "load", "client:component-path": "C:/Users/ep/dev/portfolio2026/src/components/SkillChart", "client:component-export": "default" })} ${maybeRenderHead()}<section class=""> <div class="container mx-auto"> ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Tech Timeline ` })} ${renderComponent($$result2, "RankTimeline", RankTimeline, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@/components/RankTimeline", "client:component-export": "default" })} </div> </section> ${renderComponent($$result2, "ToolsList", $$ToolsList, {})} ${renderComponent($$result2, "GitHubContributionsBlock", $$GitHubContributionsBlock, {})} ${renderComponent($$result2, "Heading", Heading, { "level": "h2", "gradient": true, "floating": true, "backplate": true, "client:idle": true, "client:component-hydration": "idle", "client:component-path": "@/components/ui/heading", "client:component-export": "Heading" }, { "default": ($$result3) => renderTemplate`Development Process` })} ${renderComponent($$result2, "ProcessFlowDiagram", ProcessFlowDiagram, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@/components/Beams", "client:component-export": "ProcessFlowDiagram" })} ${renderComponent($$result2, "Certificates", $$CertificatesBlock, { "showAll": true })} ` })}`;
}, "C:/Users/ep/dev/portfolio2026/src/pages/skills.astro", void 0);

const $$file = "C:/Users/ep/dev/portfolio2026/src/pages/skills.astro";
const $$url = "/skills";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Skills,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
