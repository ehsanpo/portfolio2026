import { c as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yypz6blN.mjs';
import 'piccolore';
import { $ as $$Layout, p as portfolioData } from '../chunks/Layout_zewWmYqx.mjs';
import { P as ProjectCard3D } from '../chunks/ProjectCard3D_CSBmQc0h.mjs';
import { $ as $$PageHero } from '../chunks/PageHero_DJ2Ub2co.mjs';
export { renderers } from '../renderers.mjs';

const $$Work = createComponent(($$result, $$props, $$slots) => {
  const companies = portfolioData.companies;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Experience", "description": "Work Experience and Professional Career" }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "PageHero", $$PageHero, { "title": "Experience", "subtitle": "A showcase of the companies I've worked at" })} ${maybeRenderHead()}<section class="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8"> <div class="grid grid-cols-1 gap-10 md:grid-cols-3"> ${companies.map((company, index) => renderTemplate`${renderComponent($$result2, "ProjectCard3D", ProjectCard3D, { "client:visible": true, "title": company.name, "description": company.description, "date": company.year, "tags": company.tags, "image": company.image ? {
    src: company.image,
    alt: company.name,
    width: 800,
    height: 600
  } : void 0, "categories": company.position, "layout": index, "href": `/work/${company.id}`, "client:component-hydration": "visible", "client:component-path": "@/components/ProjectCard3D", "client:component-export": "ProjectCard3D" })}`)} </div> </section> ` })}`;
}, "C:/Users/Ehsan/dev/portfolio2026/src/pages/work.astro", void 0);

const $$file = "C:/Users/Ehsan/dev/portfolio2026/src/pages/work.astro";
const $$url = "/work";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Work,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
